export default {
  props: {
    color: {
      type: String,
      default: '#fff'
    }
  }
}
