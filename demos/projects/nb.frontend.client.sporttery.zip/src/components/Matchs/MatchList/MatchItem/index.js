import MatchItem from './MatchItem';

export default MatchItem;
