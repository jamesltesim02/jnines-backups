import TabBarB06 from './TabBarB06';

export default TabBarB06;
