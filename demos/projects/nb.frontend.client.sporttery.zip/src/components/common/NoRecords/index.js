import NoRecords from './NoRecords';

export default NoRecords;
