<template>
  <svg width=".46rem" height=".46rem" style="width:.46rem;height:.46rem" viewBox="0 0 46 46" version="1.1">
    <defs>
      <linearGradient x1="50%" y1="0%" x2="50%" y2="99.4378167%" id="share-white-1">
        <stop stop-color="#E8FDFF" offset="0%"></stop>
        <stop stop-color="#CBFFF7" offset="100%"></stop>
      </linearGradient>
    </defs>
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-20, -305)">
        <g transform="translate(10, 290)">
          <g transform="translate(10, 15)">
            <circle fill="url(#share-white-1)" opacity="0.6" cx="23" cy="23" r="23"></circle>
            <g transform="translate(11.5, 11)">
              <path d="M7.04,4 L20.04,4 C21.6968542,4 23.04,5.34314575 23.04,7 L23.04,20 C23.04,21.6568542 21.6968542,23 20.04,23 L8.04,23 C6.38314575,23 5.04,21.6568542 5.04,20 L5.04,6 C5.04,4.8954305 5.9354305,4 7.04,4 Z" fill="#BEE8FF"></path>
              <path d="M14.3789868,0 L22.0416667,0 C22.2802132,0 22.498403,0.0871576378 22.6661285,0.231365346 C22.8705423,0.407117123 23,0.667606993 23,0.958333333 C23,4.45801185 23,6.12443741 23,7.87427667 M23,12.6508617 C23,14.2377093 23,15.451311 23,20.125 C23,21.7128187 21.7128187,23 20.125,23 L2.875,23 C1.28718134,23 0,21.7128187 0,20.125 L0,2.875 C0,1.28718134 1.28718134,0 2.875,0 L9.57893557,0 M22.6661285,0.231365346 L12.6612031,11.3234442" stroke="#1C8EFC" stroke-width="1.8" stroke-linecap="round"></path>
            </g>
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
