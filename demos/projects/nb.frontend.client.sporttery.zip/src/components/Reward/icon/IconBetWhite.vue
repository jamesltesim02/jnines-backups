<template>
  <svg width=".46rem" height=".46rem" style="width:.46rem;height:.46rem" viewBox="0 0 46 46" version="1.1">
    <defs>
      <linearGradient x1="50%" y1="0%" x2="50%" y2="100%" id="bet-white-1">
        <stop stop-color="#FAF1ED" offset="0%"></stop>
        <stop stop-color="#FEE6DD" offset="100%"></stop>
      </linearGradient>
    </defs>
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-20, -219)">
        <g transform="translate(10, 204)">
          <g transform="translate(10, 15)">
            <circle fill="url(#bet-white-1)" opacity="0.745" cx="23" cy="23" r="23"></circle>
            <path d="M19.04,16 L32.04,16 C33.6968542,16 35.04,17.3431458 35.04,19 L35.04,32 C35.04,33.6568542 33.6968542,35 32.04,35 L20.04,35 C18.3831458,35 17.04,33.6568542 17.04,32 L17.04,18 C17.04,16.8954305 17.9354305,16 19.04,16 Z" fill="#FFCCD1"></path>
            <circle fill="#FE4C66" cx="17.3744" cy="17.3552" r="1.92"></circle>
            <circle fill="#FE4C66" cx="23" cy="23" r="1.92"></circle>
            <circle fill="#FE4C66" cx="28.6448" cy="28.6448" r="1.92"></circle>
            <path d="M14,11 L32,11 C33.6568542,11 35,12.3431458 35,14 L35,32 C35,33.6568542 33.6568542,35 32,35 L14,35 C12.3431458,35 11,33.6568542 11,32 L11,14 C11,12.3431458 12.3431458,11 14,11 Z M14.7,12.7 C13.5954305,12.7 12.7,13.5954305 12.7,14.7 L12.7,31.3 C12.7,32.4045695 13.5954305,33.3 14.7,33.3 L31.3,33.3 C32.4045695,33.3 33.3,32.4045695 33.3,31.3 L33.3,14.7 C33.3,13.5954305 32.4045695,12.7 31.3,12.7 L14.7,12.7 Z" fill="#FE4C66"></path>
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
