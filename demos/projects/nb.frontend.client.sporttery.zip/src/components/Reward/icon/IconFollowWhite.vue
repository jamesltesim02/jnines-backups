<template>
  <svg width=".46rem" height=".46rem" style="width:.46rem;height:.46rem" viewBox="0 0 46 46" version="1.1">
    <defs>
      <linearGradient x1="50%" y1="0%" x2="50%" y2="98.3145221%" id="follow-white-1">
        <stop stop-color="#F7F0FF" offset="0%"></stop>
        <stop stop-color="#F4E8FF" offset="100%"></stop>
      </linearGradient>
    </defs>
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-20, -593)">
        <g transform="translate(10, 578)">
          <g transform="translate(10, 15)">
            <circle fill="url(#follow-white-1)" opacity="0.5" cx="23" cy="23" r="23"></circle>
            <g transform="translate(10, 12)">
              <path d="M27,20.4725275 C27,16.3759098 24.1218305,13.0549451 20.5714286,13.0549451 C17.0210266,13.0549451 14.1428571,16.3759098 14.1428571,20.4725275" stroke="#5F66FF" stroke-width="1.8" stroke-linecap="round"></path>
              <circle stroke="#5F66FF" stroke-width="1.8" cx="20.5714286" cy="8.6043956" r="3.46153846"></circle>
              <path d="M12.0857143,21.4305053 L16.7142857,21.4305053 C16.7142857,16.1049024 10.6540346,10.1203111 7.25558871,10.9285714 C3.85714286,11.7368317 12.0857143,14.4991509 8.74285714,21.4305053 C8.74285714,21.4305053 9.62188674,21.4305053 9.83663957,21.4305053 C9.97980812,21.4305053 10.7294997,21.4305053 12.0857143,21.4305053 Z" fill="#AEC8FF"></path>
              <circle fill="#AEC8FF" cx="8.74285714" cy="4.62857143" r="3.34285714"></circle>
              <path d="M16.7142857,20.5714286 C16.7142857,15.2458256 12.9726654,10.9285714 8.35714286,10.9285714 C3.74162031,10.9285714 0,15.2458256 0,20.5714286" stroke="#5F66FF" stroke-width="1.8" stroke-linecap="round"></path>
              <circle stroke="#5F66FF" stroke-width="1.8" cx="8.35714286" cy="5.14285714" r="4.5"></circle>
            </g>
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
