<template>
  <svg width=".46rem" height=".46rem" style="width:.46rem;height:.46rem" viewBox="0 0 46 46" version="1.1">
    <defs>
      <linearGradient x1="50%" y1="0%" x2="50%" y2="100%" id="bet-blue-1">
        <stop stop-color="#FAF1ED" offset="0%"></stop>
        <stop stop-color="#FEE6DD" offset="100%"></stop>
      </linearGradient>
    </defs>
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-20, -219)">
        <g transform="translate(10, 204)">
          <g transform="translate(10, 15)">
            <circle fill="url(#bet-blue-1)" opacity="0.1" cx="23" cy="23" r="23"></circle>
            <g transform="translate(11, 11)" fill="#FE4C66">
              <circle cx="6.3744" cy="6.3552" r="1.92"></circle>
              <circle cx="12" cy="12" r="1.92"></circle>
              <circle cx="17.6448" cy="17.6448" r="1.92"></circle>
              <path d="M3,0 L21,0 C22.6568542,-3.04359188e-16 24,1.34314575 24,3 L24,21 C24,22.6568542 22.6568542,24 21,24 L3,24 C1.34314575,24 2.02906125e-16,22.6568542 0,21 L0,3 C-2.02906125e-16,1.34314575 1.34314575,3.04359188e-16 3,0 Z M3.7,1.7 C2.5954305,1.7 1.7,2.5954305 1.7,3.7 L1.7,20.3 C1.7,21.4045695 2.5954305,22.3 3.7,22.3 L20.3,22.3 C21.4045695,22.3 22.3,21.4045695 22.3,20.3 L22.3,3.7 C22.3,2.5954305 21.4045695,1.7 20.3,1.7 L3.7,1.7 Z"></path>
            </g>
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
