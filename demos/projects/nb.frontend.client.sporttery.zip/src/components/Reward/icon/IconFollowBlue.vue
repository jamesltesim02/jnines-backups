<template>
  <svg width=".46rem" height=".46rem" style="width:.46rem;height:.46rem" viewBox="0 0 46 46" version="1.1">
    <defs>
      <linearGradient x1="50%" y1="0%" x2="50%" y2="98.3145221%" id="follow-blue-1">
        <stop stop-color="#F7F0FF" offset="0%"></stop>
        <stop stop-color="#F4E8FF" offset="100%"></stop>
      </linearGradient>
    </defs>
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-20, -593)">
        <g transform="translate(10, 578)">
          <g transform="translate(10, 15)">
            <circle fill="url(#follow-blue-1)" opacity="0.1" cx="23" cy="23" r="23"></circle>
            <g transform="translate(10, 12)" stroke="#5F66FF" stroke-width="1.8">
              <path d="M27,20.4725275 C27,16.3759098 24.1218305,13.0549451 20.5714286,13.0549451 C18.6960633,13.0549451 17.0082563,13.9815209 15.8331084,15.4595561" stroke-linecap="round"></path>
              <circle cx="20.5714286" cy="8.6043956" r="3.46153846"></circle>
              <path d="M16.7142857,20.5714286 C16.7142857,15.2458256 12.9726654,10.9285714 8.35714286,10.9285714 C3.74162031,10.9285714 0,15.2458256 0,20.5714286" stroke-linecap="round"></path>
              <circle cx="8.35714286" cy="5.14285714" r="4.5"></circle>
            </g>
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
