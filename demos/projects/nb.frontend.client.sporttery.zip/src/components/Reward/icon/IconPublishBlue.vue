<template>
  <svg width=".46rem" height=".46rem" style="width:.46rem;height:.46rem" viewBox="0 0 46 46" version="1.1">
    <defs>
      <linearGradient x1="50%" y1="0%" x2="50%" y2="100%" id="publish-blue-1">
        <stop stop-color="#FFF6DD" offset="0%"></stop>
        <stop stop-color="#FFEDBD" offset="100%"></stop>
      </linearGradient>
    </defs>
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-20, -449)">
        <g transform="translate(10, 434)">
          <g transform="translate(10, 15)">
            <circle fill="url(#publish-blue-1)" opacity="0.1" cx="23" cy="23" r="23"></circle>
            <path d="M14.5,11.4 C13.340202,11.4 12.4,12.340202 12.4,13.5 L12.4,32.3888889 C12.4,33.5486869 13.340202,34.4888889 14.5,34.4888889 L31.04,34.4888889 C32.199798,34.4888889 33.14,33.5486869 33.14,32.3888889 L33.14,13.5 C33.14,12.340202 32.199798,11.4 31.04,11.4 L14.5,11.4 Z" stroke="#FB8D2E" stroke-width="1.8"></path>
            <path d="M17.4033333,19.3148148 L28.1366667,19.3148148" stroke="#FB8D2E" stroke-width="1.8" stroke-linecap="round"></path>
            <path d="M17.4033333,23.9814815 L24.9166667,23.9814815" stroke="#FB8D2E" stroke-width="1.8" stroke-linecap="round"></path>
            <path d="M17.4033333,29.1666667 L22.77,29.1666667" stroke="#FB8D2E" stroke-width="1.8" stroke-linecap="round"></path>
            <g transform="translate(11.5, 10.5)"></g>
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
