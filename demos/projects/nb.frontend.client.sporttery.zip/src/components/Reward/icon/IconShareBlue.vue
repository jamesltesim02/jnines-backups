<template>
  <svg width=".46rem" height=".46rem" style="width:.46rem;height:.46rem" viewBox="0 0 46 46" version="1.1">
    <defs>
      <linearGradient x1="50%" y1="0%" x2="50%" y2="99.4378167%" id="share-blue-1">
        <stop stop-color="#E8FDFF" offset="0%"></stop>
        <stop stop-color="#CBFFF7" offset="100%"></stop>
      </linearGradient>
    </defs>
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-20, -305)">
        <g transform="translate(10, 290)">
          <g transform="translate(10, 15)">
            <circle fill="url(#share-blue-1)" opacity="0.1" cx="23" cy="23" r="23"></circle>
            <g transform="translate(12.5, 12)" stroke="#1C8EFC" stroke-linecap="round" stroke-width="1.8">
              <path d="M13.7538134,0 L21.0833333,0 C21.3115083,0 21.5202116,0.0833681753 21.6806446,0.221305983 C21.8761709,0.389416378 22,0.638580602 22,0.916666667 C22,4.26418525 22,5.85815752 22,7.53191682 M22,12.1008242 C22,13.6186785 22,14.7795148 22,19.25 C22,20.7687831 20.7687831,22 19.25,22 L2.75,22 C1.23121694,22 0,20.7687831 0,19.25 L0,2.75 C0,1.23121694 1.23121694,0 2.75,0 L9.16246011,0 M21.6806446,0.221305983 L12.110716,10.8311206"></path>
            </g>
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
