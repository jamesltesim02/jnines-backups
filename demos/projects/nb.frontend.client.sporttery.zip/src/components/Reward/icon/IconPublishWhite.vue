<template>
  <svg width=".46rem" height=".46rem" style="width:.46rem;height:.46rem" viewBox="0 0 46 46" version="1.1">
    <defs>
      <linearGradient x1="50%" y1="0%" x2="50%" y2="100%" id="publish-white-1">
        <stop stop-color="#FFF6DD" offset="0%"></stop>
        <stop stop-color="#FFEDBD" offset="100%"></stop>
      </linearGradient>
    </defs>
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-20, -449)">
        <g transform="translate(10, 434)">
          <g transform="translate(10, 15)">
            <circle fill="url(#publish-white-1)" opacity="0.5" cx="23" cy="23" r="23"></circle>
            <g transform="translate(11.5, 10.5)">
              <path d="M7.025,4.40740741 L18.735,4.40740741 C20.3918542,4.40740741 21.735,5.75055316 21.735,7.40740741 L21.735,20.8518519 C21.735,22.5087061 20.3918542,23.8518519 18.735,23.8518519 L7.025,23.8518519 C5.36814575,23.8518519 4.025,22.5087061 4.025,20.8518519 L4.025,7.40740741 C4.025,5.75055316 5.36814575,4.40740741 7.025,4.40740741 Z" fill="#FFD633"></path>
              <path d="M3,0.9 C1.84020203,0.9 0.9,1.84020203 0.9,3 L0.9,21.8888889 C0.9,23.0486869 1.84020203,23.9888889 3,23.9888889 L19.54,23.9888889 C20.699798,23.9888889 21.64,23.0486869 21.64,21.8888889 L21.64,3 C21.64,1.84020203 20.699798,0.9 19.54,0.9 L3,0.9 Z" stroke="#FB8D2E" stroke-width="1.8"></path>
              <path d="M5.90333333,8.81481481 L16.6366667,8.81481481" stroke="#FB8D2E" stroke-width="1.8" stroke-linecap="round"></path>
              <path d="M5.90333333,13.4814815 L13.4166667,13.4814815" stroke="#FB8D2E" stroke-width="1.8" stroke-linecap="round"></path>
              <path d="M5.90333333,18.6666667 L11.27,18.6666667" stroke="#FB8D2E" stroke-width="1.8" stroke-linecap="round"></path>
            </g>
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
