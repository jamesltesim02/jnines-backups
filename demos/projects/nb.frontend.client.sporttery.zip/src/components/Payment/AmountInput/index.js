import AmountInput from './AmountInput';

export default AmountInput;
