import BtnToggleTheme from './BtnToggleTheme';

export default BtnToggleTheme;
