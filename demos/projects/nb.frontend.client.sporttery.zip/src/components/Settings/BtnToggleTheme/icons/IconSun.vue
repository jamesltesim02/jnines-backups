<template>
  <cimg src="./sun.png" />
</template>
