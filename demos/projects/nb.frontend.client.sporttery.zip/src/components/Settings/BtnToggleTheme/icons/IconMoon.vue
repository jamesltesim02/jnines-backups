<template>
  <cimg src="./moon.png" />
</template>
