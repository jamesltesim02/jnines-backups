<template>
<svg width=".16rem" height=".18rem" style="width:.16rem;height:.18rem" viewBox="0 0 16 18" >
  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g transform="translate(-188, -34)" :fill="color" fill-rule="nonzero">
      <g transform="translate(43, 24)">
        <g transform="translate(127, 4)">
          <g transform="translate(0, 6)">
            <path d="M31.9014085,18 L18.6901408,18 L18.6901408,16.2125679 L20.943662,13.4197052 L20.943662,3.6446858 L18,0 L28.1971831,0 L25.2676056,3.63072149 L25.2676056,13.0147401 L29.4929577,13.0147401 L34,9.10473235 L31.9014085,18 Z M19.9577465,16.7432118 L30.9014085,16.7432118 L31.8591549,12.5539178 L29.943662,14.2156711 L23.971831,14.2156711 L23.971831,3.18386346 L25.5492958,1.24282389 L20.6478873,1.24282389 L22.2112676,3.18386346 L22.2112676,13.8665632 L19.9577465,16.7432118 Z" />
          </g>
        </g>
      </g>
    </g>
  </g>
</svg>
</template>
<script>
export default {
  props: ['color'],
};
</script>
