import QuickBetBar from './QuickBetBar';

export default QuickBetBar;
