import FilterBar from './FilterBar';

export default FilterBar;
