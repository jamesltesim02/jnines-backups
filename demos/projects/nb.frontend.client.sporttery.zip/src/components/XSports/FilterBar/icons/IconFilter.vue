<template>
<svg width=".24rem" height=".23rem" style="width:.24rem;height:.23rem" viewBox="0 0 24 23" >
  <defs>
    <linearGradient x1="21.730972%" y1="39.4037783%" x2="73.4432438%" y2="59.7525627%" id="linearGradient-1">
      <stop stop-color="#F0EFEF" offset="0%"></stop>
      <stop stop-color="#F0EFEF" offset="100%"></stop>
    </linearGradient>
    <linearGradient x1="21.730972%" y1="39.4037783%" x2="73.4432438%" y2="59.7525627%" id="linearGradient-2">
      <stop stop-color="#00E5FE" stop-opacity="0.2" offset="0%"></stop>
      <stop stop-color="#00E5FE" stop-opacity="0.08" offset="100%"></stop>
    </linearGradient>
    <linearGradient x1="30.1879148%" y1="-9.16676799%" x2="66.4828548%" y2="63.8004013%" id="linearGradient-3">
      <stop stop-color="#979797" offset="0%"></stop>
      <stop stop-color="#979797" offset="100%"></stop>
    </linearGradient>
    <linearGradient x1="30.1879148%" y1="-9.16676799%" x2="66.4828548%" y2="63.8004013%" id="linearGradient-4">
      <stop stop-color="#00FFD8" offset="0%"></stop>
      <stop stop-color="#00E5FE" offset="100%"></stop>
    </linearGradient>
    <linearGradient x1="32.7856284%" y1="-17.8418607%" x2="64.321662%" y2="65.8238305%" id="linearGradient-5">
      <stop stop-color="#979797" offset="0%"></stop>
      <stop stop-color="#979797" offset="100%"></stop>
    </linearGradient>
    <linearGradient x1="32.7856284%" y1="-17.8418607%" x2="64.321662%" y2="65.8238305%" id="linearGradient-6">
      <stop stop-color="#00FFD8" offset="0%"></stop>
      <stop stop-color="#00E5FE" offset="100%"></stop>
    </linearGradient>
    <linearGradient x1="30.1879148%" y1="26.5179459%" x2="66.4828548%" y2="55.477091%" id="linearGradient-7">
      <stop stop-color="#979797" offset="0%"></stop>
      <stop stop-color="#979797" offset="100%"></stop>
    </linearGradient>
    <linearGradient x1="30.1879148%" y1="26.5179459%" x2="66.4828548%" y2="55.477091%" id="linearGradient-8">
      <stop stop-color="#00FFD8" offset="0%"></stop>
      <stop stop-color="#00E5FE" offset="100%"></stop>
    </linearGradient>
    <linearGradient x1="30.1879148%" y1="35.2955299%" x2="66.4828548%" y2="53.4297562%" id="linearGradient-9">
      <stop stop-color="#979797" offset="0%"></stop>
      <stop stop-color="#979797" offset="100%"></stop>
    </linearGradient>
    <linearGradient x1="30.1879148%" y1="35.2955299%" x2="66.4828548%" y2="53.4297562%" id="linearGradient-10">
      <stop stop-color="#00FFD8" offset="0%"></stop>
      <stop stop-color="#00E5FE" offset="100%"></stop>
    </linearGradient>
  </defs>
  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" >
    <g transform="translate(-338, -74)">
      <g transform="translate(339, 75)">
        <ellipse :fill="`url(#linearGradient-${/blue/i.test(theme) ? 2 : 1})`" transform="translate(9.554951, 16.301859) rotate(33) translate(-9.554951, -16.301859) " cx="9.55495058" cy="16.3018591" rx="5.14960776" ry="2.68572621" />
        <path :stroke="`url(#linearGradient-${/blue/i.test(theme) ? 4 : 3})`" d="M0,3.87726087 L8.1973913,0.0578695653 C8.1973913,0.0578695653 17.5856522,5.43973913 19.1208696,6.48665217 C20.6083945,7.38588275 21.6393816,8.98523456 21.9186957,10.8268696 C22.2838682,13.2125665 21.2613667,15.5963685 19.3552174,16.8032174 C17.6143478,17.9763913 15.0317391,19.2968696 13.7882609,19.9597391 C12.3534783,20.7067826 10.1056522,21.3012609 7.3173913,18.6708261 C4.10826087,15.6458261 4.88304348,10.6006522 4.88304348,10.6006522 L0,7.29156522 L0,3.87726087 Z" stroke-width="1.4" stroke-linecap="round" />
        <path :stroke="`url(#linearGradient-${/blue/i.test(theme) ? 6 : 5})`" d="M13.5491304,17.5976087 C13.8192936,16.6444178 13.8734757,15.6330189 13.7069565,14.6515217 C13.4427996,12.8047223 12.4121335,11.1984389 10.9186957,10.3060435 L10.9186957,10.3060435 L2.24304348,5.19773913" stroke-width="1.4" stroke-linecap="round" />
        <path :stroke="`url(#linearGradient-${/blue/i.test(theme) ? 8 : 7})`" d="M13.3004348,9.67473913 L10.5552174,8.05965217" stroke-width="1.4" stroke-linecap="round" />
        <path :stroke="`url(#linearGradient-${/blue/i.test(theme) ? 8 : 7})`" d="M17.9108696,7.52830434 L15.1656522,5.91321739" stroke-width="1.4" stroke-linecap="round" />
        <path :stroke="`url(#linearGradient-${/blue/i.test(theme) ? 10 : 9})`" d="M10.5552174,8.05965217 L15.1656522,5.91321739" stroke-width="1.4" stroke-linecap="round" />
        <path :stroke="`url(#linearGradient-${/blue/i.test(theme) ? 10 : 9})`" d="M13.3004348,9.67473913 L17.9108696,7.52830434" stroke-width="1.4" stroke-linecap="round" />
      </g>
    </g>
  </g>
</svg>
</template>
<script>
import { mapState } from 'vuex';

export default {
  computed: {
    ...mapState('app', ['theme']),
  },
};
</script>
