import SportsFilterList from './SportsFilterList';

export default SportsFilterList;
