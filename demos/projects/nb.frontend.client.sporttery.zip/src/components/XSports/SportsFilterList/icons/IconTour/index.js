import IconTour from './IconTour';

export default IconTour;
