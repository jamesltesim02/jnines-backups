<template>
  <svg
    width=".21rem"
    height=".25rem"
    viewBox="0 0 21 25"
    version="1.1"
  >
    <defs>
      <linearGradient
        x1="6.28407376%"
        y1="46.7045644%"
        x2="96.0018199%"
        y2="64.639333%"
        id="icon-member-lg-1"
      >
        <stop stop-color="#FF8B70" offset="0%" />
        <stop stop-color="#FF4848" offset="100%" />
      </linearGradient>
      <linearGradient
        x1="6.28407376%"
        y1="40.0990468%"
        x2="96.0018199%"
        y2="93.9830627%"
        id="icon-member-lg-2"
      >
        <stop stop-color="#FF8B70" offset="0%" />
        <stop stop-color="#FF4848" offset="100%" />
      </linearGradient>
    </defs>
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-340.000000, -11.000000)">
        <g transform="translate(341.000000, 12.000000)">
          <path
            d="M13.4285714,23.0973868 L18.5714286,23.0973868 C18.5714286,17.1800502 11.8378162,10.5305044 8.06176523,11.4285714 C4.28571429,12.3266384 13.4285714,15.395882 9.71428571,23.0973868 C9.71428571,23.0973868 10.6909853,23.0973868 10.9295995,23.0973868 C11.0886757,23.0973868 11.9216663,23.0973868 13.4285714,23.0973868 Z"
            fill="#FFCCD1"
          />
          <circle fill="#FFCCD1" cx="9.71428571" cy="4.42857143" r="3.71428571" />
          <path
            d="M18.5714286,22.1428571 C18.5714286,16.2255205 14.4140727,11.4285714 9.28571429,11.4285714 C4.15735589,11.4285714 0,16.2255205 0,22.1428571"
            stroke="url(#icon-member-lg-1)"
            stroke-width="1.8"
            stroke-linecap="round"
          />
          <circle
            stroke="url(#icon-member-lg-2)"
            stroke-width="1.8"
            cx="9.28571429"
            cy="5"
            r="5"
          />
        </g>
      </g>
    </g>
  </svg>
</template>
