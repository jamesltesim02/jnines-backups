import IconSports from './IconSports';

export default IconSports;
