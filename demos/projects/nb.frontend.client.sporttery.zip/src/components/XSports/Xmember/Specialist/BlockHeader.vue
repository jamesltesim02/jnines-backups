<template>
  <h3 class="x-block-header"><slot /></h3>
</template>
<style lang="less">
.x-block-header {
  font-size: .16rem;
  letter-spacing: -0.31px;
  border-left: .03rem solid #ff5353;
  padding-left: .12rem;
}
.blue .x-block-header {
  color: #ecebeb;
  border-left: .03rem solid #53fffd;
}
</style>
