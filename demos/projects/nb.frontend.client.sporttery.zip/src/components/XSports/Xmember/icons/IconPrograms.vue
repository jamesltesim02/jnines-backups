<template>
  <svg
    width=".24rem"
    height=".27rem"
    style="width:.24rem;height:.27rem"
    viewBox="0 0 24 27"
  >
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g transform="translate(-176.000000, -221.000000)">
        <g transform="translate(176.000000, 221.500000)">
          <path
            d="M7.2,4.5837037 L19.68,4.5837037 C21.3368542,4.5837037 22.68,5.92684945 22.68,7.5837037 L22.68,21.8059259 C22.68,23.4627802 21.3368542,24.8059259 19.68,24.8059259 L7.2,24.8059259 C5.54314575,24.8059259 4.2,23.4627802 4.2,21.8059259 L4.2,7.5837037 C4.2,5.92684945 5.54314575,4.5837037 7.2,4.5837037 Z"
            fill="#FFD633"
          />
          <path
            d="M3,0.9 C1.84020203,0.9 0.9,1.84020203 0.9,3 L0.9,22.8844444 C0.9,24.0442424 1.84020203,24.9844444 3,24.9844444 L20.52,24.9844444 C21.679798,24.9844444 22.62,24.0442424 22.62,22.8844444 L22.62,3 C22.62,1.84020203 21.679798,0.9 20.52,0.9 L3,0.9 Z"
            stroke="#FB8D2E"
            stroke-width="1.8"
          />
          <path
            d="M6.16,9.16740741 L17.36,9.16740741"
            stroke="#FB8D2E"
            stroke-width="1.8"
            stroke-linecap="round"
          />
          <path
            d="M6.16,14.0207407 L14,14.0207407"
            stroke="#FB8D2E"
            stroke-width="1.8"
            stroke-linecap="round"
          />
          <path
            d="M6.16,19.4133333 L11.76,19.4133333"
            stroke="#FB8D2E"
            stroke-width="1.8"
            stroke-linecap="round"
          />
        </g>
      </g>
    </g>
  </svg>
</template>
