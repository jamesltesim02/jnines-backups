import IconHead from './IconHead';

export default IconHead;
