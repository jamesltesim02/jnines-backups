<template>
<svg
  width=".27rem"
  height=".27rem"
  style="width:.27rem;height:.27rem"
  viewBox="0 0 27 27"
>
  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g transform="translate(-58.000000, -221.000000)">
      <g transform="translate(59.000000, 222.000000)">
        <circle fill="#FFCCD1" cx="14.7058824" cy="14.7058824" r="10.2941176" />
        <circle stroke="#FE4C66" stroke-width="1.8" cx="12.5" cy="12.5" r="12.5" />
        <path
          d="M12.5,6.91176471 L12.5,12.9624483 C12.5,13.0176768 12.5447715,13.0624483 12.6,13.0624483 L16.7315679,13.0624483"
          stroke="#FE4C66"
          stroke-width="1.8"
          stroke-linecap="round"
        />
      </g>
    </g>
  </g>
</svg>
</template>
