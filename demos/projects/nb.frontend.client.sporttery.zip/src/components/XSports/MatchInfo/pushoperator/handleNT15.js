export default (vm) => {
  vm.matchInfo.games = [];
};
