export default {
  msg1: 'Hello!',
  msg2: 'I\'m msg 2.',
  msg3: 'I\'m msg 3',
};
