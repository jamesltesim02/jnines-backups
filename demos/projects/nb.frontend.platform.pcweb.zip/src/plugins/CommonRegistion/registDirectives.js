// import Vue from 'vue';

/**
 * 注册全局指令
 */
export default () => {
};
