<template>
  <div class="jackpot-page">
    奖池
  </div>
</template>
<script>

export default {
  data() {
    return { };
  },
  mounted() { },
};
</script>
<style lang="less">
.jackpot-page {
  padding-top: 20px;
}
</style>
