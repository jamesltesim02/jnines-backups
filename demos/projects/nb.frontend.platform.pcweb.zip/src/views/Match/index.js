import Match from './Match';

export default Match;
