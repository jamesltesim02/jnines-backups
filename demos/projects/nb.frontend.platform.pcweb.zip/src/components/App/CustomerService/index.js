import CustomerService from './CustomerService';

export default CustomerService;
