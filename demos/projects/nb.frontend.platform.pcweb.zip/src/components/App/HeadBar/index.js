import HeadBar from './HeadBar';

export default HeadBar;
