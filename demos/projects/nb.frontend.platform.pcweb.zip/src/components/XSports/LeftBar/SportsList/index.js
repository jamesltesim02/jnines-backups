import SportsList from './SportsList';

export default SportsList;
