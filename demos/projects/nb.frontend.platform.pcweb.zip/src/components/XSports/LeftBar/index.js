import LeftBar from './LeftBar';

export default LeftBar;
