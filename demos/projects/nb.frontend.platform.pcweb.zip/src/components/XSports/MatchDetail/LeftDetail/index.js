import LeftDetail from './LeftDetail';

export default LeftDetail;
