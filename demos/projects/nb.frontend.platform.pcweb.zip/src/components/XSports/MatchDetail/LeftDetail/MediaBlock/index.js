import MediaBlock from './MediaBlock';

export default MediaBlock;
