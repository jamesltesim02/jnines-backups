import RightDetail from './RightDetail';

export default RightDetail;
