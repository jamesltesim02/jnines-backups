export default (vm) => {
  vm.match.games = [];
};
