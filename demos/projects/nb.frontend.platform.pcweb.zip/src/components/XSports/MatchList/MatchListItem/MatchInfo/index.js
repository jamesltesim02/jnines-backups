import MatchInfo from './MatchInfo';

export default MatchInfo;
