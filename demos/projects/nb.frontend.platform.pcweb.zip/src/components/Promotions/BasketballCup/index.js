import BasketballCup from './BasketballCup';

export default BasketballCup;
