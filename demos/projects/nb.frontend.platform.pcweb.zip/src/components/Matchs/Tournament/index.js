import Tournament from './Tournament';

export default Tournament;
