import DetailGames from './DetailGames';

export default DetailGames;
