import GameOption from './GameOption';

export default GameOption;
