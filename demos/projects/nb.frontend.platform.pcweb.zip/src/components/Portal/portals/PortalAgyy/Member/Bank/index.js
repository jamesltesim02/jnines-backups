import Bank from './Bank';

export default Bank;
