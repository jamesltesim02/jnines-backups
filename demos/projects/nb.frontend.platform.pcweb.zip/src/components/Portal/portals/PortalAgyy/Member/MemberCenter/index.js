import MemberCenter from './MemberCenter';

export default MemberCenter;
