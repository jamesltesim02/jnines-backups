import PortalAgyy from './PortalAgyy';

export default PortalAgyy;
