import Channels from './Channels';

export default Channels;
