import PayResult from './PayResult';

export default PayResult;
