<template>
  <h4 class="agyy-sign-header"><slot /></h4>
</template>
<style lang="less">
.agyy-sign-header {
  margin-bottom: 60px;
  font-size: 18px;
  color: #eee;
  text-align: center;
  line-height: 25px;
}
</style>
