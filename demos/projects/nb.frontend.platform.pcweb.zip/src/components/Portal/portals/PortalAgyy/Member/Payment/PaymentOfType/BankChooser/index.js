import BankChooser from './BankChooser'; // eslint-disable-line import/no-unresolved

export default BankChooser;
