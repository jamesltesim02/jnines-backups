import Report from './Report';

export default Report;
