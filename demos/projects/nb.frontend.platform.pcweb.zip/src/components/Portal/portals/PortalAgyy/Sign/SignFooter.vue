<template>
  <div class="agyy-signfooter"><slot /></div>
</template>
<style lang="less">
.agyy-signfooter {
  text-align: center;
  font-size: 16px;
  padding-bottom: 30px;
  a {
    cursor: pointer;
    color: #ff5353;
  }
  a:hover {
    text-decoration: underline;
  }
}
</style>
