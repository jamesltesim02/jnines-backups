import BankItem from './BankItem';

export default BankItem;
