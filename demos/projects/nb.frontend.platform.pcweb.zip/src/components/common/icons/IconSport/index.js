import IconSport from './IconSport';

export default IconSport;
