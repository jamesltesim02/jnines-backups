(function(a,b,c,d,e,f,g,h,i){a[e]||(i=a[e]=function(){(a[e].q=a[e].q||[]).push(arguments)},i.l=1*new Date,i.o=f,
g=b.createElement(c),h=b.getElementsByTagName(c)[0],g.async=1,g.src=d,g.setAttribute("n",e),h.parentNode.insertBefore(g,h)
)})(window,document,"script", "https://widgets.sir.sportradar.com/713ad42ed654599df32c28e1f95b871b/widgetloader", "SIR", {
    theme: false, // using custom theme
    language: "zh"
});
SIR("addWidget", ".sr-widget-1", "match.lmtPlus", {layout: "double", matchId:22439311});