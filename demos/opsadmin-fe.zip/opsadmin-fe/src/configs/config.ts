/** 各种地址配置 */
export const Urls = {
  /** api 接口地址*/
  API: 'http://192.168.166.105:8088/',
};
