import ModifyPassword from './ModifyPassword';

export default ModifyPassword;
