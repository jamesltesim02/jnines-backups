import DatasourcePage from './Datasource';

import './Datasource.less';

export default DatasourcePage;
