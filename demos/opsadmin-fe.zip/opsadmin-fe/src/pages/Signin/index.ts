import SigninPage from './Signin';

import './Signin.less';

export default SigninPage;