import MultipleRepeatableSelect from './MultipleRepeatableSelect';

import './MultipleRepeatableSelect.less';

export default MultipleRepeatableSelect;
