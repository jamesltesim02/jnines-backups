import TasksPage from './Tasks';

import './Tasks.less';

export default TasksPage;
