import AppLayout from './AppLayout';

import './AppLayout.less';

export default AppLayout;
