

export default {
  /** 语言选项 */
  locale: {
    'zh-CN': '简体中文',
    'en-US': 'English',
  },
  appName: '管理系统',
  message: {
    success: '操作成功',
  }
};
