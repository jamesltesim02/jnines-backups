
export default {
  /** 语言选项 */
  locale: {
    'zh-CN': '简体中文',
    'en-US': 'English',
  },
  appName: 'Management System',
  message: {
    success: 'Successful',
  }
};
