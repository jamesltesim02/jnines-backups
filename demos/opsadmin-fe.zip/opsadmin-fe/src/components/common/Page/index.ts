import Page from './Page';

import './Page.less';

export default Page;
