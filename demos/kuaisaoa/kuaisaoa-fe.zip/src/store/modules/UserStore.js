import bus from '@/store/Bus'
import {register, login} from '@/api/user'

const state = {}

const mutations = {
  updateUserInfo(state, user) {
    Object.assign(state,user)
  }
}

const getters = {}

const actions = {
  saveLogedUser({commit},user) {
    commit('updateUserInfo', user)
    commit('changeLoginState', true)
  },
  async login({dispatch}, user) {
    try{
      let logedUser = await login(user)
      dispatch('saveLogedUser', logedUser)
    } catch (e) {
        console.log(e)
    }
  },
  async register({dispatch}, user) {
    try {
        let registedUser = await register(user)
        dispatch('saveLogedUser', registedUser)
    } catch (e) {
        console.log(e)
    }
  }
}

export default {state,mutations,getters,actions}