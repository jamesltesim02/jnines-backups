import bus from '@/store/Bus'

const getLevel = (()=> {
    const gradeMap = {
        100: '青铜',
        300: '白银',
        500: '黄金',
        1000: '黄金',
        2000: '白金',
        5000: '钻石'
    }

    return grade=>{
        let level = "暂无"
        for(let g in gradeMap) {
            if(grade < g)  return level
            level = gradeMap[g]
        }
        return level
    }
})()

const state = {
    username: 'username',
    nickname: '客户',
    gender: 'M',
    birthday: '2008-10-10',
    grade: 0,
    amount: 0,
    registerTime: '2009-02-02'
}
const mutations = {
    addAmount(state, amount) {
        state.amount += amount;
        state.grade += amount;
    },
    subtractAmount(state, amount) {
        if(state.amount< amount) {
            return bus.$emit('toast-message','钱不够')
        }
        state.amount -= amount;
    }
}
const getters = {
    level() {
        return getLevel(state.grade)
    },
    regYears() {
        let now = new Date()
        let regTime = new Date(Date.parse(state.registerTime))
        
        return  Math.max(now.getYear() - regTime.getYear(), 1)
    },
    person() {
        return state;
    }
}
const actions = {
    pay({commit}, amount) {
        setTimeout(()=>commit('addAmount', amount), 500)
    },
    transfer({commit}, amount) {
        setTimeout(()=>commit('subtractAmount',amount), 500)
    }
}

export default {state,mutations,getters,actions}