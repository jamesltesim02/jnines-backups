import Vue from 'vue'
import Vuex from 'vuex'

import bus from '@/store/Bus'
import user from '@/store/modules/UserStore'

Vue.use(Vuex)

const state = {
  loginState: false
}
const mutations = {
  changeLoginState({commit}, loginState) {
    state.loginState = loginState
  }
}
const getters = {}
const actions = {}

export default new Vuex.Store({
  modules: {user},
  state,
  mutations,
  getters,
  actions
});