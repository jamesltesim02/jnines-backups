import axios from "./build-axios";

export async function register(user) {
    return await axios.post('/user/create', user)
}

export async function login(user) {
    return await axios.post('/user/login', user)
}