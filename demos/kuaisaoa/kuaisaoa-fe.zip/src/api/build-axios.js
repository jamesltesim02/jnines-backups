import axios from 'axios'

axios.defaults.timeout = 30000
axios.defaults.baseURL = 'http://localhost:7001'

// TODO 其他前置后置业务处理

// 添加响应拦截器
axios.interceptors.response.use(({data}) => {
    if(data.success) {
        return data.data
    }
    return Promise.reject(data);
  }, error => {
    return Promise.reject(error);
});

export default axios