<template>
    <v-app>
        <router-view/>
    </v-app>
</template>
<script>
import bus from '@/store/Bus'
export default {
    created() {
        this.loginCheck()
    },
    watch: {
        ['$store.state.loginState'](val) {
            this.loginCheck()
        }
    },
    methods: {
        loginCheck() {
            if(!this.$store.state.loginState && '/sign' !== this.$route.fullPath) {
                this.$router.replace('/sign')
                return
            }

            if(this.$store.state.loginState && '/sign' === this.$route.fullPath) {
                this.$router.replace('/')
                return
            }
        }
    }
}
</script>
