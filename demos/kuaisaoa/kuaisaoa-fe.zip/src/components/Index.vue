<template>
  <div class="main-container">
    <v-toolbar dark color="primary">
        <v-toolbar-side-icon></v-toolbar-side-icon>
        <v-spacer>
            <v-toolbar-title class="white--text">Title</v-toolbar-title>
        </v-spacer>
        <v-btn icon><v-icon>search</v-icon></v-btn>
        <v-btn icon><v-icon>add</v-icon></v-btn>
    </v-toolbar>
    <router-view/>
    {{user}} - {{user.username}}
    <v-bottom-nav absolute :value="true" :active.sync="e1" color="transparent">
        <v-btn flat color="primary" value="recent">
            <span>列表</span>
            <v-icon>storage</v-icon>
        </v-btn>
        <v-btn flat color="primary" value="favorites">
            <span>Favorites</span>
            <v-icon>favorite</v-icon>
        </v-btn>
        <v-btn flat color="primary" value="nearby">
            <span>我的</span>
            <v-icon>person</v-icon>
        </v-btn>
    </v-bottom-nav>
  </div>
</template>
<script>
import {mapState} from 'vuex'

export default {
  data () {
    return {
      e1: 'recent'
    }
  },
  computed: {
    ...mapState(['user']),
  }
}
</script>
<style>
.main-container {
  position: relative;
  height: 100%;
  padding-bottom: 56px;
  overflow: auto;
  overflow-x: hidden;
  z-index: 1;
}
.main-container::-webkit-scrollbar {
  width: 0;
  height: 0
}
.main-container .toolbar__title {
  text-align: center;
}
</style>