<template>
<v-form v-model="valid">
  <v-text-field
    label="帐号/邮箱"
    v-model="fields.username"
    :rules="rules.username"
    maxlength="10"
    required />
  <v-text-field
    label="密码"
    v-model="fields.password"
    :rules="rules.password"
    :append-icon="passwordVisiblity ? 'visibility_off' : 'visibility'"
    :append-icon-cb="() => (passwordVisiblity = !passwordVisiblity)"
    :type="passwordVisiblity ? 'text' : 'password'"
    maxlength="12"
    required />
  <v-btn @click="login" block color="info" dark>提交</v-btn>
  <v-btn flat block>忘记密码</v-btn>
</v-form>
</template>
<script>
import {mapActions} from 'vuex'

export default {
  data: () => ({
    valid: false,
    fields: {
      username: 'admin1',
      password: 'admin123456'
    },
    rules: {
    username: [
      v => (v.length >= 4 && v.length <=10) || '帐号必须为4~10位的字符',
      v => /([a-zA-Z]\d)|(\d[a-zA-Z])/.test(v) || '帐号必须同时包含数字和字母'
    ],
    password: [
      v => (v.length >= 6 && v.length <=12) || '密码必须为6~12位的字符',
      v => /([a-zA-Z]\d)|(\d[a-zA-Z])/.test(v) || '密码必须同时包含数字和字母'
    ]
    },
    passwordVisiblity: false
  }),

  methods: {
    ...mapActions(['login']),
    login() {
      this.$store.dispatch('login', {
        username: this.fields.username,
        password: this.fields.password
      })
    }
  }
}
</script>

