<template>
  <v-tabs dark fixed-tabs slider-color="error" color="primary">
    <v-tab color="white">登录</v-tab> 
    <v-tab color="white">注册</v-tab>
    <v-tab-item><Signin/></v-tab-item>
    <v-tab-item><Signup/></v-tab-item>
  </v-tabs>
</template>

<script>
import Signin from './Signin'
import Signup from './Signup'

export default {
  created() {
  },
  data () {
    return {}
  },
  components: {Signin,Signup}
}
</script>

<style>
  form {
    box-sizing: border-box;
    padding: 20px 15px;
    transition: height .5s linear;
  }
</style>
