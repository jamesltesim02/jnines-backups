/*
@Time : 2019/5/28 16:26 
@Author : Lukebryan
@File : sns_plan.go
@Software: GoLand
*/
package api

import (
	"encoding/json"
	"fmt"
	"github.com/kataras/iris/core/errors"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"math/rand"
	"net/http"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type SnsPlan struct {
	Base
}

//保存/发布朋友圈任务
func (s SnsPlan) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	name := r.PostFormValue("name")
	state := r.PostFormValue("state")
	wechatGroupIds := r.PostFormValue("wechat_group_ids")
	startTime := r.PostFormValue("start_time")
	endTime := r.PostFormValue("end_time")

	if id == "" && wechatGroupIds == "" {
		http.Error(w, "微信分组不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewSnsPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	if name != "" {
		m.SetData("name", name)
	}
	if state != "" {
		m.SetData("state", state)
	}
	if startTime != "" {
		m.SetData("start_time", startTime)
	}
	if endTime != "" {
		m.SetData("end_time", endTime)
	}
	if wechatGroupIds != "" {
		m.SetData("wechat_group_ids", wechatGroupIds)
	}

	m.SetData("user_id", s.getCurrentUserId(r))
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}else {
		//发朋友圈
		if id == "" {
			go runMMSnsPost(startTime, endTime, wechatGroupIds, s.getCurrentUserId(r), m.GetId())
		}
		rel, _ := utils.JsonEncode(0, m.GetMap(), "操作成功")
		w.Write(rel)
		return
	}
}

//删除
func (SnsPlan) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("ids")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewSnsPlan()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("SnsPlan Delete Error: ",err)
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}

//计划列表
func (s SnsPlan) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	m, err := models.NewSnsPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()

	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	c.Each(func(item *db.Item) {


		snsItem,_ := models.NewSnsItem()
		snsItems := snsItem.GetCollection()
		snsItems.AddFieldToFilter("sns_plan_id","eq",item.GetId())
		snsItems.Load()

		allCount := len(snsItems.GetItems())
		finishCount := 0
		cancelCount := 0
		failCount := 0
		//状态:0待执行,1执行中,2执行完毕,3失败,4取消
		snsItems.Each(func(item *db.Item) {
			state := item.GetInt("state")
			if state == 2 {
				finishCount ++
			}else if state == 3 {
				failCount ++
			}else if state == 4 {
				cancelCount ++
			}
		})
		waitCount := allCount - finishCount - failCount
		item.SetData("all_count", allCount)
		item.SetData("wait_count",waitCount)
		item.SetData("finish_count", finishCount)
		item.SetData("cancel_count",cancelCount)//取消
		item.SetData("fail_count",failCount)//失败
	})
	s.list(w, c)
}

//发圈详细
func (s SnsPlan) Item(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	planID := r.PostFormValue("plan_id")
	if planID == "" {
		http.Error(w, "朋友圈计划ID不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewSnsItem()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()


	c.AddFieldToFilter("sns_plan_id","eq",planID)
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	var wechatIDs []string
	c.Each(func(item *db.Item) {
		wechatIDs = append(wechatIDs, item.GetString("wechat_id"))
	})
	bindWechat,_ := models.NewBindWechat()
	bindWechats := bindWechat.GetCollection()
	bindWechats.AddFieldToFilter("wechat_id", "in" , strings.Join(wechatIDs,"','"))
	bindWechats.Load()

	bindWechatMap := make(map[string]*db.Item)
	bindWechats.Each(func(item *db.Item) {
		bindWechatMap[item.GetString("wechat_id")] = item
	})

	c.Each(func(item *db.Item) {
		if _,ok := bindWechatMap[item.GetString("wechat_id")];ok {
			wechatItem := bindWechatMap[item.GetString("wechat_id")]
			item.SetData("nickname",wechatItem.GetString("nickname"))
		}else {
			item.SetData("nickname","")
		}

	})
	s.list(w, c)
}

//发朋友圈
func runMMSnsPost(startTime, endTime, wechatGroupIds, userID string, planID int) {
	fmt.Println("准备发朋友圈")

	var rands = rand.New(rand.NewSource(time.Now().Unix()))

	var minute = 0
	if startTime == "" {
		//立刻发
	} else {
		afterMin := utils.GetMinCount(time.Now().Format("15:04"),startTime)
		apartMin := utils.GetMinCount(startTime,endTime)

		randData := 0
		if apartMin > 0 {
			randData = rands.Intn(apartMin)
		}
		minute = afterMin + randData
	}

	fmt.Println("发朋友圈时间",minute,"分钟后")

	time.AfterFunc(time.Minute*cast.ToDuration(minute), func() {
		snsPlan,_ := models.NewSnsPlan()
		snsPlan.Load(cast.ToInt64(planID))
		if snsPlan.GetString("state") == "3"{
			log.Println("已经取消了")
			return
		}

		wechatGroupIds := snsPlan.GetString("wechat_group_ids")
		if wechatGroupIds == "" {
			log.Println("任务已经删除了")
			return
		}
		go saveSnsItem(wechatGroupIds, userID, planID)
	})
}

//保存发朋友圈记录
func saveSnsItem(wechatGroupIds, userID string, planID int) {
	log.Println("wechatGroupIds: ",wechatGroupIds,"userID: ",userID,"planID: ",planID)
	//微信
	wechatGroupIdArr := strings.Split(wechatGroupIds, ",")
	wechat, _ := models.NewBindWechat()
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("group_id", "in", strings.Join(wechatGroupIdArr, "','"))
	wechats.Join("ym_material as dl","m.wechat_id = dl.wechat_id","dl.category_id")
	wechats.Load()

	//微信号
	var wxidList []string
	wechats.Each(func(item *db.Item) {
		wxID := item.GetString("wechat_id")
		wxidList = append(wxidList, wxID)
	})

	isFirst := false
	snsPlan,_ := models.NewSnsPlan()
	snsPlans := snsPlan.GetCollection()
	snsPlans.AddFieldToFilter("wechat_group_ids","eq",wechatGroupIds)
	fmt.Println("snsPlans.GetSize(): ",snsPlans.GetSize() - 1)
	if snsPlans.GetSize()-1 <= 0 {
		isFirst = true
	}

	fmt.Println("isFirst: ",isFirst)

	loginMap := getLoginMap(wxidList,userID,"")
	loopInt := 0
	for i := range wxidList {
		if loginMap[wxidList[i]] != 12007 {
			continue
		}
		//根据微信号获取其所在的素材组
		material,_ := models.NewMaterial()
		materials := material.GetCollection()
		materials.AddFieldToFilter("wechat_id","eq",wxidList[i])
		materials.Load()
		if len(materials.GetItems()) > 0 {
			groupID := materials.GetItems()[0].GetInt64("category_id")
			fmt.Println("groupID: ",groupID)
			materialGroup,_ := models.NewMaterialCategory()
			materialGroup.Load(groupID)
			//朋友圈素材组ID
			snsMaterialGroupID := materialGroup.GetString("sns_material_group_id")

			fmt.Println("snsMaterialGroupID: ",snsMaterialGroupID)

			//朋友圈素材列表
			snsMaterial,_ := models.NewSnsMaterial()
			snsMaterials := snsMaterial.GetCollection()
			snsMaterials.AddFieldToFilter("sns_material_group_id","eq",snsMaterialGroupID)
			snsMaterials.Load()
			snsMaterialItems := snsMaterials.GetItems()

			if len(snsMaterialItems) == 0 {
				log.Println("该素材组没有朋友圈素材")
				continue
			}

			snsMaterialItemMap := make(map[int]*db.Item)
			for j := range snsMaterialItems {
				snsMaterialItemMap[snsMaterialItems[j].GetInt("id")] = snsMaterialItems[j]
			}

			//该组第一次发
			if isFirst {

				newSnsMaterialID := 0
				if i < len(snsMaterialItems) {
					newSnsMaterialID = snsMaterialItems[i].GetInt("id")
				}else {
					if loopInt < len(snsMaterialItems) {
						newSnsMaterialID = snsMaterialItems[loopInt].GetInt("id")
						loopInt ++
					}else {
						loopInt = 0
						newSnsMaterialID = snsMaterialItems[0].GetInt("id")
					}

				}

				fmt.Println("newSnsMaterialID: ",newSnsMaterialID)
				go sendSnsAndSave(userID, wxidList[i],planID, snsMaterialItemMap[newSnsMaterialID])
			}else {
				//上次发送朋友圈使用的朋友圈素材ID
				newSnsMaterialID := 0
				snsItem, _ := models.NewSnsItem()
				snsItems := snsItem.GetCollection()
				snsItems.AddFieldToFilter("wechat_id","eq", wxidList[i])
				snsItems.AddOrder("create_date desc")
				snsItems.Load()
				if len(snsItems.GetItems()) > 0 {
					newSnsMaterialID = snsItems.GetItems()[0].GetInt("sns_material_id")
				}
				//第一次发
				if newSnsMaterialID == 0 {
					newSnsMaterialID = snsMaterialItems[0].GetInt("id")
				}else {
					newID := 0
					for e := range snsMaterialItems {	//1,2
						id := snsMaterialItems[e].GetInt("id")
						fmt.Println("id: ",id,"newSnsMaterialID: ",newSnsMaterialID)
						if id > newSnsMaterialID {	//if 1/2 > 1
							newID = id
							break
						}
					}

					fmt.Println("newID: ",newID)
					if newID == 0 {
						newSnsMaterialID = snsMaterialItems[0].GetInt("id")
					}else {
						newSnsMaterialID = newID
					}
				}
				fmt.Println("newSnsMaterialID22222: ",newSnsMaterialID)
				go sendSnsAndSave(userID, wxidList[i],planID, snsMaterialItemMap[newSnsMaterialID])
			}
		}
	}

	//snsPlan,_ := models.NewSnsPlan()
	snsPlan.Load(cast.ToInt64(planID))
	snsPlan.SetData("state",2)
	if err := snsPlan.Save(); err != nil {
		log.Println("snsPlan save error: ", err)
	}

}

func sendSnsAndSave(userID, wechatID string,planID int, snsMaterial *db.Item) {
	//发送朋友圈
	err := postSns(userID, wechatID, snsMaterial)
	//保存记录
	snsItem, _ := models.NewSnsItem()
	snsItem.SetData("sns_plan_id", planID)
	snsItem.SetData("wechat_id", wechatID)
	snsItem.SetData("sns_material_id", snsMaterial.GetId())
	if err != nil {
		snsItem.SetData("state", 3) //状态:0待执行,1执行中,2执行完毕,3失败,4取消
		snsItem.SetData("msg", err.Error())
	}else {
		snsItem.SetData("state", 2) //状态:0待执行,1执行中,2执行完毕,3失败,4取消
		snsItem.SetData("msg", "Success")
	}
	if err := snsItem.Save(); err != nil {
		log.Println("snsItem save error: ", err)
	}
}

//发送朋友圈
func postSns(userID, wechatID string, snsMaterial *db.Item) error {
	picturePath := snsMaterial.GetString("picture_path")
	content := snsMaterial.GetString("content")
	types := snsMaterial.GetInt("types")
	fmt.Println("picturePath: ",picturePath)
	fmt.Println("types: ",types)
	picturePathArr := strings.Split(picturePath, ",")
	if types == 2{
		if picturePath == "" {
			return errors.New("图片不能为空")
		}
		for i := range picturePathArr {
			changed := utils.ChangeImgMD5(config.Sysconfig.FileSavePath + "/" + picturePathArr[i])
			if !changed {
				log.Println("修改素材MD5失败")
				return errors.New("修改素材MD5失败")
			}
			picturePathArr[i] = config.Sysconfig.LocalhostAddr + "/" + picturePathArr[i]
		}
	}

	dataMap := make(map[string]interface{})
	dataMap["content"] = content
	if types == 2{
		dataMap["img_list"] = strings.Join(picturePathArr, ",")
	}
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wechatID)
	respBody, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/mmsns/mmsnspost", dataMap, heardMap)
	if err != nil {
		log.Println("mmsns/mmsnspost error: ", err)
		return err
	}
	fmt.Println("发送朋友圈返回数据:",respBody)
	respMap := make(map[string]interface{})
	err = json.Unmarshal([]byte(respBody), &respMap)
	if err != nil {
		log.Println("json.Unmarshal Error: ", err)
		return err
	}

	if cast.ToString(respMap["Code"]) == "-1" {
		return errors.New(cast.ToString(respMap["Data"]))
	}
	return nil
}
