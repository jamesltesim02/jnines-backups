/*
@Time : 2019/5/20 10:48 
@Author : Lukebryan
@File : pull_chatroom.go
@Software: GoLand
*/
package api

import (
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"strings"
	"wechatmanagent/models"
	"wechatmanagent/task"
	"wechatmanagent/utils"
)

type PullChatroom struct {
	Base
}

func (s PullChatroom) PlanSave(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	name := r.PostFormValue("name")
	customerID := r.PostFormValue("customer_id")
	startTime := r.PostFormValue("start_time")
	fansType := r.PostFormValue("fans_type")	//粉类型:0原始粉,1通讯录粉
	handleFansID := r.PostFormValue("handle_fans_id")
	runCount := r.PostFormValue("run_count")
	addChatroomPeopleCount := r.PostFormValue("add_count")	//每个群加人数
	userID := s.getCurrentUserId(r)

	if customerID == "" {
		http.Error(w, "客户不能为空", http.StatusBadRequest)
		return
	}
	if addChatroomPeopleCount == "" {
		http.Error(w, "数量不能为空", http.StatusBadRequest)
		return
	}

	pullChatroomPlan,err := models.NewPullChatroomPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	if id != "" {
		pullChatroomPlan.SetId(cast.ToInt64(id))
	}
	if name != "" {
		pullChatroomPlan.SetData("name",name)
	}
	if customerID != "" {
		pullChatroomPlan.SetData("customer_id",customerID)
	}
	if startTime != "" {
		pullChatroomPlan.SetData("start_time",startTime)
	}
	if fansType != "" {
		pullChatroomPlan.SetData("fans_type",fansType)
	}
	if handleFansID != "" {
		pullChatroomPlan.SetData("handle_fans_id",handleFansID)
	}
	if addChatroomPeopleCount != "" {
		pullChatroomPlan.SetData("add_chatroom_people_count",addChatroomPeopleCount)
	}
	if runCount != "" {
		pullChatroomPlan.SetData("run_count",runCount)
	}
	pullChatroomPlan.SetData("user_id",userID)
	err = pullChatroomPlan.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, "操作失败")
		w.Write(rel)
		return
	}

	if fansType == "0" {
		go dealWithOldFriends(userID)
	}

	rel, _ := utils.JsonEncode(0, nil, "操作成功")
	w.Write(rel)

}

func dealWithOldFriends(userID string) {

	wechat,err := models.NewBindWechat()
	if err != nil {
		return
	}
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("user_id","eq",userID)
	wechats.Load()

	var wechatIDs []string
	wechats.Each(func(item *db.Item) {
		wechatIDs = append(wechatIDs, item.GetString("wechat_id"))
	})

	loginMap := getLoginMap(wechatIDs,userID,"")
	wechats.Each(func(item *db.Item) {
		wechatID := item.GetString("wechat_id")
		if loginMap[wechatID] == 12007 {
			task.SaveOldFriends(wechatID,userID)
		}
	})
}


/*
计划开始或取消
 */
func (s PullChatroom) PlanStopOrStart(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	state := r.PostFormValue("state")
	m, err := models.NewPullChatroomPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(cast.ToInt64(id))

	if m.GetString("user_id") == "" {
		rel, _ := utils.JsonEncode(-1, nil, "任务不存在")
		w.Write(rel)
		return
	}
	m.SetData("state",state)
	if err := m.Save();err != nil {
		rel, _ := utils.JsonEncode(-1, nil, "操作失败")
		w.Write(rel)
		return
	}

	if state == "1" {
		startTime := m.GetString("start_time")
		runCount := m.GetInt("run_count")
		fansType := m.GetInt("fans_type")
		useCount := m.GetInt("handle_fans_id") - 1
		if useCount < 0 {
			useCount = 0
		}
		customerID := m.GetInt("customer_id")

		pullChatroom,err := models.NewPullChatroom()
		if err != nil {
			rel, _ := utils.JsonEncode(-1, nil, "操作失败")
			w.Write(rel)
			return
		}
		pullChatrooms := pullChatroom.GetCollection()
		pullChatrooms.AddFieldToFilter("pull_chatroom_plan_id","eq",id)
		pullChatrooms.Load()

		go task.DealWithChatroomData(startTime,runCount,fansType,useCount ,customerID,cast.ToInt(id),pullChatrooms.GetItems())
	}

	rel, _ := utils.JsonEncode(0, nil, "操作成功")
	w.Write(rel)
}

/*
计划删除
 */
func (s PullChatroom) PlanDelete(w http.ResponseWriter, r *http.Request) {
	ids := r.PostFormValue("ids")
	idsArr := strings.Split(ids,",")

	if len(ids) == 0 {
		rel, _ := utils.JsonEncode(-1, nil, "请先选择要删除的行")
		w.Write(rel)
		return
	}

	m, err := models.NewPullChatroomPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(idsArr,"','"))
	c.Load()

	c.Each(func(item *db.Item) {
		err := item.Delete()
		if err != nil {
			log.Println("plan delete error: ",err)
		}
	})

	rel, _ := utils.JsonEncode(0, nil, "操作成功")
	w.Write(rel)
}

/*
计划列表
 */
func (s PullChatroom) PlanList(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	name := r.PostFormValue("name")
	state := r.PostFormValue("state")
	customerID := r.PostFormValue("customer_id")
	fansType := r.PostFormValue("fans_type")	//粉类型:0原始粉,1通讯录粉
	handleFansID := r.PostFormValue("handle_fans_id")
	userID := s.getCurrentUserId(r)

	m, err := models.NewPullChatroomPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()

	//c.AddFieldToSelect("m.*", "")
	//c.AddFieldToSelect("{count(dl.id)} as pcount", "")
	//c.JoinLeft("ym_pull_chatroom as dl", "m.id=dl.pull_chatroom_plan_id", "dl.state")

	if name != "" {
		c.AddFieldToFilter("name","like","%"+name+"%")
	}
	if customerID != "" {
		c.AddFieldToFilter("customer_id","eq",customerID)
	}
	if fansType != "" {
		c.AddFieldToFilter("fans_type","eq",fansType)
	}
	if handleFansID != "" {
		c.AddFieldToFilter("handle_fans_id","eq",handleFansID)
	}
	if state != "" {
		c.AddFieldToFilter("state","eq",cast.ToBool(state))
	}

	c.AddFieldToFilter("user_id","eq",userID)
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}


	//c.AddGroup("dl.state")
	//c.DisableAllFields()

	c.Load()

	var customerIDs []string
	c.Each(func(item *db.Item) {
		customerID := item.GetString("customer_id")
		customerIDs = append(customerIDs, customerID)

	})

	customer,_ := models.NewCustomer()
	customers := customer.GetCollection()
	customers.AddFieldToFilter("id","in",strings.Join(customerIDs,"','"))
	customers.Load()

	customerMaps := make(map[string]*db.Item)
	customers.Each(func(item *db.Item) {
		customerMaps[item.GetString("id")] = item
	})


	pullChatroom,_ := models.NewPullChatroom()
	c.Each(func(item *db.Item) {
		cid := item.GetString("customer_id")
		pullChatrooms := pullChatroom.GetCollection()
		pullChatrooms.AddFieldToFilter("pull_chatroom_plan_id","eq",item.GetId())
		chatroomCount := cast.ToInt(pullChatrooms.GetSize())
		item.SetData("chatroom_count",chatroomCount)

		cus := customerMaps[cid]

		item.SetData("customer_name",cus.GetString("name"))
	})

	s.list(w, c)
}


//群二维码导入
func (s PullChatroom) Save(w http.ResponseWriter, r *http.Request) {
	planID := r.PostFormValue("plan_id")
	codeImgPath := r.PostFormValue("codeimg_path")
	qrcodeFile := r.PostFormValue("qrcode_file")
	
	userID := s.getCurrentUserId(r)
	if codeImgPath == "" {
		http.Error(w, "群二维码不能为空", http.StatusBadRequest)
		return
	}

	qrcodeFileArr := strings.Split(qrcodeFile,"|")
	codeImgPathArr := strings.Split(codeImgPath,",")

	if len(qrcodeFileArr) != len(codeImgPathArr) {
		http.Error(w, "二维码,图片文件名数量不一致", http.StatusBadRequest)
		return
	}
	
	pullChatRoomPlan,err := models.NewPullChatroomPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	pullChatRoomPlan.Load(cast.ToInt64(planID))

	if pullChatRoomPlan.GetString("name") == "" {
		rel, _ := utils.JsonEncode(-1, nil, "拉群计划错误")
		w.Write(rel)
		return
	}
	
	handleFansID := pullChatRoomPlan.GetString("handle_fans_id")
	customerID := pullChatRoomPlan.GetString("customer_id")	//每个群加人数
	addChatroomPeopleCount := pullChatRoomPlan.GetString("add_chatroom_people_count")	//每个群加人数

	go func() {
		for i := range codeImgPathArr{
			m, err := models.NewPullChatroom()
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}

			url := task.GetCodeUrl(codeImgPathArr[i])
			m.SetData("url", url)

			m.SetData("pull_chatroom_plan_id", planID)
			m.SetData("user_id", userID)

			if customerID != "" {
				m.SetData("customer_id", customerID)
			}

			if qrcodeFile != "" {
				m.SetData("qrcode_file", qrcodeFileArr[i])
			}
			if handleFansID != ""{
				m.SetData("handle_fans_id", handleFansID)
			}
			if codeImgPath != "" {
				m.SetData("code_img_path", codeImgPathArr[i])
			}

			if addChatroomPeopleCount != "" {
				m.SetData("add_chatroom_people_count", addChatroomPeopleCount)
			}
			err = m.Save()
			if err != nil {
				log.Println(" pullChatroom save error: ",err)
			}
		}
	}()

	rel, _ := utils.JsonEncode(0, nil, "操作成功")
	w.Write(rel)
	return

}

func (s PullChatroom) Update(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	url := r.PostFormValue("url")

	pullChatroom,err := models.NewPullChatroom()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	pullChatroom.Load(cast.ToInt64(id))

	if pullChatroom.GetString("user_id") == "" {
		rel, _ := utils.JsonEncode(-1, nil, "请刷新后重试")
		w.Write(rel)
		return
	}
	if url == "" {
		rel, _ := utils.JsonEncode(-1, nil, "URL不能为空")
		w.Write(rel)
		return
	}

	pullChatroom.SetData("url",url)

	if err := pullChatroom.Save();err != nil {
		rel, _ := utils.JsonEncode(-1, nil, "修改失败")
		w.Write(rel)
		return
	}

	rel, _ := utils.JsonEncode(0, nil, "修改成功")
	w.Write(rel)
	return
}

//获取二维码url
func (s PullChatroom) CodeUrl(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")

	pullChatroom,err := models.NewPullChatroom()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	pullChatroom.Load(cast.ToInt64(id))

	if pullChatroom.GetString("code_img_path") == "" {
		rel, _ := utils.JsonEncode(-1, nil, "文件已失效")
		w.Write(rel)
		return
	}

	url := task.GetCodeUrl(pullChatroom.GetString("code_img_path"))

	pullChatroom.SetData("url",url)

	if err := pullChatroom.Save();err != nil {
		rel, _ := utils.JsonEncode(-1, nil, "获取失败")
		w.Write(rel)
		return
	}

	rel, _ := utils.JsonEncode(0, nil, "获取成功")
	w.Write(rel)
	return
}

//删除
func (PullChatroom) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewPullChatroom()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("PullChatroom Delete Error: ",err)
			return
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}

func (s PullChatroom) List(w http.ResponseWriter, r *http.Request) {
	create_date := r.PostFormValue("create_date")
	customerID := r.PostFormValue("customer_id")
	planID := r.PostFormValue("plan_id")
	state := r.PostFormValue("state")
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	m, err := models.NewPullChatroom()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	c := m.GetCollection()


	if state != "" {
		c.AddFieldToFilter("state","eq",state)
	}
	if customerID != "" {
		c.AddFieldToFilter("customer_id","eq",customerID)
	}
	if planID != "" {
		c.AddFieldToFilter("pull_chatroom_plan_id","eq",planID)
	}
	if create_date != "" {
		//c.AddFieldToFilter("creat_date","like",creat_date)
		c.AddFieldToFilter("create_date","gt",create_date + " 00:00:00")
		c.AddFieldToFilter("create_date","lt",create_date + " 23:59:59")
	}
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	c.Each(func(item *db.Item) {
		customer,_ := models.NewCustomer()
		customer.Load(item.GetInt64("customer_id"))
		item.SetData("customer",customer.GetMap())

		m, err := models.NewPullChatroomItem()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		c := m.GetCollection()
		c.AddFieldToFilter("pull_chatroom_id","eq",item.GetId())
		c.AddFieldToFilter("state","in",strings.Join(strings.Split("0,1	",","),"','"))
		c.Load()
		item.SetData("now_people_count", len(c.GetItems()))
	})

	s.list(w, c)
}

func (s PullChatroom) Items(w http.ResponseWriter, r *http.Request) {
	pullChatroomID := r.PostFormValue("pull_chatroom_id")
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")

	if pullChatroomID == "" {
		http.Error(w, "拉群ID不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewPullChatroomItem()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	c := m.GetCollection()
	c.AddFieldToFilter("pull_chatroom_id","eq",pullChatroomID)

	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	//c.Each(func(item *db.Item) {
	//})

	s.list(w, c)
}

func (s PullChatroom) QrCode(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	if id == "" {
		http.Error(w, "ID不能为空", http.StatusBadRequest)
		return
	}
	m, err := models.NewPullChatroom()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.SetId(cast.ToInt64(id))
	m.Row()
	rel, _ := utils.JsonEncode(0, m.GetString("code_img_path"), "操作成功")
	w.Write(rel)
	return
}

