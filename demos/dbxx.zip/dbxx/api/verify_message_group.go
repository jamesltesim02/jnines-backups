/*
@Time : 2019/5/16 19:36 
@Author : Lukebryan
@File : verify_message_group.go
@Software: GoLand
*/
package api

import (
	"encoding/json"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"net/http"
	"strconv"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type VerifyMessageGroup struct {
	Base
}

type VerifyMessageStruct struct {
	ID	string
	Message	[]string
}

func (s VerifyMessageGroup) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	name := r.PostFormValue("name")
	state := r.PostFormValue("state")
	types := r.PostFormValue("types")
	//[["0", ["1", "还记得我吗"]],["0", ["2", "先生，你好"]]]
	verifyMessages := r.PostFormValue("verify_message")
	//b,_ := json.Marshal(verifyMessages)
	var verifyMessageArr []interface{}
	json.Unmarshal([]byte(verifyMessages),&verifyMessageArr)

	if id == "" && name == "" {
		http.Error(w, "分组名不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewVerifyMessageGroup()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	if name != "" {
		m.SetData("name", name)
	}
	if state != "" {
		m.SetData("state", state)
	}
	if types != "" {
		m.SetData("types", types)
	}
	m.SetData("user_id", s.getCurrentUserId(r))
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		//保存验证消息
		for i := range verifyMessageArr {
			vm, err := models.NewVerifyMessage()
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}

			vms := VerifyMessageStruct{}
			b,_ := json.Marshal(verifyMessageArr[i])
			json.Unmarshal(b,&vms)

			vmsb,_ := json.Marshal(vms.Message)

			//messageStr := "["
			//for i := range vms.Message{
			//	if i == len(vms.Message)-1 {
			//		messageStr += vms.Message[i] + "]"
			//	}else {
			//		messageStr += vms.Message[i] + " "
			//	}
			//}
			vm.SetData("id", vms.ID)
			vm.SetData("content", string(vmsb))
			vm.SetData("verify_message_group_id", m.GetId())
			err = vm.Save()
			if err != nil {
				rel, _ := utils.JsonEncode(-1, nil, err.Error())
				w.Write(rel)
				return
			}
		}

		rel, _ := utils.JsonEncode(0, m, "操作成功")
		w.Write(rel)
		return
	}
}

func (VerifyMessageGroup) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewVerifyMessageGroup()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.Load(id)

	vm, err := models.NewVerifyMessage()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	vmc := vm.GetCollection()
	vmc.AddFieldToFilter("verify_message_group_id", "eq", id)
	vmc.Load()

	mapArr := vmc.GetMaps()
	for i := range mapArr{
		maps := mapArr[i]
		content := maps["content"]
		var strs []string
		json.Unmarshal([]byte(cast.ToString(content)),&strs)
		//var finalStrs []string
		//for j := range strs{
		//	finalStrs = append(finalStrs, base64.StdEncoding.EncodeToString([]byte(strs[j])))
		//}
		//mapArr[i]["content"] = finalStrs
		mapArr[i]["content"] = strs
	}
	m.SetData("verify_messages",mapArr)
	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (VerifyMessageGroup) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewVerifyMessageGroup()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(id)
	err = m.Delete()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		vm, err := models.NewVerifyMessage()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		//TODO	事务
		vmc := vm.GetCollection()
		vmc.AddFieldToFilter("verify_message_group_id","eq",id)
		vm.SetData("verify_message_group_id",id)
		vmc.Load()
		for i := range vmc.GetItems(){
			id := vmc.GetItems()[i].GetId()
			vm.SetId(cast.ToInt64(id))
			err := vm.Delete()
			if err != nil {
				rel, _ := utils.JsonEncode(-1, nil, err.Error())
				w.Write(rel)
				return
			}
		}

		rel, _ := utils.JsonEncode(0, nil, "删除成功")
		w.Write(rel)
		return
	}
}


func (VerifyMessageGroup) DelOne(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewVerifyMessage()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(id)
	err = m.Delete()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, nil, "删除成功")
		w.Write(rel)
		return
	}
}

func (s VerifyMessageGroup) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	state := r.PostFormValue("state")
	types := r.PostFormValue("types")

	m, err := models.NewVerifyMessageGroup()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()


	if state != "" {
		c.AddFieldToFilter("state","eq",cast.ToBool(state))
	}
	if types != "" {
		c.AddFieldToFilter("types","eq",types)
	}
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	c.Each(func(i *db.Item) {
		vm, err := models.NewVerifyMessage()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		vmc := vm.GetCollection()
		vmc.AddFieldToFilter("verify_message_group_id", "eq", i.GetId())
		vmc.Load()
		i.SetData("vm_count",vmc.GetSize())

	})
	s.list(w, c)
}
