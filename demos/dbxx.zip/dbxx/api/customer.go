/*
@Time : 2019/5/18 16:34 
@Author : Lukebryan
@File : customer.go
@Software: GoLand
*/
package api

import (
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type Customer struct {
	Base
}

func (s Customer) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	name := r.PostFormValue("name")
	state := r.PostFormValue("state")
	remark := r.PostFormValue("remark")

	if id == "" && name == "" {
		http.Error(w, "客户名不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewCustomer()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	if name != ""{
		m.SetData("name", name)
	}
	if remark != ""{
		m.SetData("remark", remark)
	}
	if state != ""{
		m.SetData("state", cast.ToBool(state))
	}
	m.SetData("user_id", s.getCurrentUserId(r))
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {

		rel, _ := utils.JsonEncode(0, m, "操作成功")
		w.Write(rel)
		return
	}
}

func (Customer) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewCustomer()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(id)
	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (s Customer) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	state := r.PostFormValue("state")

	m, err := models.NewCustomer()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()

	if state != "" {
		c.AddFieldToFilter("state","eq",state)
	}
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	c.Each(func(i *db.Item) {

		//handleFansID := i.GetInt("handle_fans_id")
		addFriendPlan,_ := models.NewAddFriendPlan()
		addFriendPlans := addFriendPlan.GetCollection()
		addFriendPlans.AddFieldToSelect("id", "")
		addFriendPlans.AddFieldToFilter("customer_id","eq",i.GetId())
		addFriendPlans.AddFieldToFilter("user_id","eq",i.GetString("user_id"))
		addFriendPlans.Load()

		var addFriendPlanIds []string
		addFriendPlans.Each(func(item *db.Item) {
			addFriendPlanIds = append(addFriendPlanIds, item.GetString("id"))
		})
		addFriendLog,_ := models.NewAddFriendLog()
		addFriendLogs := addFriendLog.GetCollection()
		addFriendLogs.AddFieldToSelect("is_oneway_fans", "")
		addFriendLogs.AddFieldToSelect("used_count", "")
		addFriendLogs.AddFieldToFilter("add_friend_plan_id","in",strings.Join(addFriendPlanIds,"','"))
		addFriendLogs.AddFieldToFilter("state","eq",1)
		addFriendLogs.Load()

		oneWayFansCount := 0
		canPullChatRoomCount := 0
		addFriendLogs.Each(func(item *db.Item) {
			isOnewayFans := item.GetBool("is_oneway_fans")
			usedCount := item.GetInt("used_count")
			if isOnewayFans  {
				oneWayFansCount ++
			}else {
				if usedCount == 0 {
					canPullChatRoomCount ++
				}
			}
		})


		i.SetData("allCount", canPullChatRoomCount + oneWayFansCount)
		i.SetData("canPullChatRoomCount", canPullChatRoomCount)
		i.SetData("oneWayFansCount",oneWayFansCount)

		pullChatroom,_ := models.NewPullChatroom()
		pullChatrooms := pullChatroom.GetCollection()
		pullChatrooms.AddFieldToFilter("customer_id","eq",i.GetId())
		pullChatrooms.Load()


		notFullChatRoomCount := 0	//未拉满群数
		notExportCount := 0	//可导出群数
		pullChatrooms.Each(func(item *db.Item) {
			state := item.GetInt("state")	//拉群任务完成
			needAddCount := item.GetInt("add_chatroom_people_count")	//拉群任务完成
			exported := item.GetBool("exported")	//是否已导出
			if !exported && state == 4{
				notExportCount ++
			}

			pullChatroomItem,_ := models.NewPullChatroomItem()
			pullChatroomItems := pullChatroomItem.GetCollection()
			pullChatroomItems.AddFieldToFilter("pull_chatroom_id","eq",item.GetId())
			pullChatroomSize := pullChatroomItems.GetSize()
			if cast.ToInt(pullChatroomSize) < needAddCount {
				notFullChatRoomCount ++
			}
		})
		
		i.SetData("notFullChatRoomCount",notFullChatRoomCount)
		i.SetData("notExportCount",notExportCount)
	})
	s.list(w, c)
}


func (s Customer) Handlefans(w http.ResponseWriter, r *http.Request) {

	m, err := models.NewHandleFans()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	c.Load()
	s.list(w, c)
}

//报表日志
func (s Customer) ChatRoomLogs(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	m,_ := models.NewPullChatroomExportLog()
	c := m.GetCollection()
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	s.list(w, c)
}

//导出群报表
func (s Customer) ChatRoomExport(w http.ResponseWriter, r *http.Request) {

	customerID := r.PostFormValue("customer_id")
	userID := s.getCurrentUserId(r)
	if customerID == "" {
		rel, _ := utils.JsonEncode(-1, nil, "客户ID不能为空")
		w.Write(rel)
		return
	}

	pullChatroom,_ := models.NewPullChatroom()
	pullChatrooms := pullChatroom.GetCollection()
	pullChatrooms.AddFieldToFilter("customer_id","eq",customerID)
	pullChatrooms.AddFieldToFilter("state","eq",4)
	pullChatrooms.Load()

	chatRoomIdMap := make(map[string][]string)
	var pullChatroomIds []string

	pullChatrooms.Each(func(item *db.Item) {
		exported := item.GetBool("exported")
		if !exported {
			pullChatroomIds = append(pullChatroomIds, item.GetString("id"))
		}
		arr := []string{item.GetString("chatroom_id"),item.GetString("chatroom_name"),item.GetString("add_chatroom_people_count")}
		//arr = append(arr, item.GetString("chatroom_id"))
		//arr = append(arr, item.GetString("chatroom_name"))
		chatRoomIdMap[item.GetString("id")] = arr

	})

	if len(pullChatroomIds) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "没有可导出群")
		w.Write(rel)
		return
	}

	pullChatroomItem,_ := models.NewPullChatroomItem()
	pullChatroomItems := pullChatroomItem.GetCollection()
	pullChatroomItems.AddFieldToFilter("pull_chatroom_id","in",strings.Join(pullChatroomIds,"','"))
	pullChatroomItems.AddFieldToFilter("state","eq",1)
	pullChatroomItems.Load()

	count0Map := make(map[string]int)	//原始成员
	count1Map := make(map[string]int)	//进群成功
	var pullChatroomPhones []string
	pullChatroomItems.Each(func(item *db.Item) {
		pullChatroomID := item.GetString("pull_chatroom_id")
		state := item.GetInt("state")
		pullChatroomPhones = append(pullChatroomPhones, item.GetString("phone"))
		if state == 0 {
			if _,ok := count0Map[pullChatroomID]; !ok {
				count0Map[pullChatroomID] = 1
			}else {
				count0Map[pullChatroomID] = count0Map[pullChatroomID] + 1
			}
		}else if state == 1 {
			if _,ok := count1Map[pullChatroomID]; !ok {
				count1Map[pullChatroomID] = 1
			}else {
				count1Map[pullChatroomID] = count1Map[pullChatroomID] + 1
			}
		}
	})


	strangerWechatInfo,_ := models.NewStrangerWechatInfo()
	strangerWechatInfos := strangerWechatInfo.GetCollection()
	strangerWechatInfos.AddFieldToFilter("phone","in",strings.Join(pullChatroomPhones,"','"))
	//strangerWechatInfo.SetData("phone",item.GetString("phone"))
	strangerWechatInfos.Load()

	phoneSex := make(map[string]string)
	strangerWechatInfos.Each(func(item *db.Item) {
		phoneSex[item.GetString("phone")] = item.GetString("sex")
	})

	pullChatroomItems.Each(func(item *db.Item) {
		pullChatroomID := item.GetString("pull_chatroom_id")
		sex := "男"
		if phoneSex[item.GetString("phone")] == "2" {
			sex = "女"
		}
		item.SetData("sex",sex)
		item.SetData("pull_success_count",count0Map[pullChatroomID])
		item.SetData("old_count",count0Map[pullChatroomID])
		item.SetData("chatroom_id",chatRoomIdMap[item.GetString("pull_chatroom_id")][0])
		item.SetData("chatroom_name",chatRoomIdMap[item.GetString("pull_chatroom_id")][1])
		item.SetData("add_chatroom_people_count",chatRoomIdMap[item.GetString("pull_chatroom_id")][2])
	})


	pullChatroomExportLog,_ := models.NewPullChatroomExportLog()
	pullChatroomExportLog.SetData("customer_id",customerID)
	pullChatroomExportLog.SetData("user_id",cast.ToInt(userID))
	pullChatroomExportLog.SetData("pull_chatroom_ids",strings.Join(pullChatroomIds,","))
	if err := pullChatroomExportLog.Save();err != nil {
		log.Println("pullChatroomExportLog save error: ",err)
	}

	pullChatrooms.Each(func(item *db.Item) {
		exported := item.GetBool("exported")
		if !exported {
			item.SetData("exported",1)
			err := item.Save()
			if err != nil {
				log.Println("pullChatroom save error: ",err)
			}
		}
	})

	rel, _ := utils.JsonEncode(0, pullChatroomItems.GetMaps(), "Success")
	w.Write(rel)
	return
}