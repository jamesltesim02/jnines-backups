/*
@Time : 2019/8/5 15:27 
@Author : Lukebryan
@File : wechat_log.go
@Software: GoLand
*/
package api

import (
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"net/http"
	"strings"
	"wechatmanagent/models"
)

type WechatLog struct {
	Base
}

//微信账号日志列表
func (s WechatLog) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	wechatID := s.getCurrentWxId(r)

	m, err := models.NewWechatLog()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()


	if wechatID != "" {
		c.AddFieldToFilter("from_wechat_id","eq",wechatID)
		c.AddFieldToFilter("to_wechat_id","or eq",wechatID)
	}

	//c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	c.Each(func(item *db.Item) {
		raw := item.GetString("raw")

		//<msg fromusername="wxid_iltchhxm10to22"
		// encryptusername="v1_bd08298434cf8e11fc240d778e8ba34afbf4a1519168be4836906981e22c2be0b84334807a738352d0cb0bbd57f54ef4@stranger"
		// fromnickname="lukebryan" content="你好，我是lukebryan"
		// fullpy="lukebryan" shortpy="LUKEBRYAN" imagestatus="3" scene="15"
		// country="CN" province="Hunan" city="Changsha" sign="666a666" percard="1"
		// sex="1" alias="lukebryan_shehao" weibo="" albumflag="0" albumstyle="0"
		// albumbgimgid="" snsflag="1" snsbgimgid="http://szmmsns.qpic.cn/mmsns/q5OP8DbkrJGic9s9VLAVqiaLzhIG2ficuiaufGUCWOCdeG0BF63OBoAFiauFBqBOuHlXbvlDeT6wvh18/0" snsbgobjectid="13082320940883849363" mhash="e8ab7850adb134c0f3abd99641a6c6ed" mfullhash="e8ab7850adb134c0f3abd99641a6c6ed" bigheadimgurl="http://wx.qlogo.cn/mmhead/ver_1/S3aiaXiaNWQxps4Ts0NNLqJ7C5NPbHDW9FdeP83oKsKEYsggibrKBUNk2nqSOzicyBOBGczFwcLHd9WDFibZ8JhMukbCEzHZbUbXstsHAFyGumibc/0" smallheadimgurl="http://wx.qlogo.cn/mmhead/ver_1/S3aiaXiaNWQxps4Ts0NNLqJ7C5NPbHDW9FdeP83oKsKEYsggibrKBUNk2nqSOzicyBOBGczFwcLHd9WDFibZ8JhMukbCEzHZbUbXstsHAFyGumibc/96" ticket="v2_5feced1fea51e66aeb67e0d7daa8935b69a268450fc682b81b9f6478205a834826f7b4c9803314136b314286d311c59644c9fde38fef4b8890b9387230c2c5ca@stranger" opcode="2" googlecontact="" qrticket="" chatroomusername="" sourceusername="" sourcenickname=""><brandlist count="0" ver="689072354"></brandlist></msg>
		if strings.Index(raw,"content=\"") != -1 {
			raw = raw[strings.Index(raw,"content=\"")+9 : ]
			raw = raw[ : strings.Index(raw,"\"")]
			item.SetData("raw",raw)
		}
	})

	s.list(w, c)
}
