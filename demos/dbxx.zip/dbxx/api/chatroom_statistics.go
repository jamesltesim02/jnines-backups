/*
@Time : 2019/6/14 14:28 
@Author : Lukebryan
@File : chatroom_statistics.go
@Software: GoLand
*/
package api

import (
	"github.com/spf13/cast"
	"net/http"
	"wechatmanagent/models"
)

type ChatroomStatistics struct {
	Base
}

//列表
func (s ChatroomStatistics) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	month := r.PostFormValue("month")
	startTime := r.PostFormValue("start_time")
	endTime := r.PostFormValue("end_time")

	m, err := models.NewChatroomStatistics()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))

	if startTime != "" || endTime != "" {
		if startTime != "" {
			c.AddFieldToFilter("create_date","gteq",startTime)
		}
		if endTime != "" {
			c.AddFieldToFilter("create_date","lteq",endTime+" 23:59:59")
		}
	}else {
		c.AddFieldToFilter("create_date","like",month + "%")
	}

	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	s.list(w, c)
}

