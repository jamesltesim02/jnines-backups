/*
@Time : 2019/5/28 10:58 
@Author : Lukebryan
@File : friends_circle_material.go
@Software: GoLand
*/
package api

import (
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type SnsMaterial struct {
	Base
}

//保存朋友圈素材
func (s SnsMaterial) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	snsMaterialGroupID := r.PostFormValue("group_id")
	content := r.PostFormValue("content")
	types := r.PostFormValue("types")
	state := r.PostFormValue("state")

	if id == "" && content == "" {
		http.Error(w, "内容不能为空", http.StatusBadRequest)
		return
	}
	if id == "" && types == "" {
		http.Error(w, "类型不能为空", http.StatusBadRequest)
		return
	}
	if id == "" && snsMaterialGroupID == "" {
		http.Error(w, "分组ID不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewSnsMaterial()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	if content != "" {
		m.SetData("content", content)
	}
	if types != "" {
		m.SetData("types", types)
	}
	if state != "" {
		m.SetData("state", state)
	}
	if snsMaterialGroupID != "" {
		m.SetData("sns_material_group_id", snsMaterialGroupID)
	}

	m.SetData("user_id", s.getCurrentUserId(r))

	if types == "2" {
		_, ok := r.MultipartForm.File["file"]
		if ok {
			excelPaths, _ := s.uploadFile(r, "file",config.Sysconfig.FileSavePath + "/static/sns/")

			var picturePath []string
			for i := range excelPaths{
				picturePath = append(picturePath, excelPaths[i][2])
			}
			m.SetData("picture_path", strings.Join(picturePath,","))
		}
	}
	err = m.Save()

	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m.GetMap(), "操作成功")
		w.Write(rel)
		return
	}
}

//获取单个
func (SnsMaterial) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewSnsMaterial()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(id)

	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

//删除
func (SnsMaterial) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewSnsMaterial()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("TalkMaterialGroup Delete Error: ",err)
			return
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}
//朋友圈素材列表
func (s SnsMaterial) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	types := r.PostFormValue("types")
	groupID := r.PostFormValue("group_id")
	content := r.PostFormValue("content")

	m, err := models.NewSnsMaterial()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()


	if types != "" {
		c.AddFieldToFilter("types","eq",cast.ToBool(types))
	}
	if groupID != "" {
		c.AddFieldToFilter("sns_material_group_id","eq",groupID)
	}
	if content != "" {
		c.AddFieldToFilter("content","like","%"+content+"%")
	}
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	s.list(w, c)
}



