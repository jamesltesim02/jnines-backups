/*
@Time : 2019/6/2 14:22 
@Author : Lukebryan
@File : wechat_pwd_history.go
@Software: GoLand
*/
package api

import (
	"github.com/spf13/cast"
	"net/http"
	"wechatmanagent/models"
)

type WechatPwdHistory struct {
	Base
}

//修改历史
func (s WechatPwdHistory) List(w http.ResponseWriter, r *http.Request) {
	wechatID := s.getCurrentWxId(r)
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")

	m, err := models.NewWechatPwdHistory()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	c.AddFieldToFilter("wechat_id","eq",wechatID)
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	s.list(w, c)
}

