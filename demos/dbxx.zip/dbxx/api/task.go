package api

import (
	"net/http"
	"strconv"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

//素材
type Task struct {
	Base
}

func (Task) Save(w http.ResponseWriter, r *http.Request) {
	categoryIdStr := r.PostFormValue("category_id")
	name := r.PostFormValue("name")
	startTime := r.PostFormValue("start_time")
	endTime := r.PostFormValue("end_time")
	intervalStr := r.PostFormValue("interval")
	status := r.PostFormValue("status")
	idStr := r.PostFormValue("id")
	params := r.PostFormValue("params")

	if name == "" || categoryIdStr == "" {
		http.Error(w, "类名不能为空", http.StatusBadRequest)
		return
	}

	interval, err := strconv.ParseInt(intervalStr, 10, 64)
	if err != nil {
		interval = 0
	}

	categoryId, err := strconv.ParseInt(categoryIdStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		id = 0
	}

	m, err := models.NewTask()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(id)
	m.SetData("category_id", categoryId)
	m.SetData("name", name)
	m.SetData("start_time", startTime)
	m.SetData("end_time", endTime)
	m.SetData("interval", interval)
	m.SetData("status", status)
	m.SetData("params", params)
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {

		rel, _ := utils.JsonEncode(0, m.GetId(), "创建成功")
		w.Write(rel)
		return
	}
}

func (Task) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewTask()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.Load(id)
	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (Task) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewTask()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(id)
	err = m.Delete()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, nil, "删除成功")
		w.Write(rel)
		return
	}
}

func (t Task) List(w http.ResponseWriter, r *http.Request) {
	pageStr := r.PostFormValue("page")
	sizeStr := r.PostFormValue("size")
	categoryIdStr := r.PostFormValue("category_id")
	categoryId, err := strconv.ParseInt(categoryIdStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	page, err := strconv.ParseInt(pageStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	size, err := strconv.ParseInt(sizeStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewTask()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()

	c.AddFieldToFilter("category_id", "eq", categoryId)
	c.SetPageSize(size)
	c.SetCurPage(page)
	c.Load()
	t.list(w, c)
}
