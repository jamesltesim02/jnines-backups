package api

import (
	"bytes"
	"crypto/tls"
	"fmt"
	"github.com/kataras/iris"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"wechatmanagent/config"
	"wechatmanagent/utils"
)

type Socks struct {
	Base
}

func (s Socks) Import(w http.ResponseWriter, r *http.Request) {
	r.ParseMultipartForm(MultipartFormMaxMemory)
	f := r.MultipartForm.File["socks_txt"]
	if len(f) > 0 {
		buf := new(bytes.Buffer)
		writer := multipart.NewWriter(buf)
		formFile, err := writer.CreateFormFile("socks_txt", f[0].Filename)

		if err != nil {
			log.Println("Create form file failed: %s\n", err)
		}

		srcFile, err := f[0].Open()
		if err != nil {
			log.Println("%Open source file failed: s\n", err)
		}
		defer srcFile.Close()
		_, err = io.Copy(formFile, srcFile)
		if err != nil {
			log.Println("Write to form file falied: %s\n", err)
		}

		//跳过证书验证
		tr := &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
		}
		client := http.Client{Transport:tr}

		contentType := writer.FormDataContentType()
		writer.Close() // 发送之前必须调用Close()以写入结尾行

		req,err  :=http.NewRequest(http.MethodPost,config.Sysconfig.WechatServerAddr+"/socks/import",buf)
		if err != nil {
			rel, _ := utils.JsonEncode(-1, nil, err.Error())
			w.Write(rel)
			return
		}

		req.Header.Set("Authorization",utils.GentToken(s.getCurrentUserId(r),s.getCurrentWxId(r)))
		//req.Header.Set("Connection", "close")
		//req.Header.Set("Pragma", "no-cache")
		req.Header.Set("Content-Type", contentType)
		req.ContentLength = int64(buf.Len())
		//处理返回结果
		response, err := client.Do(req)
		defer response.Body.Close()

		resultStr, err := ioutil.ReadAll(response.Body)

		log.Println("request path: ",config.Sysconfig.WechatServerAddr+"/socks/import","--------request resp: ",string(resultStr))

		if err != nil {
			log.Println(err)
		}
		w.Write([]byte(resultStr))
	} else {
		rel, _ := utils.JsonEncode(-1, nil, "文件不能为空")
		w.Write(rel)
	}
}

func (s Socks) Save(w http.ResponseWriter, r *http.Request) {
	ip := r.PostFormValue("ip")
	socksPort := r.PostFormValue("socks_port")
	httpPort := r.PostFormValue("http_port")
	username := r.PostFormValue("username")
	password := r.PostFormValue("password")
	statusStr := r.PostFormValue("status")
	cityID := r.PostFormValue("city_id")
	idStr := r.PostFormValue("id")

	if ip == "" {
		http.Error(w, "ip不能为空", http.StatusBadRequest)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["ip"] = ip
	dataMap["socks_port"] = socksPort
	dataMap["http_port"] = httpPort
	dataMap["username"] = username
	dataMap["password"] = password
	dataMap["status"] = statusStr
	dataMap["city_id"] = cityID
	dataMap["id"] = idStr
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(s.getCurrentUserId(r),s.getCurrentWxId(r))
	resp, _ := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/socks/save",dataMap,heardMap)
	w.Write([]byte(resp))
}

func (s Socks) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	dataMap := make(map[string]interface{})
	dataMap["id"] = idStr
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(s.getCurrentUserId(r),s.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/socks/get",dataMap,heardMap)
	if err != nil {
		log.Println("socks/get Error: ",err)
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	w.Write([]byte(resp))
}

func (s Socks) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	dataMap := make(map[string]interface{})
	dataMap["id"] = idStr
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(s.getCurrentUserId(r),s.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/socks/del",dataMap,heardMap)
	if err != nil {
		log.Println("socks/del Error: ",err)
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	w.Write([]byte(resp))
}

func (s Socks) List(w http.ResponseWriter, r *http.Request) {
	pageStr := r.PostFormValue("page")
	sizeStr := r.PostFormValue("size")

	dataMap := make(map[string]interface{})
	dataMap["page"] = pageStr
	dataMap["size"] = sizeStr
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(s.getCurrentUserId(r),s.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/socks/list",dataMap,heardMap)
	if err != nil {
		log.Println("socks/list Error: ",err)
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	w.Write([]byte(resp))
}


func (s Socks) Address(w http.ResponseWriter, r *http.Request) {
	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(s.getCurrentUserId(r),s.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/socks/address",dataMap,heardMap)
	if err != nil {
		log.Println("socks/address Error: ",err)
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	w.Write([]byte(resp))
}

func (s Socks) Export(cxt iris.Context) {
	r := cxt.Request()
	w := cxt.ResponseWriter()
	r.ParseForm()

	userID := r.FormValue("userid")

	fmt.Println("userID: ",userID)

	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,"")

	resp, err := utils.GetFormRequest(config.Sysconfig.WechatServerAddr+"/socks/export",dataMap,heardMap)
	if err != nil {
		log.Println("socks/export Error: ",err)
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	w.Write([]byte(resp))
}

func (s Socks) Deldisable(w http.ResponseWriter, r *http.Request) {
	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(s.getCurrentUserId(r),s.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/socks/deldisable",dataMap,heardMap)
	if err != nil {
		log.Println("socks/deldisable Error: ",err)
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	w.Write([]byte(resp))
}