package api

import (
	"bytes"
	"crypto/tls"
	"encoding/base64"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/utils"
)

type Sns struct {
	Base
}

//发送朋友圈
func (s Sns) MMSnsPost(w http.ResponseWriter, r *http.Request) {
	content := r.PostFormValue("content")
	syncFlagStr := r.PostFormValue("sync_flag")
	imgListStr := r.PostFormValue("img_list")
	videoListStr := r.PostFormValue("video_list")
	withUserListStr := r.PostFormValue("with_user_list")
	blackListStr := r.PostFormValue("black_list")
	groupListStr := r.PostFormValue("group_list")

	syncFlag := false
	if syncFlagStr == "1" {
		syncFlag = true
	}

	withUserList := strings.Split(withUserListStr, ",")
	blackList := strings.Split(blackListStr, ",")
	groupList := strings.Split(groupListStr, ",")
	imgList := [][]byte{}
	if imgListStr != "" {
		for _, item := range strings.Split(imgListStr, ",") {
			if strings.HasPrefix(item, "http") {
				res, err := http.Get(item)
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
				data, _ := ioutil.ReadAll(res.Body)
				imgList = append(imgList, data)
			} else {
				data, err := ioutil.ReadFile(item)
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
				imgList = append(imgList, data)
			}
		}
	} else {
		err := r.ParseMultipartForm(MultipartFormMaxMemory)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		imgs := r.MultipartForm.File["img_list"]
		for _, img := range imgs {
			f, err := img.Open()
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}

			data, _ := ioutil.ReadAll(f)
			imgList = append(imgList, data)
		}
	}

	videoList := []string{}
	timestemp := time.Now().UnixNano()
	if videoListStr != "" {
		for i, item := range strings.Split(videoListStr, ",") {
			data, err := base64.StdEncoding.DecodeString(item)
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}

			tmpFile := fmt.Sprintf("/var/tmp/%d_%d.mp4", timestemp, i)
			err = ioutil.WriteFile(tmpFile, data, 0755)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}

			videoList = append(videoList, tmpFile)
		}
	} else {
		paths, errs := s.saveFile(r, "video_list", VideoDir)
		for i, err := range errs {
			if err != nil {
				log.Println(err)
				continue
			}

			videoList = append(videoList, paths[i])
		}
	}

	if content == "" {
		http.Error(w, "内容不能为空", http.StatusBadRequest)
		return
	}

	isLogined := s.isLogined(r,s.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["content"] = content
	dataMap["sync_flag"] = syncFlag
	dataMap["img_list"] = imgList
	dataMap["video_list"] = videoList
	dataMap["with_user_list"] = withUserList
	dataMap["black_list"] = blackList
	dataMap["group_list"] = groupList
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(s.getCurrentUserId(r),s.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/mmsnspost",dataMap,heardMap)
	//resp, err := cli.MMSnsPost(content, syncFlag, imgList, videoList, withUserList, blackList, groupList)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	} else {
		//res, _ := utils.JsonEncode(0, resp, "更新成功")
		//w.Write(res)
		w.Write([]byte(resp))
	}
}

//更新朋友圈背景图
func (a Sns) Modifysnsbackgroud(w http.ResponseWriter, r *http.Request) {
	err := r.ParseMultipartForm(MultipartFormMaxMemory)
	f, ok := r.MultipartForm.File["background"]
	if !ok {
		rel, _ := utils.JsonEncode(-1, nil, "图片文件不能为空")
		w.Write(rel)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	buf := new(bytes.Buffer)
	writer := multipart.NewWriter(buf)
	formFile, err := writer.CreateFormFile("background", f[0].Filename)
	if err != nil {
		log.Println("Create form file failed: ", err)
	}

	srcFile, err := f[0].Open()
	if err != nil {
		log.Println("Open failed: ", err)
	}
	defer srcFile.Close()
	_, err = io.Copy(formFile, srcFile)
	if err != nil {
		log.Println("Copy failed: ", err)
	}

	//跳过证书验证
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	client := http.Client{Transport:tr}
	contentType := writer.FormDataContentType()
	writer.Close() // 发送之前必须调用Close()以写入结尾行

	req,err  :=http.NewRequest(http.MethodPost,config.Sysconfig.WechatServerAddr+"/mmsns/modifysnsbackgroud",buf)
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	req.Header.Set("Authorization",utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r)))
	req.Header.Set("Content-Type", contentType)
	req.ContentLength = int64(buf.Len())
	//处理返回结果
	response, err := client.Do(req)
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	defer response.Body.Close()

	resultStr, err := ioutil.ReadAll(response.Body)
	if err != nil {
		log.Println(err)
	}
	w.Write(resultStr)
}