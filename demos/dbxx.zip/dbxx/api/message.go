package api

import (
	"encoding/base64"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type Message struct {
	Base
}

//发送动态表情
func (m Message) SendEmoji(w http.ResponseWriter, r *http.Request) {
	toWxid := r.PostFormValue("to_wxid")
	emojiMd5 := r.PostFormValue("emoji_md5")
	if toWxid == "" || emojiMd5 == "" {
		http.Error(w, "微信id和emojiMd5不能为空", http.StatusBadRequest)
	}

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["to_wxid"] = toWxid
	dataMap["emoji_md5"] = emojiMd5
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/message/sendemoji",dataMap,heardMap)
	//rel := cli.SendEmojiMessage(toWxid, emojiMd5)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, "发送失败")
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(0, nil, "发送成功")
		w.Write(res)
	}
}

func (m Message) SendVoice(w http.ResponseWriter, r *http.Request) {
	toWxid := r.PostFormValue("to_wxid")
	voiceData, err := base64.StdEncoding.DecodeString(r.PostFormValue("voice_data"))

	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
	}

	if toWxid == "" {
		http.Error(w, "微信id不能为空", http.StatusBadRequest)
		return
	}

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}
	//发送语音消息
	dataMap := make(map[string]interface{})
	dataMap["to_wxid"] = toWxid
	dataMap["voice_data"] = voiceData
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	_, err = utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/message/sendvoice",dataMap,heardMap)
	//_, err = cli.SendVoiceMessage(toWxid, voiceData, len(voiceData))
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(0, nil, "发送成功")
		w.Write(res)
	}
}

//单发消息
func (m Message) SendMessage(w http.ResponseWriter, r *http.Request) {
	toWxid := r.PostFormValue("to_wxid")
	content := r.PostFormValue("content")

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["to_wxid"] = toWxid
	dataMap["content"] = content
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/message/sendmessage",dataMap,heardMap)
	//code, _ := cli.Short_NewSendMsg(toWxid, content, nil, 1)
	if err == nil {
		res, _ := utils.JsonEncode(0, nil, "发送成功")
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(-1, nil, "发送失败")
		w.Write(res)
	}
}

//群发信息
func (m Message) MassSend(w http.ResponseWriter, r *http.Request) {
	wxidList := r.PostFormValue("wxid_list")
	content := r.PostFormValue("content")
	ids := strings.Split(wxidList, ",")
	if len(ids) == 0 || content == "" {
		http.Error(w, "微信id或内容不能为空", http.StatusBadRequest)
		return
	}

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["wxid_list"] = wxidList
	dataMap["content"] = content
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/message/masssend",dataMap,heardMap)
	//_, err := cli.MassSend(ids, content)
	if err == nil {
		res, _ := utils.JsonEncode(0, nil, "发送成功")
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	}
}

func (ms Message) List(w http.ResponseWriter, r *http.Request) {
	pageStr := r.PostFormValue("page")
	sizeStr := r.PostFormValue("size")
	belongWxid := r.PostFormValue("belong_wxid")

	page, err := strconv.ParseInt(pageStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	size, err := strconv.ParseInt(sizeStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewWechatMessage()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	if belongWxid != "" {
		c.AddFieldToFilter("belong_wxid", "eq", belongWxid)
	}

	c.SetPageSize(size)
	c.SetCurPage(page)
	c.Load()
	ms.list(w, c)
}
