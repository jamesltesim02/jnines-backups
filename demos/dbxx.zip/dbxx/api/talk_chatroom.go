/*
@Time : 2019/6/24 15:22 
@Author : Lukebryan
@File : talk_chatroom.go
@Software: GoLand
*/
package api

import (
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/task"
	"wechatmanagent/utils"
)

type TalkChatroom struct {
	Base
}

//保存
func (s TalkChatroom) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	state := r.PostFormValue("state")
	startTime := r.PostFormValue("start_time")
	chatroomName := r.PostFormValue("chatroom_name")
	_, ok := r.MultipartForm.File["file"]
	if id == "" && !ok {
		rel, _ := utils.JsonEncode(-1, nil, "数据文件不能为空")
		w.Write(rel)
		return
	}
	imgPaths := [][3]string{}
	errs := []error{}
	if ok {
		imgPaths, errs = s.uploadFile(r, "file",config.Sysconfig.FileSavePath + "/static/qrcode/")

		if len(errs) > 0 {
			rel, _ := utils.JsonEncode(-1, nil, "上传失败")
			w.Write(rel)
			return
		}
	}
	fmt.Println("imgPaths: ",imgPaths)

	m, err := models.NewTalkChatroom()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	if ok {
		m.SetData("code_img_path", imgPaths[0][2])
		m.SetData("qrcode_file", imgPaths[0][0])
	}
	wechatID := ""
	userID := s.getCurrentUserId(r)
	if id == "" {
		wechat,_ := models.NewBindWechat()
		wechats := wechat.GetCollection()
		wechats.AddFieldToFilter("user_id","eq",userID)
		wechats.Load()

		var wechatIDs []string
		wechats.Each(func(item *db.Item) {
			wechatIDs = append(wechatIDs, item.GetString("wechat_id"))
		})

		loginMap := getLoginMap(wechatIDs,userID,s.getCurrentWxId(r))


		for k,v := range loginMap{
			if v == 12007 {
				wechatID = k
				break
			}
		}

		if wechatID == "" {
			rel, _ := utils.JsonEncode(-1, nil, "没有登录了的微信号")
			w.Write(rel)
			return
		}

		roomID,err := task.QrcodeIntoRoom(userID,"",imgPaths[0][2],wechatID)
		if err != nil {
			rel, _ := utils.JsonEncode(-1, nil, "机器人进群失败")
			w.Write(rel)
			return
		}
		if roomID == "" {
			rel, _ := utils.JsonEncode(-1, nil, "获取群ID失败")
			w.Write(rel)
			return
		}
		m.SetData("chatroom_id", roomID)
	}

	if state != "" {
		m.SetData("state", state)
	}
	if startTime != "" {
		m.SetData("start_time", startTime)
	}
	if chatroomName != "" {
		m.SetData("chatroom_name", chatroomName)
	}

	m.SetData("user_id", userID)
	err = m.Save()

	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		//保存该机器人到机器人群关联表
		wechatChatRoom,_ := models.NewWechatChatroom()
		wechatChatRoom.SetData("wechat_id",wechatID)
		wechatChatRoom.SetData("talk_chatroom_id",m.GetId())
		err = wechatChatRoom.Save()
		if err != nil {
			log.Println(err)
		}

		//机器人进群,并聊天
		go func() {
			id := m.GetId()
			startTime := m.GetString("start_time")
			codeImgPath := m.GetString("code_img_path")
			chatroomID := m.GetString("chatroom_id")
			roomID := m.GetString("chatroom_id")

			//获取群原始成员列表
			membersMapArr := task.GetChatroomMembers(userID, roomID, wechatID)

			canIntoCount := 100 - len(membersMapArr)

			//机器人进群
			intoChatRoom(userID,codeImgPath,id, canIntoCount)

			time.AfterFunc(time.Second * 10, func() {
				wc,_ := models.NewWechatChatroom()
				wcs := wc.GetCollection()
				wcs.AddFieldToFilter("talk_chatroom_id","eq",id)
				wcs.Load()

				var inRoomWechatIDs []string
				wcMaps := make(map[string]string)
				wcs.Each(func(i *db.Item) {
					wxID := i.GetString("wechat_id")
					inRoomWechatIDs = append(inRoomWechatIDs, wxID)
					wcMaps[wxID] = chatroomID
				})
				waitTime := utils.GetMinCount(time.Now().Format("15:04"),startTime)
				fmt.Println("机器人群聊任务: ",cast.ToString(waitTime),"分钟后开始")
				task.AotoTalk(userID,inRoomWechatIDs,wcMaps,waitTime)
			})
		}()

		rel, _ := utils.JsonEncode(0, m.GetMap(), "操作成功")
		w.Write(rel)
		return
	}
}

func intoChatRoom(userID,codeImgPath string,talkChatroomID ,canIntoCount int) {

	//没有入群微信号
	notInChatRoomWechats := getNotInChatRoomWechats(userID,talkChatroomID)

	var wechatIDs []string
	for i := range notInChatRoomWechats {
		wechatIDs = append(wechatIDs, notInChatRoomWechats[i].GetString("wechat_id"))
	}

	loginMap := getLoginMap(wechatIDs,userID,"")

	//本次扫码进群人
	var finalWechatIDs []string
	for k, v := range loginMap {
		if v == 12007 {
			if len(finalWechatIDs) <= canIntoCount {
				finalWechatIDs = append(finalWechatIDs, k)
			}else {
				break
			}
		}
	}

	for i := range finalWechatIDs {
		roomID,err := task.QrcodeIntoRoom(userID,"",codeImgPath, finalWechatIDs[i])
		if err != nil {
			log.Println("扫码进群失败")
			return
		}
		if strings.Index(roomID,"@chatroom") == -1 {
			return
		}
		fmt.Println("机器人扫码进群的roomID: ",roomID)
		wc2,_ := models.NewWechatChatroom()
		wc2.SetData("wechat_id",finalWechatIDs[i])
		wc2.SetData("talk_chatroom_id",talkChatroomID)
		if err := wc2.Save(); err != nil{
			log.Println("WechatChatroom save error: ",err)
			return
		}
	}
}

//获取没有入群的微信号
func getNotInChatRoomWechats(userID string,talkChatroomID int) []*db.Item {
	var inChatRoomWechats []string
	wc,_ := models.NewWechatChatroom()
	wcs := wc.GetCollection()
	wcs.AddFieldToFilter("talk_chatroom_id","eq",talkChatroomID)
	wcs.Load()

	wechatMap := make(map[string]string)
	wcs.Each(func(item *db.Item) {
		wechatMap[item.GetString("wechat_id")] = item.GetString("talk_chatroom_id")
	})

	for k := range wechatMap {
		inChatRoomWechats = append(inChatRoomWechats, k)
	}

	wechat,_ := models.NewBindWechat()
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("wechat_id","nin",strings.Join(inChatRoomWechats,"','"))
	wechats.Load()
	return wechats.GetItems()
}

//获取单个
func (TalkChatroom) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewTalkChatroom()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(id)

	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

//删除
func (TalkChatroom) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewTalkChatroom()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("TalkMaterialGroup Delete Error: ",err)
			return
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}
//列表
func (s TalkChatroom) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	chatroomName := r.PostFormValue("chatroom_name")
	userID := s.getCurrentUserId(r)
	m, err := models.NewTalkChatroom()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()


	if chatroomName != "" {
		c.AddFieldToFilter("chatroom_name","like","%"+chatroomName+"%")
	}
	c.AddFieldToFilter("user_id","eq",userID)
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	c.Each(func(item *db.Item) {
		roomID := item.GetString("chatroom_id")
		id := item.GetId()
		wechatID := ""
		count := 0

		wechatChatroom,_ := models.NewWechatChatroom()
		wechatChatrooms := wechatChatroom.GetCollection()
		wechatChatrooms.AddFieldToFilter("talk_chatroom_id","eq",id)
		wechatChatrooms.AddOrder("id desc")
		wechatChatrooms.SetPageSize(2)
		wechatChatrooms.SetCurPage(1)
		wechatChatrooms.Load()
		if len(wechatChatrooms.GetItems()) > 1 {
			item := wechatChatrooms.GetItems()[0]
			wechatID = item.GetString("wechat_id")
		}

		if wechatID != "" {
			membersMapArr := task.GetChatroomMembers(userID, roomID, wechatID)
			count = len(membersMapArr)
		}

		item.SetData("wechat_count",count)
	})
	s.list(w, c)
}
