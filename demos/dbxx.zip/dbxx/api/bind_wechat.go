package api

import (
	"encoding/json"
	"github.com/kataras/iris"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

//微信机器人
type BindWechat struct {
	Base
}

func (b BindWechat) Save(w http.ResponseWriter, r *http.Request) {
	groupIdStr := r.PostFormValue("group_id")
	wechatId := r.PostFormValue("wechat_id")
	wechatPassword := r.PostFormValue("wechat_password")
	wechatName := r.PostFormValue("wechat_name")
	loginDeviceData := r.PostFormValue("login_device_data") //这是附加json数据，比如昵称和签名之类
	idStr := r.PostFormValue("id")

	if wechatId == "" || groupIdStr == "" {
		http.Error(w, "类名不能为空", http.StatusBadRequest)
		return
	}

	groupId, err := strconv.ParseInt(groupIdStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		id = 0
	}

	m, err := models.NewBindWechat()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	m.SetId(id)
	if groupId != 0 {
		m.SetData("group_id", groupId)
	}
	if wechatId != "" {
		m.SetData("wechat_id", wechatId)
	}
	if b.getCurrentUserId(r) != "" {
		m.SetData("user_id", b.getCurrentUserId(r))
	}
	if wechatPassword != "" {
		m.SetData("wechat_password", wechatPassword)
	}
	if loginDeviceData != "" {
		m.SetData("login_device_data", loginDeviceData)
	}
	if wechatName != "" {
		m.SetData("wechat_name", wechatName)
	}

	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m.GetId(), "创建成功")
		w.Write(rel)
		return
	}
}

func (BindWechat) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewBindWechat()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	m.Load(id)
	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (BindWechat) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("ids")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewBindWechat()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("BindWechat Delete Error: ",err)
			return
		}

		//TODO 删除V1V2表数据,加人记录数据,回收加人数据(data表数据)
		//回收站
		go saveBindWechatsBack(item)
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}

func (b BindWechat) List(w http.ResponseWriter, r *http.Request) {
	pageStr := r.PostFormValue("page")
	sizeStr := r.PostFormValue("size")
	groupIdStr := r.PostFormValue("group_id")
	state := r.PostFormValue("state")
	order := r.PostFormValue("order")
	wechatAlias := r.PostFormValue("wechat_alias")
	wechatMobile := r.PostFormValue("wechat_mobile")
	groupId, err := strconv.ParseInt(groupIdStr, 10, 64)
	if err != nil {
		groupId = 0
	}

	page, err := strconv.ParseInt(pageStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	size, err := strconv.ParseInt(sizeStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewBindWechat()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	c := m.GetCollection()
	c.AddFieldToSelect("*", "m")
	c.AddFieldToSelect("{(select count(ym_wechat_friends.id) from ym_wechat_friends where belong_wxid=m.wechat_id and contact_type=0)} as friends", "")
	if groupId > 0 {
		c.AddFieldToFilter("group_id", "eq", groupId)
	}

	var allWechatID []string
	d := m.GetCollection()
	d.AddFieldToFilter("user_id","eq",b.getCurrentUserId(r))
	d.Load()
	d.Each(func(item *db.Item) {
		allWechatID = append(allWechatID, item.GetString("wechat_id"))
	})

	if state != "" {

		if state == "0" {	//离线
			maps := getLoginMap(allWechatID,b.getCurrentUserId(r),b.getCurrentWxId(r))
			var unLoginWechats []string
			for k,v := range maps{
				if v == 0 {
					unLoginWechats = append(unLoginWechats, k)
				}
			}
			c.AddFieldToFilter("wechat_id", "in", strings.Join(unLoginWechats,"','"))
			c.AddFieldToFilter("status", "eq", 1)
		}else if state == "-10001" {	//密码错误
			c.AddFieldToFilter("status", "eq", -10001)
		}else if state == "12008" {		//账号异常
			c.AddFieldToFilter("status", "eq", 2)
		}else {		//其他
			dataMap := make(map[string]interface{})
			dataMap["state"] = state

			heardMap := make(map[string]string)
			heardMap["Authorization"] = utils.GentToken(b.getCurrentUserId(r),b.getCurrentWxId(r))
			resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/filterlistbystate",dataMap,heardMap)
			//buf, err := cli.Login()
			if err != nil {
				log.Println(err)
			}
			resultMap := make(map[string]interface{})
			json.Unmarshal([]byte(resp),&resultMap)
			var wxIds []string
			b,_ := json.Marshal(resultMap["Data"])
			json.Unmarshal(b,&wxIds)

			c.AddFieldToFilter("wechat_id", "in", strings.Join(wxIds,"','"))
		}
	}

	if order != "" {
		c.AddOrder(order)
	}

	if wechatAlias != "" {
		c.AddFieldToFilter("wechat_alias", "like", "%"+wechatAlias+"%")
	}

	if wechatMobile != "" {
		c.AddFieldToFilter("wechat_mobile", "like", "%"+wechatMobile+"%")
	}

	c.AddFieldToFilter("user_id", "eq", b.getCurrentUserId(r))
	c.SetPageSize(size)
	c.SetCurPage(page)
	c.AddOrder("last_login_date desc")
	c.Load()
	ids := make([]string, 0, c.GetSize())
	c.Each(func(item *db.Item) {
		ids = append(ids, item.GetString("wechat_id"))
	})
	addFriendLog,_ := models.NewAddFriendLog()
	addFriendLogs := addFriendLog.GetCollection()
	addFriendLogs.AddFieldToSelect("{count(id)} as fans", "m")
	addFriendLogs.AddFieldToSelect("wechat_id", "m")
	addFriendLogs.AddFieldToFilter("wechat_id", "in", strings.Join(ids, "','"))
	addFriendLogs.AddFieldToFilter("state", "eq", 1)
	addFriendLogs.AddGroup("wechat_id")
	addFriendLogs.Load()

	addFriendLogItems := addFriendLogs.GetItems()
	c.Each(func(item *db.Item) {
		item.SetData("fans_count", 0)
		for i := range addFriendLogItems {
			if item.GetString("wechat_id") == addFriendLogItems[i].GetString("wechat_id") {
				item.SetData("fans_count", addFriendLogItems[i].GetInt("fans"))
				break
			}
		}

		title := ""
		material,_ := models.NewMaterial()
		materials := material.GetCollection()
		materials.AddFieldToFilter("wechat_id","eq",item.GetString("wechat_id"))
		materials.Join("ym_material_category as dl","dl.id = m.category_id","dl.title")
		materials.Load()
		//fmt.Println("materialGroupName: ",materials)
		if len(materials.GetItems()) > 0 {
			title = materials.GetItems()[0].GetString("title")
		}

		item.SetData("title", title)
	})

	b.list(w, c)
}

//解绑素材
func (b BindWechat) BindMaterial(w http.ResponseWriter, r *http.Request) {
	wechatIDs := r.PostFormValue("wechat_ids")
	wechatIDArr := strings.Split(wechatIDs,",")
	materialCategoryID := r.PostFormValue("group_id")	//素材组ID

	material,err := models.NewMaterial()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	//绑定
	if materialCategoryID != "" {
		materials := material.GetCollection()
		materials.AddFieldToFilter("wechat_id","in",strings.Join(wechatIDArr,"','"))
		if materials.GetSize() > 0 {
			rel, _ := utils.JsonEncode(-1, nil, "请选择没有绑定素材的账号")
			w.Write(rel)
			return
		}
		materials2 := material.GetCollection()
		materials2.AddFieldToFilter("category_id","eq",materialCategoryID)
		materials2.AddFieldToFilter("wechat_id","null","")
		materials2.Load()
		materials2Items := materials2.GetItems()
		if len(materials2.GetItems()) == 0 {
			rel, _ := utils.JsonEncode(-1, nil, "没有可绑定素材")
			w.Write(rel)
			return
		}

		for i := range wechatIDArr {
			if i < len(materials2Items) {
				finalMaterial := materials2Items[i]
				finalMaterial.SetData("wechat_id",wechatIDArr[i])
				if err := finalMaterial.Save(); err != nil {
					log.Println("materials2 save error: ",err)
				}
			}else {
				break
			}
		}


	}else {
		//解绑

		materials := material.GetCollection()
		materials.AddFieldToFilter("wechat_id","in",strings.Join(wechatIDArr,"','"))
		materials.Load()
		if len(materials.GetItems()) > 0 {
			materials.Each(func(item *db.Item) {
				item.SetData("wechat_id",nil)
				if err := item.Save(); err != nil {
					log.Println("materials save error: ",err)
				}
			})

		}else {
			rel, _ := utils.JsonEncode(-1, nil, "账号没有绑定素材")
			w.Write(rel)
			return
		}
	}

	rel, _ := utils.JsonEncode(0, nil, "操作成功")
	w.Write(rel)
	return
}

func (BindWechat) DelFailWechats(w http.ResponseWriter, r *http.Request) {

	m, err := models.NewBindWechat()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	statusArr := []string{"-10001","2"}

	c := m.GetCollection()
	c.AddFieldToFilter("status","in",strings.Join(statusArr,"','"))
	c.Load()
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			log.Println("DelFailWechats error: ",err)
			return
		}

		//回收站
		go saveBindWechatsBack(item)
	})

	rel, _ := utils.JsonEncode(0, nil, "删除成功")
	w.Write(rel)
	return
}

//导出http://localhost:8848/api/v1/bindwechat/exportlog?type=0&id=1
func (BindWechat) ExportLog(cxt iris.Context) {
	r := cxt.Request()
	w := cxt.ResponseWriter()
	r.ParseForm()

	types := r.FormValue("type")
	id := r.FormValue("id")
	loginLog,_ := models.NewLoginLog()
	loginLogs := loginLog.GetCollection()
	loginLogs.AddFieldToFilter("wechat_file_id","eq",id)
	if types == "0" {
		loginLogs.AddFieldToFilter("state","neq","12007")
		//status := []string{"",""}
		//loginLogs.AddFieldToFilter("state","in",strings.Join(strings.Split(status,","),"','"))
	}else {
		loginLogs.AddFieldToFilter("state","eq","12007" )
	}
	loginLogs.Load()

	name := cast.ToString(time.Now().UnixNano())+".txt"
	fileSavePath := config.Sysconfig.FileSavePath+"/static/save/"
	exist, _ := PathExists(fileSavePath)
	if !exist {
		err := os.MkdirAll(fileSavePath, os.ModePerm)
		if err != nil {
			log.Printf("mkdir failed![%v]\n", err)
			rel, _ := utils.JsonEncode(-1, nil, err.Error())
			w.Write(rel)
			return
		}
	}
	file, error := os.Create(fileSavePath+name)
	if error != nil {
		log.Println(error)
		rel, _ := utils.JsonEncode(-1, nil, error.Error())
		w.Write(rel)
		return
	}

	items := loginLogs.GetItems()

	for i := range items{
		lineContent := items[i].GetString("data") + "\r\n"
		file.WriteString(lineContent)
	}
	file.Close()


	a:=cxt.ResponseWriter()
	a.Header().Set("Content-Disposition", "attachment; filename=\""+name+"\"")
	a.Header().Set("Content-Type", "application/octet-stream")
	err := cxt.SendFile(fileSavePath+name, name)
	if err != nil {
		log.Println(err)
	}
}