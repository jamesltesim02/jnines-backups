/*
@Time : 2019/5/17 16:01 
@Author : Lukebryan
@File : import_file.go
@Software: GoLand
*/
package api

import (
	"encoding/json"
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"github.com/tealeg/xlsx"
	"log"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type ImportDataStruct struct {
	WechatID string
	Name string
	OtherData string
}

type ImportFile struct {
	Base
}
func (s ImportFile) Update(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	state := r.PostFormValue("state")

	if id == "" {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewImportFile()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	if state != "" {
		m.SetData("state",cast.ToBool(state))
	}
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, "修改失败")
		w.Write(rel)
		return
	}
	rel, _ := utils.JsonEncode(0, nil, "修改成功")
	w.Write(rel)
}

func (s ImportFile) Import(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	name := r.PostFormValue("name")

	f, ok := r.MultipartForm.File["file"]
	if !ok {
		rel, _ := utils.JsonEncode(-1, nil, "数据文件不能为空")
		w.Write(rel)
		return
	}



	excelPaths, _ := s.uploadFile(r, "file",config.Sysconfig.FileSavePath + "/static/excel/")

	srcFile, err := f[0].Open()
	if err != nil {
		log.Println("Open source file failed:  ", err)
		rel, _ := utils.JsonEncode(-1, nil, "Open source file failed:  "+ err.Error())
		w.Write(rel)
		return
	}
	defer srcFile.Close()

	m, err := models.NewImportFile()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	//name := f[0].Filename
	//name = name[0:strings.LastIndex(name,".")]
	m.SetData("name", name)
	m.SetData("file_path", excelPaths[0][2])
	m.SetData("data_type", "自定义数据")

	//获取所有已导入的手机号
	allDataMap := make(map[string]string)
	allImportFile,_ := models.NewImportFile()
	allImportFiles := allImportFile.GetCollection()
	allImportFiles.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	allImportFiles.Load()
	allImportFiles.Each(func(item *db.Item) {
		allImportData,_ := models.NewImportData()
		allImportDatas := allImportData.GetCollection()
		allImportDatas.AddFieldToFilter("import_file_id","eq",item.GetId())
		allImportDatas.Load()
		allImportDatas.Each(func(i *db.Item) {
			allDataMap[i.GetString("wechat_id")] = i.GetString("name")
		})
	})


	data_count := 0

	log.Println(excelPaths[0][2])
	//内容解析
	xlFile, err := xlsx.OpenFile(config.Sysconfig.FileSavePath + "/" + excelPaths[0][2])
	if err != nil {
		log.Printf("Open Failed: %s\n", err)
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}


	dataType := make([]string,0)
	for _, sheet := range xlFile.Sheets {
		for i,row := range sheet.Rows {
			if i != 0 {
				data_count ++
			}
			for j := 0;j< len(row.Cells);j++ {
				text := row.Cells[j].String()
				dataType = append(dataType, text)
			}
		}
	}

	m.SetData("user_id",s.getCurrentUserId(r))
	m.SetData("data_count", data_count)
	m.SetData("log_info", "数据导入完成")
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, "ImportFile Save failed:"+err.Error())
		w.Write(rel)
		return
	}



	go func() {

		needImportData := make(map[string]ImportDataStruct)

		for _, sheet := range xlFile.Sheets {
			//log.Printf("Sheet Name: %s\n", sheet.Name)
			for i, row := range sheet.Rows {		//行

				if i == 0 {
					//导入变量
					for j := 2;j< len(row.Cells);j++  {
						text := row.Cells[j].String()
						moveMessageType,_ := models.NewMoveMessageType()
						exist := moveMessageType.IsExisted(text)
						if !exist {
							moveMessageType.SetData("name",text)
							moveMessageType.Save()
						}
					}
				}else {
					var importDataStruct ImportDataStruct
					//fmt.Println("保存数据。。。。。。。。。。")
					//importData,_ := models.NewImportData()
					otherDataMap := make(map[string]string)
					//导入数据
					for i, cell := range row.Cells {		//列
						text := cell.String()
						//log.Printf("%s\n", text)
						if i == 0 {
							importDataStruct.WechatID = text
							//importData.SetData("wechat_id",text)
						}else if i == 1 {
							importDataStruct.Name = text
							//importData.SetData("name",text)
						}else {
							otherDataMap[dataType[i]] = text
						}
					}
					b, err := json.Marshal(otherDataMap)
					if err != nil {
						log.Println("json.Marshal failed:", err)
						continue
					}
					importDataStruct.OtherData = string(b)
					//importData.SetData("other_data",string(b))
					//importData.SetData("import_file_id",m.GetId())
					//err = importData.Save()
					//if err != nil {
					//	log.Println("ImportData Save Error: ",err)
					//	continue
					//}

					needImportData[importDataStruct.WechatID] = importDataStruct
				}
			}
		}

		for k, v := range needImportData {
			//该用户下没有导入过
			if _,ok := allDataMap[k]; !ok {
				importData,_ := models.NewImportData()
				importData.SetData("wechat_id",v.WechatID)
				importData.SetData("name",v.Name)
				importData.SetData("other_data",v.OtherData)
				importData.SetData("import_file_id",m.GetId())
				err = importData.Save()
				if err != nil {
					log.Println("ImportData Save Error: ",err)
					continue
				}
			}

		}
	}()

	rel, _ := utils.JsonEncode(0, m, "操作成功,已在后台运行")
	w.Write(rel)
	return

}

func (ImportFile) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewImportFile()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.Load(id)
	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (s ImportFile) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	userID := s.getCurrentUserId(r)
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	userdMap := getUsedImportFileIDsMap(userID,[]string{})

	if userdMap[idStr] != 0 {
		rel, _ := utils.JsonEncode(-1, nil, "不能删除已执行任务的数据")
		w.Write(rel)
		return
	}

	m, err := models.NewImportFile()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(id)
	err = m.Delete()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		md, err := models.NewImportData()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		//TODO	事务
		mdc := md.GetCollection()
		mdc.AddFieldToFilter("import_file_id","eq",id)
		mdc.Load()
		for i := range mdc.GetItems(){
			id := mdc.GetItems()[i].GetId()
			md.SetId(cast.ToInt64(id))
			err := md.Delete()
			if err != nil {
				log.Println("ImportData delete error: ",err)
				continue
			}
		}
		rel, _ := utils.JsonEncode(0, nil, "删除成功")
		w.Write(rel)
		return
	}
}

func (s ImportFile) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	state := r.PostFormValue("state")

	m, err := models.NewImportFile()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()

	if state != "" {
		c.AddFieldToFilter("state","eq",cast.ToBool(state))
	}
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	// SELECT count(idata.id), addlog.state as lstate from ym_import_data as idata
	// left join ym_add_friend_log as addlog
	// on idata.wechat_id=addlog.add_phone
	// where idata.import_file_id = 59 group by lstate;
	c.Each(func(i *db.Item) {
		//共13648，待加0，已加13648(通过136，待通过13512)，无效0，失败0
		//导入数据量
		//importData,_ := models.NewImportData()
		//importDatas := importData.GetCollection()
		//importDatas.AddFieldToSelect("wechat_id", "m")
		//importDatas.AddFieldToSelect("{count(id) as pcount}", "")
		//importDatas.AddFieldToFilter("import_file_id","eq",i.GetId())
		//importDatas.JoinLeft("ym_add_friend_log as dl", "m.wechat_id=dl.add_phone", "dl.state")
		//importDatas.AddGroup("dl.state")
		//importDatas.Load()
		importData,_ := models.NewImportData()

		importDatas := importData.GetCollection()
		importDatas.AddFieldToSelect("{count(m.id)} as pcount", "")
		importDatas.AddFieldToFilter("import_file_id","eq",i.GetId())
		importDatas.JoinLeft("ym_add_friend_log as dl", "m.wechat_id=dl.add_phone", "dl.state")
		importDatas.AddGroup("dl.state")
		importDatas.DisableAllFields()
		importDatas.Load()

		allCount := 0
		passCount := 0	//通过数量
		waitPassCount := 0	//待通过数量
		failCount := 0		//失败数量
		invalidCount := 0	//无效数量
		for _, countItem := range importDatas.GetItems() {
			allCount+= countItem.GetInt("pcount")
			if countItem.GetInt("state") == 1 {
				passCount+= countItem.GetInt("pcount")
			}else if countItem.GetInt("state") == 2{
				waitPassCount+= countItem.GetInt("pcount")
			}else if countItem.GetInt("state") == 3{
				failCount+= countItem.GetInt("pcount")
			}else if countItem.GetInt("state") == 4{
				invalidCount += countItem.GetInt("pcount")
			}
		}

		i.SetData("all_count",allCount)
		i.SetData("waitadd_count",allCount-passCount-waitPassCount-invalidCount-failCount)
		i.SetData("pass_count",passCount)
		i.SetData("waitpass_count",waitPassCount)
		i.SetData("invalid_count",invalidCount)
		i.SetData("fail_count",failCount)
	})

	s.list(w, c)
}

//合并
func (s ImportFile) Merge(w http.ResponseWriter, r *http.Request) {
	ids := r.PostFormValue("ids")
	name := r.PostFormValue("name")
	userID := s.getCurrentUserId(r)
	arr := strings.Split(ids,",")

	usedMap := getUsedImportFileIDsMap(userID,[]string{"1","2"})

	for i := range arr {
		if usedMap[arr[i]] != 0 {
			rel, _ := utils.JsonEncode(-1, nil, "不能合并已在执行任务中的数据")
			w.Write(rel)
			return
		}
	}

	//phonev1v2,err := models.NewPhoneV1v2()
	//if err != nil {
	//	rel, _ := utils.JsonEncode(-1, nil, err.Error())
	//	w.Write(rel)
	//	return
	//}
	//phonev1v2s := phonev1v2.GetCollection()

	importFile,err := models.NewImportFile()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	importFile.SetData("name",name)
	importFile.SetData("user_id",userID)
	importFile.SetData("data_type","自定义数据")
	importFile.SetData("data_count",0)
	importFile.SetData("log_info","合并完成")
	if err := importFile.Save();err != nil {
			rel, _ := utils.JsonEncode(-1, nil, err.Error())
			w.Write(rel)
			return
	}

	importData,_ := models.NewImportData()
	importDatas := importData.GetCollection()
	importDatas.AddFieldToSelect("m.*", "")
	importDatas.AddFieldToFilter("m.import_file_id","in",strings.Join(arr,"','"))
	importDatas.Join("ym_add_friend_log as dl", "m.wechat_id=dl.add_phone", "dl.state as distate")
	importDatas.Load()
	fmt.Println(importDatas)

	//加过的人
	usedDataIDs := make(map[string]int)
	importDatas.Each(func(item *db.Item) {
		id := item.GetString("id")
		usedDataIDs[id] = 1
	})

	fmt.Println("usedDataIDs: ",usedDataIDs)

	importDatas2 := importData.GetCollection()
	importDatas2.AddFieldToFilter("import_file_id","in",strings.Join(arr,"','"))
	importDatas2.Load()

	fmt.Println(importDatas2)

	importDatas2.Each(func(item *db.Item) {
		id := item.GetString("id")
		if usedDataIDs[id] == 1 {
			return
		}
		fmt.Println("save ",id)
		item.SetData("import_file_id",importFile.GetId())
		if err := item.Save();err != nil {
			log.Println("importdata save error: ",err)
		}
	})

	//_,err = importData.GetAdapter().Exec("update ym_import_data set import_file_id = "+
	//	importFile.GetString("id")+" where id not in ("+
	//	strings.Join(usedDataIDs,",")+") and import_file_id in ("+strings.Join(arr,",")+")")
	//if err != nil {
	//	log.Println("ym_import_data update error: ",err)
	//}
	//fmt.Println("update ym_import_data set import_file_id = "+
	//	importFile.GetString("id")+" where id not in ("+
	//	strings.Join(usedDataIDs,",")+") and import_file_id in ("+strings.Join(arr,",")+")")

	rel, _ := utils.JsonEncode(0, nil, "合并成功")
	w.Write(rel)
	return
}


func getUsedImportFileIDsMap(userID string,states []string) (map[string]int) {
	importFileIDMaps := make(map[string]int)
	addFriendPlan,err := models.NewAddFriendPlan()
	if err != nil {
		return importFileIDMaps
	}
	addFriendPlans := addFriendPlan.GetCollection()
	addFriendPlans.AddFieldToFilter("user_id","eq",userID)
	if len(states) > 0 {
		addFriendPlans.AddFieldToFilter("state","in",strings.Join(states,"','"))
	}
	addFriendPlans.Load()
	addFriendPlanItems := addFriendPlans.GetItems()

	for i := range addFriendPlanItems {
		dataGroupIds := addFriendPlanItems[i].GetString("data_group_ids")
		arr := strings.Split(dataGroupIds,",")
		for e := range arr {
			importFileIDMaps[arr[e]] = 1
		}
	}

	return importFileIDMaps
}

