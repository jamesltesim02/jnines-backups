package api

import (
	"encoding/json"
	"fmt"
	"github.com/kataras/iris"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/task"
	"wechatmanagent/utils"
)

type BindWechatGroup struct {
	Base
}

func (s BindWechatGroup) Create(w http.ResponseWriter, r *http.Request) {
	groupName := r.PostFormValue("group_name")
	groupName = strings.Trim(groupName," ")
	if groupName == "" {
		rel, _ := utils.JsonEncode(-1, nil, "组名不能为空")
		w.Write(rel)
		return
	}

	b, err := models.NewBindWechatGroup()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	b.SetData("group_name", groupName)
	b.SetData("user_id", s.getCurrentUserId(r))
	err = b.Add()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, b.GetId(), "创建成功")
		w.Write(rel)
		return
	}
}

//批量普通登录
func (b BindWechatGroup) BatchLogin(w http.ResponseWriter, r *http.Request) {
	groupID := r.PostFormValue("group_id")

	if groupID == ""{
		rel, _ := utils.JsonEncode(-1, nil, "分组ID不能为空")
		w.Write(rel)
		return
	}

	wechat,_ := models.NewBindWechat()
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("group_id","eq",groupID)
	wechats.Load()
	var wechatIDs []string
	wechats.Each(func(item *db.Item) {
		wechatIDs = append(wechatIDs, item.GetString("wechat_id"))
	})
	loginMap := getLoginMap(wechatIDs,b.getCurrentUserId(r),"")

	wechats.Each(func(item *db.Item) {
		if item.GetString("wechat_password") == "" {
			return
		}
		if loginMap[item.GetString("wechat_id")] != 12007 {
			go login(item)
		}
	})

	rel, _ := utils.JsonEncode(0, nil, "登录成功")
	w.Write(rel)
	return
}

func login(item *db.Item) {
	dataMap := make(map[string]interface{})
	dataMap["wxid"] = item.GetString("wechat_id")
	dataMap["password"] = item.GetString("wechat_password")

	sixData := item.GetString("android_device_data")
	deviceType := 2
	if sixData == "" {
		sixData = item.GetString("login_device_data")
		deviceType = 1
	}
	dataMap["device_type"] = deviceType
	dataMap["six_data"] = sixData
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(item.GetString("user_id"),item.GetString("wechat_id"))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/login",dataMap,heardMap)
	if err != nil {
		log.Println("account/login error: ",err)
		return
	}else {
		task.Subcribe(item.GetString("wechat_id"),item.GetString("user_id"))
	}

	resultMap := make(map[string]interface{})
	err = json.Unmarshal([]byte(resp),&resultMap)
	if err != nil {
		log.Println("Unmarshal error: ",err)
		return
	}
	if cast.ToString(resultMap["Code"]) == "-1" {
		log.Println(item.GetString("wechat_id"),"登录失败!")
	}
}

//批量注销
func (b BindWechatGroup) BatchLoginout(w http.ResponseWriter, r *http.Request) {

	groupID := r.PostFormValue("group_id")
	if groupID == ""{
		rel, _ := utils.JsonEncode(-1, nil, "分组ID不能为空")
		w.Write(rel)
		return
	}

	wechat,_ := models.NewBindWechat()
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("group_id","eq",groupID)
	wechats.Load()

	var items []*db.Item
	wechats.Each(func(item *db.Item) {
		dataMap := make(map[string]interface{})
		heardMap := make(map[string]string)
		heardMap["Authorization"] = utils.GentToken(item.GetString("user_id"),item.GetString("wechat_id"))
		resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/logout",dataMap,heardMap)
		if err != nil {
			log.Println("account/logout error: ",err)
			items = append(items, item)
			return
		}
		resultMap := make(map[string]interface{})
		err = json.Unmarshal([]byte(resp),&resultMap)
		if err != nil {
			log.Println("Unmarshal error: ",err)
			items = append(items, item)
			return
		}
		if cast.ToString(resultMap["Code"]) == "-1" {
			items = append(items, item)
		}
	})
	reMap := make([]map[string]interface{}, len(items))
	for i := range items {
		reMap[i] = items[i].GetMap()
	}
	rel, _ := utils.JsonEncode(0, reMap, "注销成功")
	w.Write(rel)
	return
}

//合并
func (b BindWechatGroup) Merge(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	groupID := r.PostFormValue("group_id")
	types :=  r.PostFormValue("types")//0所有/1登陆了的/2未登陆的
	count :=  cast.ToInt(r.PostFormValue("count"))

	if id == "" {
		rel, _ := utils.JsonEncode(-1, nil, "请选择要合并的分组")
		w.Write(rel)
		return
	}
	if groupID == "" {
		rel, _ := utils.JsonEncode(-1, nil, "请选择微信分组")
		w.Write(rel)
		return
	}
	
	//获取微信组微信
	//目标微信
	wechat,_ := models.NewBindWechat()
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("group_id","eq",id)
	wechats.Load()


	var allWechats []string
	var loginedWechats []string
	var unLoginWechats []string

	if types != "" {
		var wxidArr []string
		wechats.Each(func(item2 *db.Item) {
			wxidArr = append(wxidArr, item2.GetString("wechat_id"))
		})

		dataMap := make(map[string]interface{})
		dataMap["wxid_list"] = strings.Join(wxidArr,",")
		heardMap := make(map[string]string)
		heardMap["Authorization"] = utils.GentToken(b.getCurrentUserId(r),b.getCurrentWxId(r))
		data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/batchcheckloginstatus",dataMap,heardMap)

		if err != nil {
			log.Println("batchcheckloginstatus List Error1: ",err)
		}

		maps := make(map[string]interface{})
		err = json.Unmarshal([]byte(data),&maps)
		if err != nil {
			log.Println("batchcheckloginstatus List Error2: ",err)
		}

		dataMaps := make(map[string]int)
		b,_ := json.Marshal(maps["Data"])
		err = json.Unmarshal(b,&dataMaps)
		if err != nil {
			log.Println("batchcheckloginstatus List Error3: ",err)
		}

		for k, v := range dataMaps {
			allWechats = append(allWechats, k)
			if v == 12007 {
				loginedWechats = append(loginedWechats, k)
			}else {
				unLoginWechats = append(unLoginWechats , k)
			}
		}
	}

	var finalWechats []string
	if types == "0" {
		for i := range allWechats {
			finalWechats = append(finalWechats, allWechats[i])
		}
	}else if types == "1" {
		for i := range loginedWechats {
			finalWechats = append(finalWechats, loginedWechats[i])
		}
	}else {
		for i := range unLoginWechats {
			finalWechats = append(finalWechats, unLoginWechats[i])
		}
	}

	if count != 0 && count > len(finalWechats) {
		rel, _ := utils.JsonEncode(-1, nil, "目标数量大于确定数量")
		w.Write(rel)
		return
	}

	var changeWechats []string
	if count != 0 {
		for i := 0;i < count; i++ {
			changeWechats = append(changeWechats, finalWechats[i])
		}
	}else {
		changeWechats = finalWechats
	}

	log.Println("changeWechats: ",changeWechats)
	wechats.Each(func(item *db.Item) {
		for i := 0;i < len(changeWechats); i++ {
			if item.GetString("wechat_id") == changeWechats[i] {
				item.SetData("group_id",groupID)
				err := item.Save()
				if err != nil{
					log.Println("wechat save error: ",err)
					return
				}
			}
		}
	})

	rel, _ := utils.JsonEncode(0, nil, "合并成功")
	w.Write(rel)
	return
}

func (BindWechatGroup) Update(w http.ResponseWriter, r *http.Request) {
	groupName := r.PostFormValue("group_name")
	groupName = strings.Trim(groupName," ")
	//if groupName == "" {
	//	rel, _ := utils.JsonEncode(-1, nil, "组名不能为空")
	//	w.Write(rel)
	//	return
	//}
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	statusStr := r.PostFormValue("status")
	status, err := strconv.ParseInt(statusStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	b, err := models.NewBindWechatGroup()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	b.SetId(id)
	if groupName != "" {
		b.SetData("group_name", groupName)
	}
	if statusStr != "" {
		b.SetData("status", status)
	}
	err = b.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, b.GetId(), "修改成功")
		w.Write(rel)
		return
	}
}

func (BindWechatGroup) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	b, err := models.NewBindWechatGroup()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	b.Load(id)
	rel, _ := utils.JsonEncode(0, b.GetMap(), "")
	w.Write(rel)
}

func (BindWechatGroup) Del(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	if id == "" {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewBindWechatGroup()
	c := m.GetCollection()
	c.AddFieldToFilter("id","eq",id)
	c.Load()

	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			log.Println("BindWechatGroup Delete Error: ",err)
			return
		}

		wechat, _ := models.NewBindWechat()
		wechats := wechat.GetCollection()
		wechats.AddFieldToFilter("group_id","eq",item.GetId())
		wechats.Load()
		wechats.Each(func(i *db.Item) {
			err = i.Delete()
			if err != nil {
				log.Println("BindWechat Delete Error: ",err)
				return
			}

			//回收站
			go saveBindWechatsBack(i)


		})
	})

	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, nil, "删除成功")
		w.Write(rel)
		return
	}
}



func saveBindWechatsBack(i *db.Item) {
	backData(i)

	userID := i.GetString("user_id")
	wechatID := i.GetString("wechat_id")

	//释放未返回的V1V2及importdata
	go deletePhoneV1v2(userID,wechatID)

	//释放绑定的微信素材
	go deleteWechatBindMaterial(userID,wechatID)

	bindWechatsBack,err := models.NewBindWechatsBack()
	if err != nil {
		log.Println("bindWechatsBack init error: ",err)
	}
	bindWechatsBack.SetData("user_id",userID)
	bindWechatsBack.SetData("wechat_id",wechatID)
	bindWechatsBack.SetData("wechat_password",i.GetString("wechat_password"))
	bindWechatsBack.SetData("socks_ip",i.GetString("socks_ip"))
	bindWechatsBack.SetData("wechat_alias",i.GetString("wechat_alias"))
	bindWechatsBack.SetData("wechat_mobile",i.GetString("wechat_mobile"))
	bindWechatsBack.SetData("nickname",i.GetString("nickname"))
	bindWechatsBack.SetData("sex",i.GetInt("sex"))
	bindWechatsBack.SetData("signature",i.GetString("signature"))
	bindWechatsBack.SetData("country",i.GetString("country"))
	bindWechatsBack.SetData("province",i.GetString("province"))
	bindWechatsBack.SetData("city",i.GetString("city"))
	bindWechatsBack.SetData("small_headimg_url",i.GetString("small_headimg_url"))
	bindWechatsBack.SetData("group_id",i.GetInt("group_id"))
	bindWechatsBack.SetData("verify_friend_switch",i.GetInt("verify_friend_switch"))
	bindWechatsBack.SetData("last_login_date",i.GetString("last_login_date"))
	bindWechatsBack.SetData("wechat_token",i.GetString("wechat_token"))
	bindWechatsBack.SetData("login_device_data",i.GetString("login_device_data"))
	bindWechatsBack.SetData("status",i.GetInt("status"))
	bindWechatsBack.SetData("android_device_data",i.GetString("android_device_data"))
	bindWechatsBack.SetData("wechat_file_id",i.GetInt("wechat_file_id"))
	bindWechatsBack.SetData("create_date",i.GetString("create_date"))
	if err := bindWechatsBack.Save();err != nil {
		log.Println("bindWechatsBack save error: ",err)
	}
}

//释放绑定的微信素材
func deleteWechatBindMaterial(userID,wechatID string) {
	if wechatID == "" {
		return
	}

	material, _ := models.NewMaterial()
	d := material.GetCollection()
	d.AddFieldToFilter("wechat_id", "eq", wechatID)
	d.AddFieldToFilter("user_id", "eq", userID)
	d.Load()

	if d.GetSize() > 0 {
		d.Each(func(item *db.Item) {
			item.SetData("wechat_id",nil)
			if err := item.Save();err != nil {
				log.Println("material save error: ",err)
			}
		})
	}

}

//释放未返回的V1V2及importdata
func deletePhoneV1v2(userID,wechatID string) {
	if userID == "" || wechatID == "" {
		return
	}

	phoneV1V2,err := models.NewPhoneV1v2()
	if err != nil {
		log.Println("phonev1v2 init error: ",err)
		return
	}
	phoneV1V2s := phoneV1V2.GetCollection()
	phoneV1V2s.AddFieldToFilter("user_id","eq",userID)
	phoneV1V2s.AddFieldToFilter("wechat_id","eq",wechatID)
	phoneV1V2s.AddFieldToFilter("state","lt",4)
	phoneV1V2s.Load()
	phoneV1V2s.Each(func(item *db.Item) {
		if err := item.Delete();err != nil {
			log.Println("phoneV1V2 delete error: ",err)
		}
	})

	var addPhones []string
	phoneV1V2s.Each(func(item *db.Item) {
		addPhones = append(addPhones, item.GetString("add_phone"))
	})

	//回收数据表
	importData,err := models.NewImportData()
	if err != nil {
		log.Println("importData init error: ",err)
		return
	}
	importDatas := importData.GetCollection()
	_,err = importDatas.GetAdapter().Exec("update ym_import_data set state = 0 " +
		"where wechat_id in ('"+strings.Join(addPhones,"','")+"')")
	if err != nil {
		log.Println("ym_import_data update 0 error: ",err)
	}

}

func backData(item *db.Item) {
	wechatID := item.GetString("wechat_id")

	phonev1v2,err := models.NewPhoneV1v2()
	if err != nil {
		log.Println("phonev1v2 init error: ",err)
		return
	}
	phonev1v2s := phonev1v2.GetCollection()
	phonev1v2s.AddFieldToFilter("wechat_id","eq",wechatID)
	phonev1v2s.Load()

	var addPhones []string
	phonev1v2s.Each(func(phonev1v2item *db.Item) {
		addPhones = append(addPhones, phonev1v2item.GetString("add_phone"))
	})

	addPhonesStr := strings.Join(addPhones,"','")

	//V1V2表删除
	phonev1v2s.Each(func(phonev1v2item *db.Item) {
		if err := phonev1v2item.Delete();err != nil {
			log.Println("phonev1v2item delete error: ",err)
		}
	})
	//加人历史记录表删除
	//addFriendLog,err := models.NewAddFriendLog()
	//if err == nil {
	//	addFriendLogs := addFriendLog.GetCollection()
	//	addFriendLogs.AddFieldToFilter("wechat_id","eq",wechatID)
	//	addFriendLogs.Load()
	//	addFriendLogs.Each(func(addFriendLogitem *db.Item) {
	//		if err := addFriendLogitem.Delete();err != nil {
	//			log.Println("addFriendLogitem delete error: ",err)
	//		}
	//	})
	//}

	//回收数据表
	importData,err := models.NewImportData()
	if err != nil {
		log.Println("importData init error: ",err)
		return
	}
	importDatas := importData.GetCollection()
	_,err = importDatas.GetAdapter().Exec("update ym_import_data set state = 0 " +
		"where wechat_id in ('"+addPhonesStr+"')")
	if err != nil {
		log.Println("ym_import_data update 0 error: ",err)
	}
}

func (bw BindWechatGroup) List(w http.ResponseWriter, r *http.Request) {
	online := r.PostFormValue("online")
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	status := r.PostFormValue("status")
	b, err := models.NewBindWechatGroup()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	c := b.GetCollection()
	c.AddFieldToFilter("user_id","eq",bw.getCurrentUserId(r))
	if status != "" {
		c.AddFieldToFilter("status","eq",status)
	}
	c.AddOrder("id desc")

	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}

	c.Load()

	if online != "" {

		var vechatIDs []string
		vechatGroupMaps := make(map[int][]*db.Item)
		c.Each(func(item *db.Item) {
			wechat,_ := models.NewBindWechat()
			wechats := wechat.GetCollection()
			wechats.AddFieldToFilter("group_id","eq",item.GetString("id"))
			wechats.Load()
			vechatGroupMaps[item.GetId()] = wechats.GetItems()

			item.SetData("allCount", len(wechats.GetItems()))
			wechats.Each(func(item2 *db.Item) {
				vechatIDs = append(vechatIDs, item2.GetString("wechat_id"))
			})
		})

		loginMap := getLoginMap(vechatIDs,bw.getCurrentUserId(r),"")

		c.Each(func(item *db.Item) {

			wechatItems := vechatGroupMaps[item.GetId()]
			onlineCount := 0
			for i := range wechatItems {
				if loginMap[wechatItems[i].GetString("wechat_id")] == 12007 {
					onlineCount ++
				}
			}
			item.SetData("onlineCount", onlineCount)
		})
	}

	bw.list(w, c)
}

//获取微信分组导出数据
func (bw BindWechatGroup) Wechats(cxt iris.Context) {
	r := cxt.Request()
	w := cxt.ResponseWriter()
	r.ParseForm()

	userID := r.FormValue("user_id")//r.PostFormValue("types")       //类型:1 62类型,2安卓类型
	types := r.FormValue("type")//r.PostFormValue("types")       //类型:1 62类型,2安卓类型
	groupId := r.FormValue("group_id")//r.PostFormValue("group_id")       //微信分組ID
	secondPassword := r.FormValue("second_password")//r.PostFormValue("second_password")       //二级密码
	if groupId == "" {
		rel, _ := utils.JsonEncode(-1, nil, "微信分組ID不能为空")
		w.Write(rel)
		return
	}
	if secondPassword == "" {
		rel, _ := utils.JsonEncode(-1, nil, "二级密码不能为空")
		w.Write(rel)
		return
	}
	user,_ := models.NewUser()
	user.Load(cast.ToInt64(userID))
	if user.GetId() == 0 {
		rel, _ := utils.JsonEncode(-1, nil, "登录失效,请重新登录")
		w.Write(rel)
		return
	}

	if user.GetString("second_password") == "" {
		rel, _ := utils.JsonEncode(-1, nil, "没有设置二级密码,请先设置二级密码")
		w.Write(rel)
		return
	}

	secondPwd := getMd5Pwd(user.GetString("user_name"),secondPassword)
	if user.GetString("second_password") != secondPwd {
		rel, _ := utils.JsonEncode(-1, nil, "密码错误")
		w.Write(rel)
		return
	}

	wechatGroup,_ := models.NewBindWechatGroup()
	wechatGroup.Load(cast.ToInt64(groupId))

	if wechatGroup.GetId() == 0 {
		rel, _ := utils.JsonEncode(-1, nil, "微信分組不存在")
		w.Write(rel)
		return
	}

	wechat, _ := models.NewBindWechat()
	c := wechat.GetCollection()
	c.AddFieldToFilter("group_id", "eq", groupId)
	c.Load()
	items := c.GetItems()

	name := wechatGroup.GetString("group_name")+".txt"
	fileSavePath := config.Sysconfig.FileSavePath+"/static/save/"
	exist, _ := PathExists(fileSavePath)
	if !exist {
		err := os.MkdirAll(fileSavePath, os.ModePerm)
		if err != nil {
			log.Printf("mkdir failed![%v]\n", err)
			rel, _ := utils.JsonEncode(-1, nil, err.Error())
			w.Write(rel)
			return
		}
	}
	file, error := os.Create(fileSavePath+name)
	if error != nil {
		log.Println(error)
		rel, _ := utils.JsonEncode(-1, nil, error.Error())
		w.Write(rel)
		return
	}

	for i := range items{
		//wechat_id := items[i].GetString("wechat_id")
		wechat_mobile := items[i].GetString("wechat_mobile")
		wechat_password := items[i].GetString("wechat_password")
		device_data := items[i].GetString("android_device_data")
		pwd := items[i].GetString("wechat_password")
		if types == "1" {
			device_data = items[i].GetString("login_device_data")
		}
		lineContent := wechat_mobile + "----" + wechat_password + "----" + device_data + "\r\n"

		if pwd != "" {
			file.WriteString(lineContent)
		}
	}
	file.Close()

	//res := cxt.ResponseWriter()
	//file, err := os.Open(fileSavePath+name)
	//defer file.Close()
	//fileName := path.Base(fileSavePath+name)
	//fileName = url.QueryEscape(fileName) // 防止中文乱码
	//res.Header().Set("Content-Type", "application/octet-stream")
	//res.Header().Set("content-disposition", "attachment; filename=\""+fileName+"\"")
	//_, err = io.Copy(res, file)
	//if err != nil {
	//	http.Error(w, err.Error(), http.StatusInternalServerError)
	//	return
	//}

	a:=cxt.ResponseWriter()
	a.Header().Set("Content-Disposition", "attachment; filename=\""+name+"\"")
	a.Header().Set("Content-Type", "application/octet-stream")
	err := cxt.SendFile(fileSavePath+name, name)
	if err != nil {
		log.Println(err)
	}

}

//批量修改密码
func (bw BindWechatGroup) BatchUpdatePwd(w http.ResponseWriter, r *http.Request) {
	groupId := r.PostFormValue("group_id")       //微信分組ID
	wechat, _ := models.NewBindWechat()
	c := wechat.GetCollection()
	c.AddFieldToFilter("group_id", "eq", groupId)
	c.Load()

	go func() {
		items := c.GetItems()
		for i := range items {
			item := items[i]
			go func() {
				oldPwd := item.GetString("wechat_password")
				if oldPwd != "" {
					newPwd := utils.GetRandomString(8)
					//修改密码
					dataMap := make(map[string]interface{})
					dataMap["old_pwd"] = oldPwd
					dataMap["pwd"] = newPwd
					heardMap := make(map[string]string)
					heardMap["Authorization"] = utils.GentToken(bw.getCurrentUserId(r),item.GetString("wechat_id"))
					resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/changepassword",dataMap,heardMap)

					//添加到修改密码历史记录
					pwdHistory,_ := models.NewWechatPwdHistory()
					pwdHistory.SetData("wechat_id",item.GetString("wechat_id"))
					pwdHistory.SetData("old_pwd",oldPwd)
					pwdHistory.SetData("new_pwd",newPwd)

					msg := ""

					if err != nil {
						msg = err.Error()
						log.Println("changepassword error: ",err)
					}

					log.Println("批量修改密码返回:",resp)

					maps := make(map[string]interface{})
					err = json.Unmarshal([]byte(resp), &maps)
					if err != nil {
						log.Println("changepassword json.Unmarshal Error: ", err)
					}
					if cast.ToString(maps["Code"]) == "-1" {
						msg = cast.ToString(maps["Msg"])
					}

					if msg == "" {
						msg = "修改成功"
					}

					pwdHistory.SetData("msg",msg)
					if  err := pwdHistory.Save(); err != nil {
						log.Println("WechatPwdHistory Save Error: ",err)
					}
				}
			}()
		}
	}()

	rel, _ := utils.JsonEncode(0, nil, "已在后台修改")
	w.Write(rel)
}

//批量修改信息(昵称/头像/个性签名/朋友圈背景图/自动通过好友/朋友圈查看多少天)
func (bw BindWechatGroup) BatchUpdateInfo(w http.ResponseWriter, r *http.Request) {
	groupId := r.PostFormValue("group_id")       //微信分組IDs
	categoryId := r.PostFormValue("category_id") //素材分組IDs
	types := r.PostFormValue("type")             //修改类型	昵称/头像/个性签名/朋友圈背景图/自动通过好友开关
	isRand := r.PostFormValue("isrand")          //是否随机
	active := r.PostFormValue("active")          //自动通过好友开关
	userID := bw.getCurrentUserId(r)
	//朋友圈可见范围	1：3天， 2：半年，3：全部
	visibleRange := r.PostFormValue("visible_range")

	//取未绑定素材的微信
	wechat, _ := models.NewBindWechat()
	c := wechat.GetCollection()
	c.AddFieldToFilter("group_id", "in", strings.Join(strings.Split(groupId,","),"','"))
	c.Load()
	wechatItems := c.GetItems()



	if types == "mmsnimg" || types == "signatrue" || types == "headimg" || types == "nikename" {


		//已绑定的
		c2 := wechat.GetCollection()
		c2.AddFieldToFilter("group_id", "in", strings.Join(strings.Split(groupId,","),"','"))
		c2.Join("ym_material as dl", "m.wechat_id=dl.wechat_id", "dl.id as dlid")
		c2.Load()
		bindedWechatItems := c2.GetItems()
		hadMap := make(map[string]int)
		for i := range bindedWechatItems {
			hadMap[bindedWechatItems[i].GetString("wechat_id")] = 1
		}

		fmt.Println(c)

		//没绑定的
		var canUpWecatIDs []string
		for i := range wechatItems {
			wxID := wechatItems[i].GetString("wechat_id")
			if _,ok := hadMap[wxID]; ok {
				continue
			}
			canUpWecatIDs = append(canUpWecatIDs, wxID)
		}

		//登录了的
		loginMap := getLoginMap(canUpWecatIDs,userID,"")

		fmt.Println("登录了的微信号: ",loginMap)

		var finalWechatIDs []string
		for i := range canUpWecatIDs {
			if loginMap[canUpWecatIDs[i]] == 12007 {
				finalWechatIDs = append(finalWechatIDs, canUpWecatIDs[i])
			}
		}

		//未绑定的微信素材
		material, _ := models.NewMaterial()
		d := material.GetCollection()
		d.AddFieldToFilter("category_id", "in", strings.Join(strings.Split(categoryId,","),"','"))
		d.AddFieldToFilter("wechat_id", "null", "")
		d.Load()

		//素材
		materialItems := d.GetItems()

		if len(finalWechatIDs) < 1 {
			rel, _ := utils.JsonEncode(-1, nil, "没有微信可以修改")
			w.Write(rel)
			return
		}
		if len(materialItems) < 1 {
			rel, _ := utils.JsonEncode(-1, nil, "请确认是否有闲置素材")
			w.Write(rel)
			return
		}

		go func() {
			if cast.ToBool(isRand) {
				//随机
				randUpdate(finalWechatIDs, materialItems, types, bw.getCurrentUserId(r))

			} else {
				//顺序
				orderUpdate(finalWechatIDs, materialItems, types, bw.getCurrentUserId(r))
			}
		}()
	}else if types == "friendswitch" {
		go func() {
			for i := range wechatItems {
				data := make(map[string]interface{})
				data["active"] = active
				resp, err := updateInfo(types, bw.getCurrentUserId(r), wechatItems[i].GetString("wechat_id"),data)
				if err != nil {
					log.Println("friendswitch update error: resp: ",resp," error: ",err)
					continue
				}
				time.Sleep(time.Second * 2)
			}
		}()
	}else if types == "mmsnday" {
		go func() {
			for i := range wechatItems {
				data := make(map[string]interface{})
				data["visible_range"] = visibleRange
				resp, err := updateInfo(types, bw.getCurrentUserId(r), wechatItems[i].GetString("wechat_id"),data)
				if err != nil {
					log.Println("friendswitch update error: resp: ",resp," error: ",err)
					continue
				}
				time.Sleep(time.Second * 2)
			}
		}()
	}

	rel, _ := utils.JsonEncode(0, nil, "已在后台进行")
	w.Write(rel)

}

func randUpdate(wechatIDs []string, materialItems []*db.Item, types string, userID string){

	//随机
	//放入map
	wechatMaps := make(map[string]*db.Item)
	for i := range wechatIDs {
		if i < len(materialItems) {
			wechatMaps[wechatIDs[i]] = materialItems[i]
		}else {
			break
		}

	}

	for wechatID, material := range wechatMaps {
		//从素材[]里取值
		nickname := material.GetData("nickname")
		imagePath := material.GetData("heading_img_path")
		signatrue := material.GetData("signatrue")
		backgroundImgPath := material.GetData("background_img_path")
		data := make(map[string]interface{})
		data["nickname"] = nickname
		data["imagePath"] = config.Sysconfig.LocalhostAddr + "/" + cast.ToString(imagePath)
		data["signatrue"] = signatrue
		data["background_img_path"] = backgroundImgPath
		resp, err := updateInfo(types, userID, wechatID,data)
		if err != nil {
			log.Println("randUpdate updateInfo error: resp: ",resp," error: ",err)
			continue
		}

		material.SetData("wechat_id",wechatID)
		if err := material.Save() ; err != nil {
			log.Println("material save error: ",err)
		}

		time.Sleep(time.Second * 3)
	}
}

type WechatIDMaterial struct {
	WechatID string
	Material *db.Item
}

func orderUpdate(wechatIDs []string, materialItems []*db.Item, types string, userID string) {
	var resp string
	var err error

	//顺序
	wechatMaterials := make([]WechatIDMaterial, len(wechatIDs))
	for i := range wechatIDs {
		if i < len(materialItems) {
			var wm WechatIDMaterial
			wm.WechatID = wechatIDs[i]
			wm.Material = materialItems[i]
			wechatMaterials = append(wechatMaterials, wm)
		}else {
			break
		}

	}

	for i := range wechatMaterials {
		wechatID := wechatMaterials[i].WechatID
		material := wechatMaterials[i].Material

		nickname := material.GetData("nickname")
		imagePath := material.GetData("heading_img_path")
		signatrue := material.GetData("signatrue")
		backgroundImgPath := material.GetData("background_img_path")
		data := make(map[string]interface{})
		data["nickname"] = nickname
		data["imagePath"] = config.Sysconfig.LocalhostAddr + "/" + cast.ToString(imagePath)
		data["signatrue"] = signatrue
		data["background_img_path"] = backgroundImgPath
		resp, err = updateInfo(types, userID, wechatID,data)
		if err != nil {
			log.Println("orderUpdate updateInfo error: resp: ",resp," error: ",err)
			time.Sleep(time.Second * 3)
			continue
		}

		material.SetData("wechat_id",wechatID)
		if err := material.Save();err != nil {
			log.Println("material save error: ",err)
			continue
		}
		time.Sleep(time.Second * 3)
	}
	////循环算法,获取二维数组
	//
	//
	//finalArr := make([][]string, 0)
	//wArr := make([]string, 0)
	//for i := range wechatIDs {
	//	wArr = append(wArr, wechatIDs[i])
	//	if len(wArr) == len(materialItems) {
	//		//fmt.Println(wArr)
	//		finalArr = append(finalArr, wArr)
	//		wArr = make([]string, 0)
	//	} else {
	//		if i == len(wechatIDs)-1 {
	//			//fmt.Println(wArr)
	//			finalArr = append(finalArr, wArr)
	//		}
	//	}
	//}
	//for i := range finalArr {
	//	wechatItemArr := finalArr[i]
	//	for j := range wechatItemArr { //长度固定为materialItems长度
	//		//wechatItemArr[j].SetData("nickname", nickname)
	//		//wechatItemArr[j].Save()
	//		//wechatItem := wechatItems[i]
	//		//从素材[]里取值
	//
	//	}
	//}
}

func updateInfo(types string, userID, wxID string,data map[string]interface{}) (string, error) {
	var resp string
	var err error

	dataMap := make(map[string]interface{})

	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wxID)
	if types == "nikename" {
		//修改昵称
		dataMap["nickname"] = data["nickname"]
		resp, err = utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/updatenickname", dataMap, heardMap)
	} else if types == "headimg" {
		//修改头像
		dataMap["image_path"] = data["imagePath"]
		heardMap["Content-Type"] = "application/x-www-form-urlencoded"
		resp, err = utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/modifyheadimg", dataMap, heardMap)
	} else if types == "signatrue" {
		//修改签名
		dataMap["personality"] = data["signatrue"]
		resp, err = utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/updatepersonality", dataMap, heardMap)
	} else if types == "mmsnimg" {
		dataMap["background"] = data["background_img_path"]
		resp,err = utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/mmsns/modifysnsbackgroud", dataMap, heardMap)
	} else if types == "friendswitch" {
		//修改自动通过好友
		dataMap["active"] = data["active"]
		resp,err = utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/verifyfriendswitch", dataMap, heardMap)
	} else if types == "mmsnday" {
		//修改自动通过好友
		dataMap["active"] = data["active"]
		resp,err = utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/verifyfriendswitch", dataMap, heardMap)
	}
	return resp, err
}

//批量解绑素材
func (bw BindWechatGroup) BacthUntyingMaterial(w http.ResponseWriter, r *http.Request) {
	groupIds := r.PostFormValue("group_ids")       //微信分組IDs

	wechat,err := models.NewBindWechat()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("group_id","in",strings.Join(strings.Split(groupIds,","),"','"))
	wechats.Load()

	var wechatIDs []string
	wechats.Each(func(item *db.Item) {
		wechatIDs = append(wechatIDs, item.GetString("wechat_id"))
	})

	material,err := models.NewMaterial()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	materials := material.GetCollection()
	materials.AddFieldToFilter("wechat_id","in",strings.Join(wechatIDs,"','"))
	materials.Load()

	materials.Each(func(item *db.Item) {
		item.SetData("wechat_id",nil)
		if err := item.Save();err != nil {
			log.Println("material save error; ",err)
		}
	})

	rel, _ := utils.JsonEncode(0, nil, "操作成功")
	w.Write(rel)
	return

}