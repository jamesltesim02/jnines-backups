/*
@Time : 2019/5/17 17:21 
@Author : Lukebryan
@File : move_message_type.go
@Software: GoLand
*/
package api

import (
	"github.com/spf13/cast"
	"net/http"
	"strconv"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type MoveMessageType struct {
	Base
}

func (s MoveMessageType) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	name := r.PostFormValue("name")
	if name == "" {
		http.Error(w, "分组名不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewMoveMessageType()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	m.SetData("name", name)
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m, "操作成功")
		w.Write(rel)
		return
	}
}

func (MoveMessageType) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewMoveMessageType()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(id)
	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (MoveMessageType) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewMoveMessageType()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(id)
	err = m.Delete()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, nil, "删除成功")
		w.Write(rel)
		return
	}
}

func (s MoveMessageType) List(w http.ResponseWriter, r *http.Request) {

	m, err := models.NewMoveMessageType()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	c.AddOrder("id desc")
	c.Load()
	s.list(w, c)
}
