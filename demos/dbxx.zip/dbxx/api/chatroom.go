package api

import (
	"encoding/base64"
	"net/http"
	"strings"
	"wechatmanagent/config"
	"wechatmanagent/utils"
)

type Chatroom struct {
	Base
}

//发送动态表情
func (c Chatroom) CreateChatroom(w http.ResponseWriter, r *http.Request) {
	roomName := r.PostFormValue("name")
	memberList := r.PostFormValue("members")
	members := strings.Split(memberList, ",")
	if roomName == "" || memberList == "" {
		http.Error(w, "群名和群成员不能为空", http.StatusBadRequest)
		return
	}

	isLogined := c.isLogined(r,c.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["members"] = members
	dataMap["name"] = roomName
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(c.getCurrentUserId(r),c.getCurrentWxId(r))
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/create",dataMap,heardMap)
	//_, err := cli.CreateChatroom(roomName, members)
	if err == nil {
		res, _ := utils.JsonEncode(0, nil, "创建成功")
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	}
}

func (c Chatroom) QuitChatroom(w http.ResponseWriter, r *http.Request) {
	roomId := r.PostFormValue("room_id")

	if roomId == "" {
		http.Error(w, "微信id不能为空", http.StatusBadRequest)
		return
	}

	isLogined := c.isLogined(r,c.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["room_id"] = roomId
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(c.getCurrentUserId(r),c.getCurrentWxId(r))
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/quit",dataMap,heardMap)
	//_, err := cli.QuitChatroom(roomId)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(0, nil, "操作成功")
		w.Write(res)
	}
}

//扫码进群
func (c Chatroom) ScanQRJoin(w http.ResponseWriter, r *http.Request) {
	QRData, err := base64.StdEncoding.DecodeString(r.PostFormValue("QRData"))
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}

	isLogined := c.isLogined(r,c.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["QRData"] = QRData
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(c.getCurrentUserId(r),c.getCurrentWxId(r))
	_, err = utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/scanqrjoin",dataMap,heardMap)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(0, nil, "操作成功")
		w.Write(res)
	}
	//m, err := qrcode.Decode(bytes.NewReader(QRData))
	//if err != nil {
	//	res, _ := utils.JsonEncode(-1, nil, err.Error())
	//	w.Write(res)
	//	return
	//}
	//
	//fmt.Println(m)
	//TODO 	GetA8Key		FullURL
	//rsp, err := cli.GetA8Key(m.Content, cli.GetWxid())
	//if err != nil {
	//	res, _ := utils.JsonEncode(-1, nil, err.Error())
	//	w.Write(res)
	//} else {
	//	_, err := http.PostForm(*rsp.FullURL, nil)
	//	if err != nil {
	//		res, _ := utils.JsonEncode(-1, nil, err.Error())
	//		w.Write(res)
	//	} else {
	//		res, _ := utils.JsonEncode(0, nil, "操作成功")
	//		w.Write(res)
	//	}
	//}
}

//拉人进群
func (c Chatroom) AddNewMembers(w http.ResponseWriter, r *http.Request) {
	roomId := r.PostFormValue("room_id")
	memberList := r.PostFormValue("members")
	members := strings.Split(memberList, ",")
	if roomId == "" || memberList == "" {
		http.Error(w, "群名和群成员不能为空", http.StatusBadRequest)
		return
	}

	isLogined := c.isLogined(r,c.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["room_id"] = roomId
	dataMap["members"] = members
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(c.getCurrentUserId(r),c.getCurrentWxId(r))
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/addnewmembers",dataMap,heardMap)
	//_, err := cli.AddChatroomMembers(roomId, members)
	if err != nil {
		//TODO	InviteChatroomMembers
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	}
	res, _ := utils.JsonEncode(0, nil, "操作成功")
	w.Write(res)
}

// 获取群成员列表
func (c Chatroom) GetChatroomMembers(w http.ResponseWriter, r *http.Request) {
	isLogined := c.isLogined(r,c.getCurrentWxId(r))
	if !isLogined {
		rel, _ := utils.JsonEncode(-1, nil, "请先调用扫码登录接口")
		w.Write(rel)
		return
	}

	roomId := r.PostFormValue("room_id")


	dataMap := make(map[string]interface{})
	dataMap["room_id"] = roomId
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(c.getCurrentUserId(r),c.getCurrentWxId(r))
	members, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/getchatroommembers",dataMap,heardMap)
	//members, err := cli.GetChatroomMembers(roomId)
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
	} else {
		//rel, _ := utils.JsonEncode(0, members, "")
		//w.Write(rel)
		w.Write([]byte(members))
	}
}
