/*
@Time : 2019/5/28 10:58 
@Author : Lukebryan
@File : friends_circle_material.go
@Software: GoLand
*/
package api

import (
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type PhoneV1v2 struct {
	Base
}

//获取单个
func (PhoneV1v2) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("ids")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewPhoneV1v2()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(id)

	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

//删除
func (PhoneV1v2) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewSnsMaterial()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("PhoneV1v2 Delete Error: ",err)
			return
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}
//朋友圈素材列表
func (s PhoneV1v2) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	wechatID := r.PostFormValue("wechat_id")
	addFriendPlanID := r.PostFormValue("add_friend_plan_id")
	addPhone := r.PostFormValue("add_phone")
	userID := s.getCurrentUserId(r)

	addFriendPlan,err := models.NewAddFriendPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	addFriendPlans := addFriendPlan.GetCollection()
	addFriendPlans.AddFieldToFilter("user_id","eq",userID)
	addFriendPlans.Load()

	var addFriendPlanIDs []string
	addFriendPlans.Each(func(item *db.Item) {
		addFriendPlanIDs = append(addFriendPlanIDs, item.GetString("id"))
	})

	m, err := models.NewPhoneV1v2()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()


	if wechatID != "" {
		c.AddFieldToFilter("wechat_id","eq",wechatID)
	}
	if addFriendPlanID != "" {
		c.AddFieldToFilter("add_friend_plan_id","eq",addFriendPlanID)
	}
	if addPhone != "" {
		c.AddFieldToFilter("add_phone","like","%"+addPhone+"%")
	}
	c.AddFieldToFilter("add_friend_plan_id","in",strings.Join(addFriendPlanIDs,"','"))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	s.list(w, c)
}



