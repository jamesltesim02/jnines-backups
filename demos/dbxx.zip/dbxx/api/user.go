package api

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
	"wechatmanagent/web/middleware"
)

type User struct {
	Base
}

//创建用户
func (User) Create(w http.ResponseWriter, r *http.Request) {
	userName := r.PostFormValue("user_name")
	password := r.PostFormValue("password")
	email := r.PostFormValue("email")
	phone := r.PostFormValue("phone")

	user, err := models.NewUser()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	//newPwd := getMd5Pwd(userName,password)
	user.SetData("user_name", userName)
	user.SetData("password", password)
	user.SetData("email", email)
	user.SetData("phone", phone)
	err = user.Create()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, user.GetId(), "创建成功")
		w.Write(rel)
		return
	}
}

//修改密码
func (u User) ChangePassword(w http.ResponseWriter, r *http.Request) {
	oldPassword := r.PostFormValue("old_password")
	newPassword := r.PostFormValue("new_password")
	confirmPassword := r.PostFormValue("confirm_password")

	user,_ := models.NewUser()
	user.Load(cast.ToInt64(u.getCurrentUserId(r)))

	pwd := getMd5Pwd(user.GetString("user_name"),oldPassword)
	if pwd != user.GetString("password") {
		rel, _ := utils.JsonEncode(-1, nil, "密码错误")
		w.Write(rel)
		return
	}

	if newPassword != confirmPassword {
		rel, _ := utils.JsonEncode(-1, nil, "两次密码输入不一致")
		w.Write(rel)
		return
	}

	newPwd := getMd5Pwd(user.GetString("user_name"),newPassword)
	user.SetData("password",newPwd)
	err := user.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, "修改失败")
		w.Write(rel)
		return
	}
	rel, _ := utils.JsonEncode(0, newPassword, "修改成功")
	w.Write(rel)
	return
}

func getMd5Pwd(userName,pwd string,) string {
	h256 := sha256.New()
	h256.Write([]byte(pwd))
	h256.Write([]byte("JOIN"))
	h256.Write([]byte(userName))
	return hex.EncodeToString(h256.Sum(nil))
}

//登录
func (s User) Login(w http.ResponseWriter, r *http.Request) {
	userName := r.PostFormValue("user_name")
	password := r.PostFormValue("password")

	user, err := models.NewUser()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	//pwd := getMd5Pwd(user.GetString("user_name"),password)
	user.SetData("user_name", userName)
	user.SetData("password", password)

	err = user.VerifyLogin()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		fmt.Println("登录后userID: ",user.GetId())
		apiToken,err := loginApi(userName,password)

		if err != nil {
			log.Println(err)
			//rel, _ := utils.JsonEncode(-1, nil, err.Error())
			//w.Write(rel)
			//return
		}

		if apiToken == "" {
			apiToken = s.getCurrentUserId(r)
		}

		utils.ApiToken[user.GetString("id")] = apiToken

		//创建客户端对应cookie以及在服务器中进行记录
		var sessionID = middleware.SMgr.StartSession(w, r)
		var loginUserInfo = user.GetId()

		//踢除重复登录的
		var onlineSessionIDList = middleware.SMgr.GetSessionIDList()
		for _, onlineSessionID := range onlineSessionIDList {
			//fmt.Println("在线onlineSessionID:   ",onlineSessionID)
			if userInfo, ok := middleware.SMgr.GetSessionVal(onlineSessionID, "UserInfo"); ok {
				if value, ok := userInfo.(int); ok {
					if value == user.GetId(){
						//fmt.Println("踢除重复登录",onlineSessionID)
						middleware.SMgr.EndSessionBy(onlineSessionID)
					}
				}
			}
		} 

		//设置变量值
		middleware.SMgr.SetSessionVal(sessionID, "UserInfo", loginUserInfo)
		maps := make(map[string]interface{})
		maps["Session"] = sessionID
		maps["ID"] = user.GetId()
		tokenString := middleware.GenerateToken(maps)

		resultMap := make(map[string]interface{})
		resultMap["Token"] = tokenString
		resultMap["APIToken"] = apiToken
		resultMap["ID"] = user.GetId()
		rel, _ := utils.JsonEncode(0, resultMap, "登录成功")
		w.Write(rel)
		return
	}
}

func loginApi(userName,password string) (string,error) {
	dataMap := make(map[string]interface{})
	dataMap["user_name"] = userName
	dataMap["password"] = password
	heardMap := make(map[string]string)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/user/login", dataMap, heardMap)
	if err != nil {
		log.Println("api user login error: ", err)
		return "",err
	}
	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(resp), &maps)
	if err != nil {
		log.Println("api user login json.Unmarshal Error: ", err)
		return "",err
	}
	if cast.ToString(maps["Code"]) == "-1" {
		log.Println(cast.ToString(maps["Msg"]))
		return "",errors.New(cast.ToString(maps["Msg"]))
	}
	return cast.ToString(maps["Data"]),nil
}

//设置二级密码
func (u User) SetSecondPwd(w http.ResponseWriter, r *http.Request) {
	userID := u.getCurrentUserId(r)
	user,_ := models.NewUser()
	user.Load(cast.ToInt64(userID))

	secondPassword := r.PostFormValue("second_password")

	if user.GetInt64("id") == 0 {
		rel, _ := utils.JsonEncode(-1, nil, "登录过期,请先登录")
		w.Write(rel)
		return
	}

	if user.GetString("second_password") != "" {
		rel, _ := utils.JsonEncode(-1, nil, "二级密码已设置过了,无法更改")
		w.Write(rel)
		return
	}
	user.SetData("second_password",getMd5Pwd(user.GetString("user_name"),secondPassword))
	err := user.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, "设置失败")
		w.Write(rel)
		return
	}
	rel, _ := utils.JsonEncode(0, nil, "设置成功")
	w.Write(rel)
}

//是否有二级密码
func (u User) HasSecondPwd(w http.ResponseWriter, r *http.Request) {
	userID := u.getCurrentUserId(r)
	user,_ := models.NewUser()
	user.Load(cast.ToInt64(userID))

	if user.GetInt64("id") == 0 {
		rel, _ := utils.JsonEncode(-1, nil, "登录过期,请先登录")
		w.Write(rel)
		return
	}

	flag := true
	if user.GetString("second_password") != "" {
		flag = false
	}
	rel, _ := utils.JsonEncode(0, flag, "")
	w.Write(rel)
}