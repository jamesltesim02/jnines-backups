/*
@Time : 2019/5/28 10:58 
@Author : Lukebryan
@File : SnsMaterialGroup.go
@Software: GoLand
*/
package api

import (
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type SnsMaterialGroup struct {
	Base
}

//保存朋友圈素材组
func (s SnsMaterialGroup) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	name := r.PostFormValue("name")

	if id == "" && name == "" {
		http.Error(w, "名称不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewSnsMaterialGroup()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	m.SetData("name", name)
	m.SetData("user_id", s.getCurrentUserId(r))
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m.GetMap(), "操作成功")
		w.Write(rel)
		return
	}
}

//获取单个
func (SnsMaterialGroup) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewSnsMaterialGroup()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(id)

	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

//删除
func (SnsMaterialGroup) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewSnsMaterialGroup()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("TalkMaterialGroup Delete Error: ",err)
			return
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}
//朋友圈素材组列表
func (s SnsMaterialGroup) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	name := r.PostFormValue("name")

	m, err := models.NewSnsMaterialGroup()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()

	if name != "" {
		c.AddFieldToFilter("name","eq",name)
	}
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	c.Each(func(item *db.Item) {
		material, _ := models.NewSnsMaterial()
		materials := material.GetCollection()
		materials.AddFieldToFilter("sns_material_group_id","eq",item.GetId())
		size := materials.GetSize()
		item.SetData("material_count", size)
	})

	s.list(w, c)
}



