		/*
@Time : 2019/5/28 16:26 
@Author : Lukebryan
@File : Talk_plan.go
@Software: GoLand
*/
package api

		import (
			"github.com/liuzhiyi/go-db"
			"github.com/spf13/cast"
			"log"
			"net/http"
			"strings"
			"wechatmanagent/models"
			"wechatmanagent/task"
			"wechatmanagent/utils"
		)

type TalkPlan struct {
	Base
}

//保存/发布对话任务
func (s TalkPlan) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	name := r.PostFormValue("name")
	count := r.PostFormValue("count")	//聊天次数
	eachAddCount := r.PostFormValue("each_add_count")	//互加数量
	talkInterval := r.PostFormValue("talk_interval")	//聊天间隔
	talkMaterialGroupID := r.PostFormValue("talk_material_group_id")	//对话素材组ID
	wechatGroupIds := r.PostFormValue("wechat_group_ids")	//微信分组IDs
	morningTime := r.PostFormValue("morning_time")	//上午聊天时间区间
	afternoonTime := r.PostFormValue("afternoon_time")	//下午聊天时间区间
	nightTime := r.PostFormValue("night_time")	//晚上聊天时间区间

	if id == "" && talkMaterialGroupID == "" {
		http.Error(w, "素材组不能为空", http.StatusBadRequest)
		return
	}
	if id == "" && wechatGroupIds == "" {
		http.Error(w, "微信分组不能为空", http.StatusBadRequest)
		return
	}
	if id == "" && (eachAddCount == "" || count == "") {
		http.Error(w, "微信分组不能为空", http.StatusBadRequest)
		return
	}

	if id == "" && (morningTime == "" && afternoonTime == ""  && nightTime == ""){
		http.Error(w, "时间不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewTalkPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	if name != "" {
		m.SetData("name", name)
	}
	if count != "" {
		m.SetData("count", count)
	}
	if eachAddCount != "" {
		m.SetData("each_add_count", eachAddCount)
	}
	if talkInterval != "" {
		m.SetData("talk_interval", talkInterval)
	}
	if morningTime != "" {
		m.SetData("morning_time", morningTime)
	}
	if afternoonTime != "" {
		m.SetData("afternoon_time", afternoonTime)
	}
	if nightTime != "" {
		m.SetData("night_time", nightTime)
	}
	if wechatGroupIds != "" {
		m.SetData("wechat_group_ids", wechatGroupIds)
	}
	if talkMaterialGroupID != "" {
		m.SetData("talk_material_group_id", talkMaterialGroupID)
	}
	m.SetData("user_id", s.getCurrentUserId(r))
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}else {
		if id == "" {
			go task.ToTalk(1,&m.Item)
		}

		rel, _ := utils.JsonEncode(0, m.GetMap(), "操作成功")
		w.Write(rel)
		return
	}
}

//删除
func (TalkPlan) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("ids")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewTalkPlan()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("TalkMaterialGroup Delete Error: ",err)
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}

//计划列表
func (s TalkPlan) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	m, err := models.NewTalkPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()


	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	c.Each(func(item *db.Item) {


		talkItem,_ := models.NewTalkItem()
		talkItems := talkItem.GetCollection()
		talkItems.AddFieldToFilter("talk_plan_id","eq",item.GetId())
		talkItems.Load()

		allCount := len(talkItems.GetItems())

		finishCount := 0
		cancelCount := 0
		failCount := 0

		//状态:0待执行,1执行中,2执行完毕,3失败,4取消
		talkItems.Each(func(item *db.Item) {
			state := item.GetInt("state")
			if state == 2 {
				finishCount ++
			}else if state == 3 {
				failCount ++
			}else if state == 4 {
				cancelCount ++
			}
		})
		waitCount := allCount - finishCount - failCount
		item.SetData("all_count", allCount)
		item.SetData("wait_count",waitCount)
		item.SetData("finish_count", finishCount)
		item.SetData("cancel_count",cancelCount)//取消
		item.SetData("fail_count",failCount)//失败
	})
	s.list(w, c)
}

//发圈详细
func (s TalkPlan) Item(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	planID := r.PostFormValue("plan_id")
	if planID == "" {
		http.Error(w, "朋友圈计划ID不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewTalkItem()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	c.AddFieldToFilter("talk_plan_id","eq",planID)
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	var wechatIDs []string
	c.Each(func(item *db.Item) {
		wechatIDs = append(wechatIDs, item.GetString("from_wechat_id"))
		wechatIDs = append(wechatIDs, item.GetString("to_wechat_id"))
	})
	bindWechat,_ := models.NewBindWechat()
	bindWechats := bindWechat.GetCollection()
	bindWechats.AddFieldToFilter("wechat_id", "in" , strings.Join(wechatIDs,"','"))
	bindWechats.Load()

	bindWechatMap := make(map[string]*db.Item)
	bindWechats.Each(func(item *db.Item) {
		bindWechatMap[item.GetString("wechat_id")] = item
	})

	c.Each(func(item *db.Item) {
		fromWechatItem := bindWechatMap[item.GetString("from_wechat_id")]
		toWechatItem := bindWechatMap[item.GetString("to_wechat_id")]
		fromNickname := ""
		toNickname := ""
		if _,ok := bindWechatMap[item.GetString("from_wechat_id")]; ok {
			fromNickname = fromWechatItem.GetString("nickname")
		}
		if _,ok := bindWechatMap[item.GetString("to_wechat_id")]; ok {
			toNickname = toWechatItem.GetString("nickname")
		}
		item.SetData("fromNickname",fromNickname)
		item.SetData("toNickname",toNickname)
	})
	s.list(w, c)
}
