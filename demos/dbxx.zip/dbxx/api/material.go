package api

import (
	"bufio"
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

//素材
type Material struct {
	Base
}

func (mt Material) Import(w http.ResponseWriter, r *http.Request) {

	categoryId := r.PostFormValue("category_id")
	sex := r.PostFormValue("sex")
	types := r.PostFormValue("type")
	userID := mt.getCurrentUserId(r)
	if categoryId == "" {
		rel, _ := utils.JsonEncode(-1, nil, "分组不能为空")
		w.Write(rel)
		return
	}

	if types == "5" {
		if sex != "1" && sex != "2" {
			rel, _ := utils.JsonEncode(-1, nil, "性别错误")
			w.Write(rel)
			return
		}
	}

	imgPaths, _ := mt.saveFile(r, "img_path", ImgDir)
	text, ok := r.MultipartForm.File["text"]
	texts := []string{}
	if ok {
		fd, _ := text[0].Open()
		buf := bufio.NewReader(fd)

		for {
			line, _, err := buf.ReadLine()
			if err == io.EOF {
				break
			}
			texts = append(texts, string(line))
			//if utils.IsUTF8(line) {
			//	texts = append(texts, string(line))
			//}else {
			//	texts = append(texts, utils.ConvertByte2String(line,"GBK"))
			//}
		}
	}

	materialCategory, _ := models.NewMaterialCategory()
	materialCategory.Load(cast.ToInt64(categoryId))
	if materialCategory.GetId() == 0 {
		rel, _ := utils.JsonEncode(-1, nil, "分组错误,请刷新后重试")
		w.Write(rel)
		return
	}

	go saveImportMaterial(userID,types,sex,categoryId,imgPaths,texts)

	rel, _ := utils.JsonEncode(0, nil, "已在后台进行")
	w.Write(rel)
	return
}

func saveImportMaterial(userID,types,sex,categoryId string,imgPaths,texts []string) {
	material, _ := models.NewMaterial()
	materials := material.GetCollection()
	materials.AddFieldToFilter("category_id","eq",categoryId)
	if types == "1" { //昵称
		materials.AddFieldToFilter("nickname", "null", "")
	} else if types == "2" { //签名
		materials.AddFieldToFilter("signatrue", "null", "")
	} else if types == "3" { //头像
		materials.AddFieldToFilter("heading_img_path", "null", "")
	} else if types == "4" { //朋友圈背景图
		materials.AddFieldToFilter("background_img_path", "null", "")
	}
	materials.Load()
	materialItems := materials.GetItems()
	if types == "1" || types == "2" { //昵称	/签名
		for i := range texts {
			newMaterial, _ := models.NewMaterial()
			if i <= (len(materialItems) - 1) {
				newMaterial.SetId(materialItems[i].GetInt64("id"))
			}
			if types == "1" {
				newMaterial.SetData("nickname",texts[i])
			}else {
				newMaterial.SetData("signatrue",texts[i])
			}
			newMaterial.SetData("user_id",userID)
			newMaterial.SetData("category_id",categoryId)
			if err := newMaterial.Save(); err != nil {
				log.Println("materialItems save error: ",err)
				continue
			}
		}
	}else if types == "3" || types == "4" { //头像	朋友圈背景图
		for i := 0; i < len(imgPaths); i++ {
			newMaterial, _ := models.NewMaterial()
			if i <= (len(materialItems) - 1) {
				newMaterial.SetId(materialItems[i].GetInt64("id"))
			}
			if types == "3" {
				newMaterial.SetData("heading_img_path",imgPaths[i])
			}else {
				newMaterial.SetData("background_img_path",imgPaths[i])
			}
			newMaterial.SetData("user_id",userID)
			newMaterial.SetData("category_id",categoryId)
			if err := newMaterial.Save(); err != nil {
				log.Println("materialItems save error: ",err)
				continue
			}
		}
	}else {
		materials.Each(func(item *db.Item) {
			item.SetData("sex",sex)
			if err := item.Save(); err != nil {
				log.Println("materialItems save error: ",err)
				return
			}
		})
	}
}

func (mt Material) Save(w http.ResponseWriter, r *http.Request) {
	categoryIdStr := r.PostFormValue("category_id")
	repeatable := r.PostFormValue("repeatable")
	headingImgPath := r.PostFormValue("heading_img_path")
	remark := r.PostFormValue("remark")
	sexStr := r.PostFormValue("sex")
	nickname := r.PostFormValue("nickname")
	backgroundPath := r.PostFormValue("background_img_path")
	signatrue := r.PostFormValue("signatrue")

	idStr := r.PostFormValue("id")

	sex, err := strconv.ParseInt(sexStr, 10, 64)
	if err != nil {
		sex = 1
	}

	categoryId, err := strconv.ParseInt(categoryIdStr, 10, 64)
	if err != nil {
		categoryId = 0
	}

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		id = 0
	}

	if headingImgPath == "" {
		paths, _ := mt.saveFile(r, "heading_img_path", ImgDir)
		if len(paths) > 0 {
			headingImgPath = paths[0]
		}
	}

	if backgroundPath == "" {
		paths, _ := mt.saveFile(r, "background_img_path", ImgDir)
		if len(paths) > 0 {
			backgroundPath = paths[0]
		}
	}

	fmt.Println("heading_img_path: ", headingImgPath)
	fmt.Println("background_img_path: ", backgroundPath)

	m, err := models.NewMaterial()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(id)

	if categoryId != 0 {
		m.SetData("category_id", categoryId)
	}
	if headingImgPath != "" {
		m.SetData("heading_img_path", headingImgPath)
	}
	if signatrue != "" {
		m.SetData("signatrue", signatrue)
	}
	if repeatable != "" {
		m.SetData("repeatable", repeatable)
	}
	if backgroundPath != "" {
		m.SetData("background_img_path", backgroundPath)
	}
	if nickname != "" {
		m.SetData("nickname", nickname)
	}
	if sex != 0 {
		m.SetData("sex", sex)
	}
	if remark != "" {
		m.SetData("remark", remark)
	}
	m.SetData("user_id", mt.getCurrentUserId(r))
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m.GetId(), "创建成功")
		w.Write(rel)
		return
	}
}

func (Material) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewMaterial()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.Load(id)
	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (Material) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	ids := strings.Split(idStr, ",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewMaterial()
	c := m.GetCollection()
	c.AddFieldToFilter("id", "in", strings.Join(ids, "','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("TalkMaterialGroup Delete Error: ", err)
			return
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}

func (mt Material) List(w http.ResponseWriter, r *http.Request) {
	pageStr := r.PostFormValue("page")
	sizeStr := r.PostFormValue("size")
	sexStr := r.PostFormValue("sex")
	nickname := r.PostFormValue("nickname")
	area := r.PostFormValue("area")
	categoryIdStr := r.PostFormValue("category_id")
	categoryId, err := strconv.ParseInt(categoryIdStr, 10, 64)
	if err != nil {
		categoryId = 0
	}

	sex, err := strconv.ParseInt(sexStr, 10, 64)
	if err != nil {
		sex = 0
	}

	page, err := strconv.ParseInt(pageStr, 10, 64)
	if err != nil {
		page = 1
	}

	size, err := strconv.ParseInt(sizeStr, 10, 64)
	if err != nil {
		size = 10
	}

	m, err := models.NewMaterial()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	if sex > 0 {
		c.AddFieldToFilter("sex", "eq", sex)
	}

	if nickname != "" {
		c.AddFieldToFilter("nickname", "eq", nickname)
	}

	if area != "" {
		c.AddFieldToFilter("area", "eq", area)
	}

	if categoryId != 0 {
		c.AddFieldToFilter("category_id", "eq", categoryId)
	}
	c.AddFieldToFilter("user_id", "eq", mt.getCurrentUserId(r))
	c.AddOrder("id desc")
	c.SetPageSize(size)
	c.SetCurPage(page)
	c.Load()
	mt.list(w, c)
}

func (a Material) AreaCodes(w http.ResponseWriter, r *http.Request) {
	//data, err := ioutil.ReadFile("./mmregioncode_zh_CN.txt")
	//if err != nil {
	//	http.Error(w, err.Error(), http.StatusInternalServerError)
	//	return
	//}
	//rel, _ := utils.JsonEncode(0, data, "")
	//w.Write(rel)
	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r), a.getCurrentWxId(r))
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/material/areacodes", dataMap, heardMap)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	w.Write([]byte(data))
}
