/*
@Time : 2019/5/20 10:10 
@Author : Lukebryan
@File : upload_file.go
@Software: GoLand
*/
package api

import (
	"net/http"
	"wechatmanagent/config"
	"wechatmanagent/utils"
)

type UploadFile struct {
	Base
}

func (s UploadFile) Upload(w http.ResponseWriter, r *http.Request) {
	err := r.ParseMultipartForm(MultipartFormMaxMemory)
	if err != nil {
		return
	}
	_, ok := r.MultipartForm.File["file"]
	if !ok {
		rel, _ := utils.JsonEncode(-1, nil, "数据文件不能为空")
		w.Write(rel)
		return
	}

	excelPathMap, errs := s.uploadFile(r, "file",config.Sysconfig.FileSavePath + "/static/qrcode/")

	if len(errs) > 0 {
		rel, _ := utils.JsonEncode(-1, nil, "上传失败")
		w.Write(rel)
		return
	}

	rel, _ := utils.JsonEncode(0, excelPathMap, "上传成功")
	w.Write(rel)
	return

}
