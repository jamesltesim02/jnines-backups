package api

import (
	"net/http"
	"strconv"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type TaskCategory struct {
	Base
}

func (TaskCategory) Save(w http.ResponseWriter, r *http.Request) {
	name := r.PostFormValue("name")
	action := r.PostFormValue("action")
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		id = 0
	}

	if name == "" {
		http.Error(w, "类名不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewTaskCategory()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	m.SetData("id", id)
	m.SetData("name", name)
	m.SetData("action", action)
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m.GetId(), "操作成功")
		w.Write(rel)
		return
	}
}

func (TaskCategory) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewTaskCategory()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	m.Load(id)
	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (TaskCategory) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewTaskCategory()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	m.SetId(id)
	err = m.Delete()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, nil, "删除成功")
		w.Write(rel)
		return
	}
}

func (tc TaskCategory) List(w http.ResponseWriter, r *http.Request) {
	m, err := models.NewTaskCategory()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	c := m.GetCollection()
	c.Load()
	tc.list(w, c)
}
