package api

import (
	"net/http"
	"strconv"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type Wallet struct {
	Base
}

//打开红包
func (m Wallet) OpenWxhb(w http.ResponseWriter, r *http.Request) {
	channelId := r.PostFormValue("channel_id")
	msgType := r.PostFormValue("msg_type")
	sendId := r.PostFormValue("send_id")
	nativeUrl := r.PostFormValue("native_url")
	if channelId == "" || nativeUrl == "" {
		http.Error(w, "参数不全", http.StatusBadRequest)
	}

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["channel_id"] = channelId
	dataMap["msg_type"] = msgType
	dataMap["send_id"] = sendId
	dataMap["native_url"] = nativeUrl
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/wallet/openwxhb",dataMap,heardMap)
	//resp, err := cli.OpenWxhb(channelId, msgType, sendId, nativeUrl, "v1.0", 1)
	if err == nil {
		//res, _ := utils.JsonEncode(0, resp, "打开成功")
		//w.Write(res)
		w.Write([]byte(resp))
	} else {
		res, _ := utils.JsonEncode(-1, nil, "发送失败")
		w.Write(res)
	}
}

//打开红包 (limit,offset参数设置本次请求返回领取红包人数区间)
func (m Wallet) GetDetailWxhb(w http.ResponseWriter, r *http.Request) {
	limit := r.PostFormValue("limit")
	offset := r.PostFormValue("offset")
	sendId := r.PostFormValue("send_id")
	nativeUrl := r.PostFormValue("native_url")
	if sendId == "" || nativeUrl == "" {
		http.Error(w, "参数不全", http.StatusBadRequest)
	}

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["limit"] = limit
	dataMap["offset"] = offset
	dataMap["send_id"] = sendId
	dataMap["native_url"] = nativeUrl
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/wallet/getdetailwxhb",dataMap,heardMap)
	//resp, err := cli.GetDetailWxhb(limit, offset, sendId, nativeUrl, "v1.0")
	if err == nil {
		//res, _ := utils.JsonEncode(0, resp, "")
		//w.Write(res)
		w.Write([]byte(resp))
	} else {
		res, _ := utils.JsonEncode(-1, nil, "发送失败")
		w.Write(res)
	}
}

//收款
func (m Wallet) TransferOperation(w http.ResponseWriter, r *http.Request) {
	transId := r.PostFormValue("trans_id")
	transferId := r.PostFormValue("transfer_id")
	invalidTimeStr := r.PostFormValue("invalid_time")
	invalidTime, err := strconv.ParseInt(invalidTimeStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	if transId == "" || transferId == "" {
		http.Error(w, "参数不全", http.StatusBadRequest)
	}

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["trans_id"] = transId
	dataMap["transfer_id"] = transferId
	dataMap["invalid_time"] = invalidTime
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/wallet/transferoperation",dataMap,heardMap)
	//resp, err := cli.TransferOperation(invalidTime, transId, transferId)
	if err == nil {
		//res, _ := utils.JsonEncode(0, resp, "")
		//w.Write(res)
		w.Write([]byte(resp))
	} else {
		res, _ := utils.JsonEncode(-1, nil, "发送失败")
		w.Write(res)
	}
}

//收款查询
func (m Wallet) TransferQurey(w http.ResponseWriter, r *http.Request) {
	transId := r.PostFormValue("trans_id")
	transferId := r.PostFormValue("transfer_id")
	userName := r.PostFormValue("user_name")
	invalidTimeStr := r.PostFormValue("invalid_time")
	invalidTime, err := strconv.ParseInt(invalidTimeStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	if transId == "" || transferId == "" {
		http.Error(w, "参数不全", http.StatusBadRequest)
	}

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["user_name"] = userName
	dataMap["trans_id"] = transId
	dataMap["transfer_id"] = transferId
	dataMap["invalid_time"] = invalidTime
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/wallet/transferquery",dataMap,heardMap)
	//resp, err := cli.TransferQurey(invalidTime, transId, transferId, userName)
	if err == nil {
		//res, _ := utils.JsonEncode(0, resp, "")
		//w.Write(res)
		w.Write([]byte(resp))
	} else {
		res, _ := utils.JsonEncode(-1, nil, "发送失败")
		w.Write(res)
	}
}

// 从本地读取余额变动记录
func (wa Wallet) GetCreditOrderFromLocal(w http.ResponseWriter, r *http.Request) {
	pageStr := r.PostFormValue("page")
	sizeStr := r.PostFormValue("size")

	page, err := strconv.ParseInt(pageStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	size, err := strconv.ParseInt(sizeStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	isLogined := wa.isLogined(r,wa.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	m, err := models.NewWechatMessage()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()

	//TODO cli.GetWxid()	client.MsgApp
	//c.AddFieldToFilter("belong_wxid", "eq", cli.GetWxid())
	//c.AddFieldToFilter("type", "eq", client.MsgApp)

	c.SetPageSize(size)
	c.SetCurPage(page)
	c.Load()
	wa.list(w, c)
}

//查看钱包明细
func (m Wallet) GetWalletDetail(w http.ResponseWriter, r *http.Request) {
	limitStr := r.PostFormValue("limit")
	limit, err := strconv.ParseInt(limitStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	offsetStr := r.PostFormValue("offset")
	offset, err := strconv.ParseInt(offsetStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["limit"] = limit
	dataMap["offset"] = offset
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/wallet/getwalletdetail",dataMap,heardMap)
	//resp, err := cli.GetWalletDetail(limit, offset)
	if err == nil {
		//res, _ := utils.JsonEncode(0, resp, "")
		//w.Write(res)
		w.Write([]byte(resp))
	} else {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	}
}

//二维码收款
func (m Wallet) F2FQRCode(w http.ResponseWriter, r *http.Request) {
	//TODO need????
	amountStr := r.PostFormValue("amount")
	amount, err := strconv.ParseFloat(amountStr, 10)
	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["amount"] = amount
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/wallet/f2fqrcode",dataMap,heardMap)
	//resp, err := cli.F2FQRCode()
	if err == nil {
		//res, _ := utils.JsonEncode(0, resp, "")
		//w.Write(res)
		w.Write([]byte(resp))
	} else {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	}
}

//二维码收款带金额
func (m Wallet) TransferSetF2FFee(w http.ResponseWriter, r *http.Request) {
	amountStr := r.PostFormValue("amount")
	amount, err := strconv.ParseFloat(amountStr, 10)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	isLogined := m.isLogined(r,m.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["amount"] = amount
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(m.getCurrentUserId(r),m.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/wallet/transfersetf2ffee",dataMap,heardMap)
	//resp, err := cli.TransferSetF2FFee(amount)
	if err == nil {
		//res, _ := utils.JsonEncode(0, resp, "")
		//w.Write(res)
		w.Write([]byte(resp))
	} else {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	}
}
