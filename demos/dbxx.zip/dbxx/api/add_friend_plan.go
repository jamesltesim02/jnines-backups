/*
@Time : 2019/5/18 13:56 
@Author : Lukebryan
@File : add＿friend＿plan.go
@Software: GoLand
*/
package api

import (
	"encoding/json"
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/task"
	"wechatmanagent/utils"
)

type AddFriendPlan struct {
	Base
}

func (s AddFriendPlan) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	name := r.PostFormValue("name")
	customerID := r.PostFormValue("customer_id")
	runType := r.PostFormValue("run_type")
	startTime := r.PostFormValue("start_time")
	endTime := r.PostFormValue("end_time")
	addRound := r.PostFormValue("add_round")	//加人轮数
	addCount := r.PostFormValue("add_count")	//每轮加人数
	addPhoneInterval := r.PostFormValue("add_phone_interval")	//每轮加手机号间隔
	dataGroupIds := r.PostFormValue("data_group_ids")
	verifyMessages := r.PostFormValue("verify_messages")
	verifyMessages2 := r.PostFormValue("verify_messages2")
	wechatGroupIds := r.PostFormValue("wechat_group_ids")
	userID := s.getCurrentUserId(r)
	if name == "" {
		http.Error(w, "分组名不能为空", http.StatusBadRequest)
		return
	}
	if startTime == "" || endTime == "" {
		http.Error(w, "开始时间和结束时间不能为空", http.StatusBadRequest)
		return
	}
	if dataGroupIds == "" {
		http.Error(w, "数据表格不能为空", http.StatusBadRequest)
		return
	}
	if verifyMessages == "" || verifyMessages2 == ""  {
		http.Error(w, "验证消息不能为空", http.StatusBadRequest)
		return
	}
	if wechatGroupIds == "" {
		http.Error(w, "微信组不能为空", http.StatusBadRequest)
		return
	}

	//如果有个任务使用了该数据组且在执行,return false
	if dataGroupIds != "" && (id == "" || id == "0") {
		flag := checkPlanCanAdd(dataGroupIds,userID)
		if !flag {
			rel, _ := utils.JsonEncode(-1, nil, "数据组已有执行中的任务")
			w.Write(rel)
			return
		}

	}

	m, err := models.NewAddFriendPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.SetId(cast.ToInt64(id))
	if id != "" {
		m.Load(cast.ToInt64(id))
		if m.GetString("state") == "1" {
			rel, _ := utils.JsonEncode(-1, nil, "无法修改进行中的任务")
			w.Write(rel)
			return
		}
	}
	
	if name != ""{
		m.SetData("name", name)
	}
	if customerID != ""{
		m.SetData("customer_id", customerID)
	}
	if runType != ""{
		m.SetData("run_type", runType)
	}
	if startTime != ""{
		m.SetData("start_time", startTime)
	}
	if endTime != ""{
		m.SetData("end_time", endTime)
	}
	if addRound != ""{
		m.SetData("add_round", addRound)
	}
	if addCount != ""{
		m.SetData("add_count", addCount)
	}
	if addPhoneInterval != ""{
		m.SetData("add_phone_interval", addPhoneInterval)
	}
	if dataGroupIds != ""{
		m.SetData("data_group_ids", dataGroupIds)
	}
	if verifyMessages != ""{
		m.SetData("verify_messages", verifyMessages)
	}
	if verifyMessages2 != ""{
		m.SetData("verify_messages2", verifyMessages2)
	}
	if wechatGroupIds != ""{
		m.SetData("wechat_group_ids", wechatGroupIds)
	}
	m.SetData("user_id",s.getCurrentUserId(r))
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m.GetMap(), "操作成功")
		w.Write(rel)

		if id == "" || id == "0" {
			go func() {
				//加人计划
				//当前时间在开始时间之前,则第二天自动执行
				startT := cast.ToTime(time.Now().Format("2006-01-02") + " " + startTime + ":00")
				nowTime,_ := time.Parse("2006-01-02 15:04:05",time.Now().Format("2006-01-02 15:04:05"))
				if nowTime.Before(startT) {

					wechatArr := task.GetLoginedWechats(wechatGroupIds)

					importFileIds := strings.Split(dataGroupIds, ",")
					//已加过的手机号
					hasAddFriends := task.GetHasAddFriends(userID,wechatArr)

					importData, _ := models.NewImportData()
					importDatas := importData.GetCollection()
					//importDatas.AddFieldToSelect("wechat_id", "wechat_id")
					importDatas.AddFieldToFilter("import_file_id", "in", strings.Join(importFileIds, "','"))
					importDatas.AddFieldToFilter("state", "eq", 0)
					importDatas.AddFieldToFilter("wechat_id", "nin", strings.Join(hasAddFriends, "','"))
					importDatas.AddOrder("reliable")
					importDatas.Load()

					//获取总数据
					var importDataPhones []string
					importDatas.Each(func(item *db.Item) {
						importDataPhones = append(importDataPhones, item.GetString("wechat_id"))
					})



					for index := range wechatArr {

						wechatID := wechatArr[index]
						addPhones := task.GetImportDatas(importDataPhones,index+1, 30)
						fmt.Println(wechatID,"首次同步 addPhones: ",addPhones)

						if len(addPhones) == 0 {
							continue
						}

						//上传通讯录好友
						err := task.Uploadmcontact(addPhones, wechatID, userID)
						if err != nil {
							log.Println("上传通讯录好友失败")
							continue
						}else {
							for i := range addPhones {
								phoneV1v2,err := models.NewPhoneV1v2()
								if err != nil {
									continue
								}

								//添加导v1v2表
								phoneV1v2.SetData("wechat_id",wechatID)
								phoneV1v2.SetData("add_friend_plan_id",id)
								phoneV1v2.SetData("add_phone",addPhones[i])
								phoneV1v2.SetData("add_phone_md5",utils.GetMD5String(addPhones[i]))
								if err := phoneV1v2.Save();err != nil {
									log.Println("phoneV1v2 save error: ",err)
									continue
								}
							}
							//修改数据使用状态
							flag := task.UpdateDataState(importFileIds, addPhones)
							if !flag {
								log.Println("修改数据使用状态失败")
							}
						}
					}

					task.RunAddFriend(2,&m.Item)
				}
			}()
		}
		return
	}
}

func checkPlanCanAdd(dataGroupIds,userID string) bool {
	plan, err := models.NewAddFriendPlan()
	if err != nil {
		return false
	}
	plans := plan.GetCollection()
	plans.AddFieldToFilter("user_id","eq",userID)
	plans.AddFieldToFilter("state","eq",1)
	plans.Load()

	dataIDs := make(map[string]int)
	plans.Each(func(item *db.Item) {
		dataIds := item.GetString("data_group_ids")
		importFileIds := strings.Split(dataIds, ",")
		for i := range importFileIds {
			dataIDs[importFileIds[i]] = 1
		}
	})

	datas := strings.Split(dataGroupIds, ",")
	for i := range datas {
		if dataIDs[datas[i]] == 1 {
			return false
		}
	}
	return true
}
//终止或开始任务
func (a AddFriendPlan) StopOrStart(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	state := r.PostFormValue("state")	//	0/1
	userID := a.getCurrentUserId(r)
	if id == "" {
		rel, _ := utils.JsonEncode(-1, nil, "任务id不能为空")
		w.Write(rel)
		return
	}

	if state != "0" && state != "1" {
		rel, _ := utils.JsonEncode(-1, nil, "状态传入错误")
		w.Write(rel)
		return
	}

	m, err := models.NewAddFriendPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(cast.ToInt64(id))
	if m.GetId() == 0 {
		rel, _ := utils.JsonEncode(-1, nil, "id传入错误")
		w.Write(rel)
		return
	}

	if state == "1" {
		dataGroupIds := m.GetString("data_group_ids")
		flag := checkPlanCanAdd(dataGroupIds,userID)
		if !flag {
			rel, _ := utils.JsonEncode(-1, nil, "数据组已有执行中的任务")
			w.Write(rel)
			return
		}
	}

	if state == "0"{
		m.SetData("state",3)
	}else {
		m.SetData("state",1)
	}

	if err := m.Save();err != nil {
		rel, _ := utils.JsonEncode(-1, nil, "操作失败")
		w.Write(rel)
		return
	}

	rel, _ := utils.JsonEncode(0, nil, "操作成功")
	w.Write(rel)

	if state == "0" {
		go task.StopTask(id)	//终止任务
	}else {
		//加人计划
		//当前时间在开始时间之前,则第二天自动执行
		startT := cast.ToTime(time.Now().Format("2006-01-02") + " " + m.GetString("start_time") + ":00")
		if time.Now().Before(startT) {
			go task.RunAddFriend(2,&m.Item)
		}
	}
}
func (AddFriendPlan) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewAddFriendPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(id)

	wechatGroupIds := cast.ToString(m.GetData("wechat_group_ids"))

	ids := strings.Split(wechatGroupIds,",")

	wechatGroupMaps := make([]map[string]interface{},0)
	wechatGroupNames := make([]string,0)
	for j := range ids{
		wechatGroup, err := models.NewBindWechatGroup()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		wechatGroup.SetData("id",ids[j])
		wechatGroup.Row()
		wechatGroupMaps = append(wechatGroupMaps, wechatGroup.GetMap())
		wechatGroupNames= append(wechatGroupNames, wechatGroup.GetString("group_name"))
	}

	m.SetData("wechat_groups",wechatGroupMaps)
	m.SetData("wechat_group_names",strings.Join(wechatGroupNames,","))

	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (AddFriendPlan) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewAddFriendPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(id)
	err = m.Delete()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, nil, "删除成功")
		w.Write(rel)
		return
	}
}

func (s AddFriendPlan) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	state := r.PostFormValue("state")

	m, err := models.NewAddFriendPlan()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()


	if state != "" {
		c.AddFieldToFilter("state","eq",cast.ToBool(state))
	}
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	var planIDs []string
	c.Each(func(item *db.Item) {
		planIDs = append(planIDs, item.GetString("id"))
	})

	c.Each(func(i *db.Item) {

		customerID := i.GetString("customer_id")
		id := i.GetString("id")
		customer,_ := models.NewCustomer()
		customer.Load(cast.ToInt64(customerID))

		i.SetData("customer_name",customer.GetString("name"))

		wechatGroupIds := cast.ToString(i.GetData("wechat_group_ids"))

		ids := strings.Split(wechatGroupIds,",")

		wechatGroupMaps := make([]map[string]interface{},0)
		wechatGroupNames := make([]string,0)
		for j := range ids{
			wechatGroup, err := models.NewBindWechatGroup()
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
			wechatGroup.SetData("id",ids[j])
			wechatGroup.Row()
			wechatGroupMaps = append(wechatGroupMaps, wechatGroup.GetMap())
			wechatGroupNames= append(wechatGroupNames, wechatGroup.GetString("group_name"))
		}

		i.SetData("wechat_groups",wechatGroupMaps)
		i.SetData("wechat_group_names",strings.Join(wechatGroupNames,","))


		allCount := 0
		usedCount := 0
		passCount := 0	//通过数量
		waitPassCount := 0	//待通过数量
		failCount := 0		//失败数量
		invalidCount := 0	//无效数量

		//总数量
		dataGroupIds := i.GetString("data_group_ids")
		dataGroupIdsArr := strings.Split(dataGroupIds,",")
		for index := range dataGroupIdsArr {
			importData,_ := models.NewImportData()

			importDatas := importData.GetCollection()
			importDatas.AddFieldToSelect("{count(m.id)} as pcount", "")
			importDatas.AddFieldToFilter("import_file_id","eq",dataGroupIdsArr[index])
			importDatas.JoinLeft("ym_add_friend_log as dl", "m.wechat_id=dl.add_phone", "dl.state")
			importDatas.AddGroup("dl.state")
			importDatas.DisableAllFields()
			importDatas.Load()


			for _, countItem := range importDatas.GetItems() {
				allCount+= countItem.GetInt("pcount")
				if countItem.GetInt("state") == 1 {
					usedCount+= countItem.GetInt("pcount")
				}else if countItem.GetInt("state") == 2{
					usedCount+= countItem.GetInt("pcount")
				}else if countItem.GetInt("state") == 3{
					usedCount+= countItem.GetInt("pcount")
				}else if countItem.GetInt("state") == 4{
					usedCount += countItem.GetInt("pcount")
				}
			}
		}


		addFriendLog,_ := models.NewAddFriendLog()

		addFriendLogs := addFriendLog.GetCollection()
		addFriendLogs.AddFieldToSelect("{count(m.id)} as pcount", "")
		addFriendLogs.AddFieldToSelect("state", "")
		addFriendLogs.AddFieldToFilter("add_friend_plan_id","eq",id)
		addFriendLogs.AddGroup("m.state")
		addFriendLogs.DisableAllFields()
		addFriendLogs.Load()
		for _, countItem := range addFriendLogs.GetItems() {
			if countItem.GetInt("state") == 1 {
				passCount+= countItem.GetInt("pcount")
			}else if countItem.GetInt("state") == 2{
				waitPassCount+= countItem.GetInt("pcount")
			}else if countItem.GetInt("state") == 3{
				failCount+= countItem.GetInt("pcount")
			}else if countItem.GetInt("state") == 4{
				invalidCount += countItem.GetInt("pcount")
			}
		}

		i.SetData("all_count",allCount)
		i.SetData("waitadd_count",allCount - usedCount)
		//i.SetData("waitadd_count",allCount - passCount - waitPassCount - invalidCount - failCount)
		i.SetData("pass_count",passCount)
		i.SetData("waitpass_count",waitPassCount)
		i.SetData("invalid_count",invalidCount)
		i.SetData("fail_count",failCount)
	})
	s.list(w, c)
}

//历史记录
func (s AddFriendPlan) Logs(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	state := r.PostFormValue("state")
	addPhone := r.PostFormValue("add_phone")
	createDate := r.PostFormValue("create_date")
	planId := r.PostFormValue("plan_id")
	userID := s.getCurrentUserId(r)



	m, err := models.NewAddFriendLog()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	if state != "" {
		c.AddFieldToFilter("state","eq",cast.ToBool(state))
	}
	if addPhone != "" {
		c.AddFieldToFilter("add_phone","eq",addPhone)
	}
	if planId != "" {
		c.AddFieldToFilter("add_friend_plan_id","eq",planId)
	}else {
		var planIds []string
		addFriendPlan,_ := models.NewAddFriendPlan()
		addFriendPlans := addFriendPlan.GetCollection()
		addFriendPlans.AddFieldToFilter("user_id","eq",userID)
		addFriendPlans.Load()
		addFriendPlans.Each(func(item *db.Item) {
			planIds = append(planIds, item.GetString("id"))
		})
		c.AddFieldToFilter("add_friend_plan_id","in",strings.Join(planIds,"','"))
	}
	if createDate != "" {
		//c.AddFieldToFilter("create_date","like",createDate+"%")
		c.AddFieldToFilter("create_date","gt",createDate + " 00:00:00")
		c.AddFieldToFilter("create_date","lt",createDate + " 23:59:59")
	}
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	var wechatIDs []string
	var allWechatIDs []string

	c.Each(func(item *db.Item) {
		wechatIDs = append(wechatIDs, item.GetString("wechat_id"))

		allWechatIDs = append(allWechatIDs, item.GetString("wechat_id"))
		allWechatIDs = append(allWechatIDs, item.GetString("add_wechat_id"))
	})

	wechatMessage,_ := models.NewWechatMessage()
	wechatMessages := wechatMessage.GetCollection()
	wechatMessages.AddFieldToFilter("from_id","in",strings.Join(allWechatIDs,"','"))
	wechatMessages.AddFieldToFilter("to_id","in",strings.Join(allWechatIDs,"','"))
	wechatMessages.AddFieldToFilter("type","eq",1)
	wechatMessages.AddOrder("id desc")
	wechatMessages.Load()
	//fmt.Println("wechatMessages lenth: ", len(wechatMessages.GetItems()))
	rawMap := make(map[string]string)
	wechatMessages.Each(func(item *db.Item) {
		k := item.GetString("from_id") + item.GetString("to_id")
		v := item.GetString("raw")
		if _,ok := rawMap[k]; !ok {
			rawMap[k] = v
		}
	})

	//fmt.Println("rawMap: ")
	//fmt.Println(rawMap)

	wechatPhoneMap := getWechatPhoneMap(wechatIDs)

	c.Each(func(i *db.Item) {
		wechatID := i.GetString("wechat_id")
		i.SetData("wechat_mobile",wechatPhoneMap[wechatID])

		i.SetData("dispatch_msg",rawMap[i.GetString("wechat_id") + i.GetString("add_wechat_id")])
		i.SetData("receive_msg",rawMap[i.GetString("add_wechat_id") + i.GetString("wechat_id")])
	})
	s.list(w, c)
}

func getWechatPhoneMap(wechatIDs []string) map[string]string {
	wechat,_ := models.NewBindWechat()
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("wechat_id","in",strings.Join(wechatIDs,"','"))
	wechats.Load()
	maps := make(map[string]string)
	wechats.Each(func(item *db.Item) {
		maps[item.GetString("wechat_id")] = item.GetString("wechat_mobile")
	})
	return maps
}

//加人统计
func (s AddFriendPlan) Statistics(w http.ResponseWriter, r *http.Request) {

	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	createDate := r.PostFormValue("create_date")

	m,_ := models.NewBindWechatGroup()
	c := m.GetCollection()
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	c.Each(func(item *db.Item) {
		wechat,_ := models.NewBindWechat()
		wechats := wechat.GetCollection()
		wechats.AddFieldToFilter("group_id","eq",item.GetString("id"))
		wechats.Load()
		item.SetData("allCount", len(wechats.GetItems()))
		items := wechats.GetItems()
		var wxidArr []string
		closedCount := 0
		for i := range items{
			wxidArr = append(wxidArr, items[i].GetString("wechat_id"))
			if items[i].GetInt("status") == 2 {
				closedCount ++
			}
		}
		loginMap := getLoginMap(wxidArr,s.getCurrentUserId(r),s.getCurrentWxId(r))

		onlineCount := 0

		for _,v := range loginMap{
			if v == 12007 {
				onlineCount ++
			}
		}
		item.SetData("onlineCount", onlineCount)
		item.SetData("closedCount", closedCount)

		//统计
		addFriendLog,_ := models.NewAddFriendLog()
		addFriendLogs := addFriendLog.GetCollection()
		addFriendLogs.AddFieldToFilter("wechat_id","in",strings.Join(wxidArr,"','"))
		addFriendLogs.AddFieldToFilter("create_date","gteq",createDate+" 00:00:00")	//>=
		addFriendLogs.AddFieldToFilter("create_date","lteq",createDate+" 23:59:59")	//<=
		addFriendLogs.Load()
		//请求次数YmAddFriendLog
		//requestCount := len(addFriendLogs.GetItems())
		//通过好友YmAddFriendLog State=1
		passCount := 0
		//单向粉YmAddFriendLog IsOnewayFans=true
		onewayCount := 0
		//待通过YmAddFriendLog State=2
		waitPassCount := 0

		addFriendLogs.Each(func(i *db.Item) {
			state := i.GetInt("state")
			if state == 1 {
				passCount ++
			}else if state == 2 {
				waitPassCount ++
			}

			if i.GetBool("is_oneway_fans") {
				onewayCount ++
			}
		})
		//请求成功数
		requestCount := passCount + waitPassCount
		//通过率
		passProbability := utils.GetPercentage(cast.ToFloat64(passCount),cast.ToFloat64(requestCount),2)
		//封号率
		closeProbability := utils.GetPercentage(cast.ToFloat64(closedCount),cast.ToFloat64(onlineCount),2)

		item.SetData("requestCount", requestCount)
		item.SetData("passCount", passCount)
		item.SetData("onewayCount", onewayCount)
		item.SetData("waitPassCount", waitPassCount-onewayCount)
		item.SetData("passProbability", passProbability)
		item.SetData("closeProbability", closeProbability)

	})
	s.list(w, c)
}

//加人统计列表(单个微信组)
func (s AddFriendPlan) GroupStatistics(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	groupID := r.PostFormValue("group_id")
	startTime := r.PostFormValue("start_time")
	endTime := r.PostFormValue("end_time")

	wechat,_ := models.NewBindWechat()
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("group_id","eq",groupID)

	if size != "" {
		wechats.SetPageSize(cast.ToInt64(size))
		wechats.SetCurPage(cast.ToInt64(page))
	}
	wechats.Load()

	var wxidArr []string
	wechats.Each(func(wechatItem *db.Item) {
		wxidArr = append(wxidArr, wechatItem.GetString("wechat_id"))

		addFriendLog,_ := models.NewAddFriendLog()
		addFriendLogs := addFriendLog.GetCollection()
		addFriendLogs.AddFieldToFilter("wechat_id","eq",wechatItem.GetString("wechat_id"))
		if startTime != "" {
			addFriendLogs.AddFieldToFilter("create_date","gteq",startTime+" 00:00:00")
		}
		if endTime != "" {
			addFriendLogs.AddFieldToFilter("create_date","lteq",endTime+" 23:59:59")
		}
		addFriendLogs.Load()

		//requestCount := 0
		passCount := 0
		waitPassCount := 0
		addFriendLogs.Each(func(item *db.Item) {
			state := item.GetInt("state")//状态(通过1/待通过2/失败3/无效4)
			//requestCount ++
			if state == 1 {
				passCount ++
			}else if state == 2 {
				waitPassCount ++
			}
		})
		requestCount := passCount + waitPassCount
		//通过率
		passProbability := utils.GetPercentage(cast.ToFloat64(passCount),cast.ToFloat64(requestCount),2)

		wechatItem.SetData("requestCount",requestCount)
		wechatItem.SetData("passCount",passCount)
		wechatItem.SetData("waitPassCount",waitPassCount)
		wechatItem.SetData("passProbability",passProbability)
	})

	loginMap := getLoginMap(wxidArr,s.getCurrentUserId(r),s.getCurrentWxId(r))
	wechats.Each(func(item *db.Item) {
		item.SetData("onlineCode",loginMap[item.GetString("wechat_id")])
	})
	s.list(w, wechats)
}

func getLoginMap(wxidArr []string,userID,wechatID string) map[string]int {
	dataMap := make(map[string]interface{})
	dataMap["wxid_list"] = strings.Join(wxidArr,",")
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,wechatID)
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/batchcheckloginstatus",dataMap,heardMap)

	if err != nil {
		log.Println("BindWechatGroup List Error1: ",err)
	}

	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(data),&maps)
	if err != nil {
		log.Println("BindWechatGroup List Error2: ",err)
	}

	dataMaps := make(map[string]int)
	b,_ := json.Marshal(maps["Data"])
	err = json.Unmarshal(b,&dataMaps)
	if err != nil {
		log.Println("BindWechatGroup List Error3: ",err)
	}
	return dataMaps
}