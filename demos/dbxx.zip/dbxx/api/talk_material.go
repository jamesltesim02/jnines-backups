/*
@Time : 2019/5/28 10:58 
@Author : Lukebryan
@File : friends_circle_material.go
@Software: GoLand
*/
package api

import (
	"bufio"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type TalkMaterial struct {
	Base
}

//保存对话素材
func (s TalkMaterial) Save(w http.ResponseWriter, r *http.Request) {
	id := r.PostFormValue("id")
	talkMaterialGroupID := r.PostFormValue("group_id")
	content := r.PostFormValue("content")

	if talkMaterialGroupID == "" {
		http.Error(w, "分组ID不能为空", http.StatusBadRequest)
		return
	}
	if content == "" {
		http.Error(w, "内容不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewTalkMaterial()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	m.SetId(cast.ToInt64(id))
	m.SetData("content", content)
	m.SetData("talk_material_group_id", talkMaterialGroupID)
	m.SetData("user_id", s.getCurrentUserId(r))

	err = m.Save()

	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m.GetMap(), "操作成功")
		w.Write(rel)
		return
	}
}

func (s TalkMaterial) Import(w http.ResponseWriter, r *http.Request) {
	talkMaterialGroupID := r.PostFormValue("group_id")
	text, ok := r.MultipartForm.File["file"]

	if talkMaterialGroupID == "" {
		rel, _ := utils.JsonEncode(-1, nil, "缺少分组ID")
		w.Write(rel)
		return
	}

	lines := []string{}
	if ok {
		fd, _ := text[0].Open()

		buf := bufio.NewReader(fd)

		for {
			line, _, err := buf.ReadLine()
			if err == io.EOF {
				break
			}
			if string(line) != "" {
				lines = append(lines, string(line))
			}
		}
	}else {
		rel, _ := utils.JsonEncode(-1, nil, "缺少导入文件")
		w.Write(rel)
		return
	}

	var failStr []string
	for i := range lines{
		m, _ := models.NewTalkMaterial()
		m.SetData("content", lines[i])
		m.SetData("user_id", s.getCurrentUserId(r))
		m.SetData("talk_material_group_id", talkMaterialGroupID)
		err := m.Save()
		if err != nil {
			log.Println("TalkMaterial Save Error: ",err)
			failStr = append(failStr, lines[i])
			continue
		}
	}

	rel, _ := utils.JsonEncode(0, failStr, "导入成功")
	w.Write(rel)
}

//获取单个
func (TalkMaterial) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewTalkMaterial()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	m.Load(id)

	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

//删除
func (TalkMaterial) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewTalkMaterial()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("TalkMaterialGroup Delete Error: ",err)
			return
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}
//对话素材列表
func (s TalkMaterial) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	content := r.PostFormValue("content")
	groupID := r.PostFormValue("group_id")

	m, err := models.NewTalkMaterial()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()


	if content != "" {
		c.AddFieldToFilter("content","like","%"+content+"%")
	}
	if groupID != "" {
		c.AddFieldToFilter("talk_material_group_id","eq",groupID)
	}
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()
	s.list(w, c)
}



