package api

import (
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

type MaterialCategory struct {
	Base
}

func (s MaterialCategory) Create(w http.ResponseWriter, r *http.Request) {
	title := r.PostFormValue("title")
	snsMaterialGroupID := r.PostFormValue("sns_material_group_id")
	if title == "" {
		http.Error(w, "名字不能为空", http.StatusBadRequest)
		return
	}

	m, err := models.NewMaterialCategory()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	m.SetData("title", title)
	m.SetData("sns_material_group_id", snsMaterialGroupID)
	m.SetData("user_id", s.getCurrentUserId(r))
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m.GetId(), "创建成功")
		w.Write(rel)
		return
	}
}

func (s MaterialCategory) Update(w http.ResponseWriter, r *http.Request) {
	title := r.PostFormValue("title")
	snsMaterialGroupID := r.PostFormValue("sns_material_group_id")
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewMaterialCategory()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	m.SetId(id)
	if title != "" {
		m.SetData("title", title)
	}
	if snsMaterialGroupID != "" {
		m.SetData("sns_material_group_id", snsMaterialGroupID)
	}

	m.SetData("user_id", s.getCurrentUserId(r))
	err = m.Save()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	} else {
		rel, _ := utils.JsonEncode(0, m.GetId(), "修改成功")
		w.Write(rel)
		return
	}
}

func (MaterialCategory) Get(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewMaterialCategory()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	m.Load(id)
	rel, _ := utils.JsonEncode(0, m.GetMap(), "")
	w.Write(rel)
}

func (MaterialCategory) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("id")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewMaterialCategory()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("TalkMaterialGroup Delete Error: ",err)
			return
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}

func (mc MaterialCategory) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")

	snsMaterialGroup,err := models.NewSnsMaterialGroup()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	m, err := models.NewMaterialCategory()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	c := m.GetCollection()
	c.AddFieldToFilter("user_id","eq",mc.getCurrentUserId(r))
	c.AddOrder("id desc")
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.Load()

	c.Each(func(item *db.Item) {
		//素材数量
		material,_ := models.NewMaterial()
		materials := material.GetCollection()
		materials.AddFieldToFilter("category_id","eq",item.GetString("id"))
		size := materials.GetSize()
		item.SetData("material_count", size)

		//朋友圈素材组名
		snsMaterialGroup.Load(item.GetInt64("sns_material_group_id"))
		item.SetData("sns_material_name",snsMaterialGroup.GetString("name"))

		//绑定的微信数量
		materials2 := material.GetCollection()
		materials2.AddFieldToFilter("category_id","eq",item.GetString("id"))
		materials2.AddFieldToFilter("wechat_id","notnull","")
		bindCount := materials2.GetSize()

		item.SetData("bind_count",bindCount)
	})

	mc.list(w, c)
}
