package api

import (
	"bufio"
	"bytes"
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"errors"
	"github.com/spf13/cast"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"strconv"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/task"
	"wechatmanagent/utils"
)

type Account struct {
	Base
}

func (a Account) BatchLogin(w http.ResponseWriter, r *http.Request) {

	device_type := r.PostFormValue("device_type")
	group_id := r.PostFormValue("group_id")
	userID := a.getCurrentUserId(r)
	wechatID := a.getCurrentWxId(r)
	err := r.ParseMultipartForm(MultipartFormMaxMemory)
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	f, ok := r.MultipartForm.File["account_txt"]
	if !ok {
		rel, _ := utils.JsonEncode(-1, nil, "账号数据文件不能为空")
		w.Write(rel)
		return
	}
	if len(f) > 0 {
		//保存记录
		wechatFileID,err := saveWechatFile(f[0],userID,device_type)
		if err != nil {
			rel, _ := utils.JsonEncode(-1, nil, err.Error())
			w.Write(rel)
			return
		}

		go saveWechatFileAndBatchlogin(f[0],userID,wechatID,device_type,group_id, wechatFileID)
		rel, _ := utils.JsonEncode(0, nil, "已在后台进行")
		w.Write([]byte(rel))
	} else {
		rel, _ := utils.JsonEncode(-1, nil, "账号数据文件不能为空")
		w.Write(rel)
	}
}

func saveWechatFileAndBatchlogin(f *multipart.FileHeader,userID,wechatID,device_type,group_id string, wechatFileID int) {
	importDataMap := make(map[string]string)
	var lines [][]string

	fd, _ := f.Open()
	defer fd.Close()
	buf := bufio.NewReader(fd)

	reimport := 0
	newImport := 0
	count := 0
	defer func() {  //保存进度信息
		wechatFile,_ := models.NewWechatFile()
		wechatFile.SetData("id", wechatFileID)
		wechatFile.SetData("new_count", newImport)
		wechatFile.SetData("imported_count", reimport)
		if count == newImport+reimport {
			wechatFile.SetData("state", 1)
		} else {
			wechatFile.SetData("state", 2)
		}
		wechatFile.Save()
	}()

	arr := make([]string,0)
	i := 0
	for {
		line, _, err := buf.ReadLine()
		if err == io.EOF {
			lines = append(lines, arr)
			i = 0
			arr = make([]string,0)
			break
		}

		parts := strings.Split(string(line), AccountFileSep)
		if len(parts) != 3 {
			continue
		}

		count++
		importDataMap[parts[0]] = string(line)

		//修改大小时修改这个i即可
		if i == 5{
			lines = append(lines, arr)
			i = 0
			arr = make([]string,0)
		}
		arr = append(arr, string(line))
		i ++
	}

	//先账号入库
	for i := range lines{
		arr := lines[i]
		fmt.Println("lines[i]: ",arr)
		errs,wxids := importWechats(device_type,group_id,userID,wechatID, wechatFileID, arr)
		for j := range wxids{

			if errs[j] == "已导入，请不要重复导入" {
				reimport++
			} else {
				newImport++
			}

			saveLoginLog(wechatFileID,wxids[j],errs[j],importDataMap[wxids[j]],0)
		}
	}

	// 再异步登录账号
	go func() {
		for i := range lines{
			arr := lines[i]
			fmt.Println("lines[i]: ",arr)
			_,tokens,states,_ := batchlogin(device_type,group_id,userID,wechatID, wechatFileID, arr)
			for j := range tokens{
				if states[j] == 12007 {
					task.Subcribe(tokens[j],userID)
					go task.SaveOldFriends(tokens[j],userID)
				}
			}
		}
	}()
}


type wechatImportResp struct {
	Code int
	Data struct {
		Errors []string `json:"errors"`
		Wxids []string `json:"wxids"`
	}
	Msg string
}

func importWechats(deviceType,groupID,userID,wechatID string, wechatFileID int, accountList []string ) ([]string, []string) {
	errs := make([]string, 0)
	wxids := make([]string, 0)
	fmt.Println("accountList: ",accountList)
	if len(accountList) == 0 {
		log.Println("账号列表不能为空")
		return errs, wxids
	}

	dataMap := make(map[string]interface{})
	dataMap["device_type"] = deviceType
	dataMap["group_id"] = groupID
	dataMap["wechat_file_id"] = wechatFileID
	dataMap["account_list"] = strings.Join(accountList,"\n")

	fmt.Println(strings.Join(accountList,"\n"))

	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,wechatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/bindwechat/import",dataMap,heardMap)

	if err != nil {
		log.Println("bindwechat/import error : ",err)
		for i := range accountList {
			errs = append(errs, err.Error())
			wxids = append(wxids, accountList[i])
		}
	}

	importResp := new(wechatImportResp)
	err = json.Unmarshal([]byte(resp),importResp)
	if err != nil {
		errs = append(errs, err.Error())
	}

	errs = importResp.Data.Errors
	wxids = importResp.Data.Wxids
	return errs, wxids
}


func batchlogin(deviceType,groupID,userID,wechatID string, wechatFileID int, accountList []string ) ([]string, []string, []int, []int) {
	var errors []string
	var tokens []string
	var states []int
	var codes []int
	fmt.Println("accountList: ",accountList)
	if len(accountList) == 0 {
		log.Println("账号列表不能为空")
		return errors,tokens,states,codes
	}

	dataMap := make(map[string]interface{})
	dataMap["device_type"] = deviceType
	dataMap["group_id"] = groupID
	dataMap["wechat_file_id"] = wechatFileID
	dataMap["account_list"] = strings.Join(accountList,"\n")

	fmt.Println(strings.Join(accountList,"\n"))

	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,wechatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/batchlogin",dataMap,heardMap)

	if err != nil {
		log.Println("account/batchlogin error : ",err)
		for i := range accountList {
			errors = append(errors, err.Error())
			tokens = append(tokens, accountList[i])
			states = append(states, -11113)
			codes = append(codes, -9)
		}
	}

	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(resp),&maps)
	if err != nil {
		log.Println("batchlogin json.Unmarshal error : ",err)
	}
	b,err := json.Marshal(maps["Data"])
	if err != nil {
		log.Println("batchlogin json.Marshal error : ",err)
	}
	err = json.Unmarshal(b,&maps)
	if err != nil {
		log.Println("batchlogin json.Unmarshal error : ",err)
	}
	b3,err := json.Marshal(maps["errors"])
	if err != nil {
		log.Println("batchlogin json.Marshal error : ",err)
	}
	b4,err := json.Marshal(maps["tokens"])
	if err != nil {
		log.Println("batchlogin json.Marshal error : ",err)
	}
	b5,err := json.Marshal(maps["states"])
	if err != nil {
		log.Println("batchlogin json.Marshal error : ",err)
	}
	b6,err := json.Marshal(maps["codes"])
	if err != nil {
		log.Println("batchlogin json.Marshal error : ",err)
	}

	err = json.Unmarshal(b3,&errors)
	if err != nil {
		log.Println("errors json.Marshal error : ",err)
	}
	err = json.Unmarshal(b4,&tokens)
	if err != nil {
		log.Println("tokens json.Marshal error : ",err)
	}
	err = json.Unmarshal(b5,&states)
	if err != nil {
		log.Println("states json.Marshal error : ",err)
	}
	err = json.Unmarshal(b6,&codes)
	if err != nil {
		log.Println("codes json.Marshal error : ",err)
	}
	return errors,tokens,states,codes
}

func saveLoginLog(wechatFileID int,addPhone,msg,data string,state int) {

	if msg == "" {
		msg = "导入成功"
	}

	loginLog,_ := models.NewLoginLog()
	loginLog.SetData("wechat_file_id",wechatFileID)
	loginLog.SetData("wechat_id",addPhone)
	loginLog.SetData("data",data)
	loginLog.SetData("state",state)
	loginLog.SetData("msg",msg)
	error := loginLog.Save()
	if error != nil {
		log.Println("loginLog save error: ",error)
	}
}

func saveWechatFile(f *multipart.FileHeader,userID,deviceType string) (wechatFileID int,err error) {
	lines := [][]string{}
	fd, _ := f.Open()
	defer fd.Close()


	m5 := md5.New()
	data, _ := ioutil.ReadAll(fd)
	m5.Write(data)
	md5 := m5.Sum(nil)
	md5String := hex.EncodeToString(md5)

	wechatFile,_ := models.NewWechatFile()
	c := wechatFile.GetCollection()
	c.AddFieldToNewFilter("md5", "eq", md5String)
	c.AddOrder("create_date desc")
	c.SetPageSize(1)
	c.Load()
	items := c.GetItems()
	if len(items) == 1 {
		if items[0].GetInt("state") == 0 {
			return 0, errors.New("此任务正在进行中,请耐心等待结束")
		}
	}

	buf := bufio.NewReader(bytes.NewReader(data))
	count := 0
	for {
		line, _, err := buf.ReadLine()
		if err == io.EOF {
			break
		}
		parts := strings.Split(string(line), AccountFileSep)
		if len(parts) != 3 {
			continue
		}

		count++
		lines = append(lines, parts)
	}

	//var phones []string
	//for i := range lines{
	//	phones = append(phones, lines[i][0])
	//}

	//wechat,_ := models.NewBindWechat()
	//wechats := wechat.GetCollection()
	//wechats.AddFieldToFilter("wechat_mobile","in",strings.Join(phones,"','"))
	//wechats.Load()

	//newCount := len(phones)
	//if len(wechats.GetItems()) > 0 {
	//	newCount = newCount - len(wechats.GetItems())
	//	if newCount < 0 {
	//		newCount = 0
	//	}
	//}
	//importedCount := len(wechats.GetItems())

	wechatFile.SetData("name",f.Filename)
	wechatFile.SetData("user_id",userID)
	wechatFile.SetData("data_type",deviceType)//1  62数据  2  A16数据
	wechatFile.SetData("new_count",0)
	wechatFile.SetData("imported_count",0)
	wechatFile.SetData("state",0)  // 0进行中， 1已完成， 2导入完部分数据，请重新导入本次文本
	var log_info = fmt.Sprintf("本次总共需要导入%d账号", count)
	wechatFile.SetData("log_info",log_info)
	wechatFile.SetData("md5", md5String)

	err = wechatFile.Save()
	if err != nil {
		log.Println(err)
	}
	wechatFileID = wechatFile.GetInt("id")
	return
}

type loginResp struct {
	Code int
	Data struct {
		LoginState int `json:"login_state"`
		Wxid string `json:"wxid"`
	}
	Msg string
}

func (a Account) login(r *http.Request,socksID, wxid, password, sixData,deviceType string) string {

	dataMap := make(map[string]interface{})
	dataMap["wxid"] = wxid
	dataMap["password"] = password
	dataMap["device_type"] = deviceType

	if sixData != "" {
		dataMap["six_data"] = sixData
	}
	if socksID != "" {
		dataMap["socks_id"] = socksID
	}
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/login",dataMap,heardMap)
	if err != nil {
		return resp
	}

	rel := new(loginResp)
	json.Unmarshal([]byte(resp), rel)
	if rel.Code == 0 && rel.Data.LoginState == 12007{
		go task.Subcribe(wxid,a.getCurrentUserId(r))
		go task.SaveOldFriends(wxid,a.getCurrentUserId(r))
	}

	return resp
}

func (a Account) Login(w http.ResponseWriter, r *http.Request) {
	wxid := r.PostFormValue("wxid")
	password := r.PostFormValue("password")
	sixData := r.PostFormValue("six_data")
	deviceType := r.PostFormValue("device_type")
	socksID := r.PostFormValue("socks_id")

	resp := a.login(r,socksID, wxid, password, sixData,deviceType)
	w.Write([]byte(resp))
}

func (a Account) LoginByQRCode(w http.ResponseWriter, r *http.Request) {
	uuid := r.PostFormValue("uuid")
	socks_id := r.PostFormValue("socks_id")
	//cli := client.NewWechatClient("", "", "")
	//socks, err := models.NewSocks()
	//if err != nil {
	//	http.Error(w, err.Error(), http.StatusInternalServerError)
	//	return
	//}
	//
	//list := socks.GetListByUserId(a.getCurrentUserId(r))
	//if len(list) > 0 {
	//	idx := rand.Int63n(int64(len(list)))
	//	item := list[idx]
	//	cli.SetSocks(&client.SocksItem{item.GetString("ip") + ":" + item.GetString("socks_port"), item.GetString("username"), item.GetString("password")})
	//}
	//
	//err = cli.Init()
	//if err != nil {
	//	http.Error(w, err.Error(), http.StatusInternalServerError)
	//	return
	//}

	dataMap := make(map[string]interface{})
	if uuid != "" {
		dataMap["uuid"] = uuid
	}
	if socks_id != "" {
		dataMap["socks_id"] = socks_id
	}

	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	buf, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/loginbyqrcode",dataMap,heardMap)
	//buf, err := cli.Login()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	//a.setCli(r, cli)
	//rel, _ := utils.JsonEncode(0, buf, "二维码生成成功")
	w.Write([]byte(buf))
}

func (a Account) BatchCheckLoginStatus(w http.ResponseWriter, r *http.Request) {
	wxidList := r.PostFormValue("wxid_list")
	//wxids := strings.Split(wxidList, ",")
	//clis := a.getClis(r, wxids)
	//data := make(map[string]int32)
	//for i, cli := range clis {
	//	data[wxids[i]] = client.LOGIN_STATE_UNLOGIN
	//	if cli != nil {
	//		data[wxids[i]] = cli.GetConn().GetLoginState()
	//	}
	//}

	dataMap := make(map[string]interface{})
	dataMap["wxid_list"] = wxidList
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/batchcheckloginstatus",dataMap,heardMap)
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(data),&maps)
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		log.Println(err)
		return
	}
	resultDataMap := make(map[string]int)
	b2,err := json.Marshal(maps["Data"])
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		log.Println(err)
		return
	}
	err = json.Unmarshal(b2,&resultDataMap)
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		log.Println(err)
		return
	}

	go autoauth(a.getCurrentUserId(r),resultDataMap)

	w.Write([]byte(data))
}

func autoauth(userID string,loginStatus map[string]int) {
	for wechatID,state := range loginStatus{
		if state == 120005 || state == 12009{
			dataMap := make(map[string]interface{})
			heardMap := make(map[string]string)
			heardMap["Authorization"] = utils.GentToken(userID,wechatID)
			data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/autoauth",dataMap,heardMap)
			if err != nil {
				log.Println(err)
				return
			}
			log.Println("autoauth response: ",data)
		}
	}
}

func (a Account) CheckLoginQRCodeStatus(w http.ResponseWriter, r *http.Request) {

	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/checkloginqrcodestatus",dataMap,heardMap)
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	go func() {
		maps := make(map[string]interface{})
		err = json.Unmarshal([]byte(data),&maps)
		if err != nil {
			return
		}

		b2,err := json.Marshal(maps["Data"])
		if err != nil {
			return
		}
		err = json.Unmarshal(b2,&maps)
		if err != nil {
			return
		}
		wxid := cast.ToString(maps["wxid"])
		task.SaveOldFriends(wxid,a.getCurrentUserId(r))
		task.Subcribe(wxid,a.getCurrentUserId(r))
	}()

	w.Write([]byte(data))
}

func (a Account)  Verifyfriendswitch(w http.ResponseWriter, r *http.Request) {
	active := r.PostFormValue("active")
	userID := a.getCurrentUserId(r)
	wechatID := a.getCurrentWxId(r)
	dataMap := make(map[string]interface{})
	dataMap["active"] = cast.ToInt(active)
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,wechatID)
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/verifyfriendswitch",dataMap,heardMap)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(0, nil, "修改成功")
		w.Write(res)
	}
}

//wxid 不为空则优先id添加好友
func (a Account) AddFriend(w http.ResponseWriter, r *http.Request) {
	alias := r.PostFormValue("alias")
	phone := r.PostFormValue("phone")
	verifyContent := r.PostFormValue("verify_content")

	if alias == "" && phone == "" {
		http.Error(w, "不能同时为空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	if alias != "" {
		dataMap["alias"] = alias
	}else {
		dataMap["phone"] = phone
	}
	if verifyContent != "" {
		dataMap["verify_content"] = verifyContent
	}

	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/addfriend",dataMap,heardMap)
	//err := cli.AddFriend(wxid, phone)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(0, nil, "发送成功")
		w.Write(res)
		task.Subcribe(a.getCurrentWxId(r),a.getCurrentUserId(r))
	}
}

//上传通讯录添加好友
func (a Account) AddFriendWithIMContact(w http.ResponseWriter, r *http.Request) {
	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		rel, _ := utils.JsonEncode(-1, nil, "请先调用扫码登录接口")
		w.Write(rel)
		return
	}

	phoneList := r.PostFormValue("phone_list")
	mobile := r.PostFormValue("mobile")
	dataMap := make(map[string]interface{})
	dataMap["phone_list"] = phoneList
	dataMap["mobile"] = mobile
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/addfiendwithimcontact",dataMap,heardMap)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	} else {
		res, _ := utils.JsonEncode(0, nil, "添加成功")
		w.Write(res)
	}
}

//修改密码
func (a Account) ChangePassword(w http.ResponseWriter, r *http.Request) {
	oldPwd := r.PostFormValue("old_pwd")
	pwd := r.PostFormValue("pwd")
	isRand := cast.ToBool(r.PostFormValue("is_rand"))
	if oldPwd == "" {
		http.Error(w, "旧密码不能为空", http.StatusBadRequest)
		return
	}
	//是否随机
	if !isRand {
		if pwd == "" {
			http.Error(w, "新密码不能为空", http.StatusBadRequest)
			return
		}
	}else {
		pwd = utils.GetRandomString(8)
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	//TODO 判断是否时扫码登录

	dataMap := make(map[string]interface{})
	dataMap["old_pwd"] = oldPwd
	dataMap["pwd"] = pwd
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/changepassword",dataMap,heardMap)

	pwdHistory,_ := models.NewWechatPwdHistory()
	pwdHistory.SetData("wechat_id",a.getCurrentWxId(r))
	pwdHistory.SetData("old_pwd",oldPwd)
	pwdHistory.SetData("new_pwd",pwd)
	if err != nil {
		pwdHistory.SetData("msg","修改失败")
		w.Write([]byte(resp))
	} else {
		pwdHistory.SetData("msg","修改成功")
		w.Write([]byte(resp))
	}
	err = pwdHistory.Save()
	if err != nil {
		log.Println(err)
	}
}

// 更新个性签名
func (a Account) UpdatePersonality(w http.ResponseWriter, r *http.Request) {
	personality := r.PostFormValue("personality")
	if personality == "" {
		http.Error(w, "不能同时为空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["personality"] = personality
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/updatepersonality",dataMap,heardMap)
	//err := cli.UpdatePersonality(personality)
	if err != nil {
		w.Write([]byte(resp))
	} else {
		b, _ := models.NewBindWechat()
		b.SetData("wechat_id", a.getCurrentWxId(r))
		b.Row()
		b.SetData("signature", personality)
		b.Save()
		w.Write([]byte(resp))
	}
}

//更新性别 1男2女
func (a Account) ModifySex(w http.ResponseWriter, r *http.Request) {
	val := r.PostFormValue("sex")
	sexEnum, err := strconv.ParseInt(val, 10, 32)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	if sexEnum != 1 && sexEnum != 2 {
		http.Error(w, "性别只能为1或2", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	//user := &pb.ModUserInfo{
	//	Sex: proto.Int32(int32(sexEnum)),
	//}

	dataMap := make(map[string]interface{})
	dataMap["sex"] = sexEnum
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/modifysex",dataMap,heardMap)
	//err = cli.UpdateUserInfo(user)
	if err != nil {
		w.Write([]byte(resp))
	} else {
		b, _ := models.NewBindWechat()
		b.SetData("wechat_id", a.getCurrentWxId(r))
		b.Row()
		b.SetData("sex", sexEnum)
		b.Save()

		w.Write([]byte(resp))
	}
}

//更新地区
func (a Account) ModifyArea(w http.ResponseWriter, r *http.Request) {
	province := r.PostFormValue("province")
	city := r.PostFormValue("city")
	country := r.PostFormValue("country")
	if country == "" {
		country = "CN"
	}

	if province == "" || city == "" {
		http.Error(w, "省份或者城市不能空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["province"] = province
	dataMap["city"] = city
	dataMap["country"] = country
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/modifyarea",dataMap,heardMap)
	//err := cli.UpdateUserInfo(user)
	if err != nil {
		w.Write([]byte(resp))
	} else {
		b, _ := models.NewBindWechat()

		b.SetData("wechat_id", a.getCurrentWxId(r))
		b.Row()
		b.SetData("country", country)
		b.SetData("province", province)
		b.SetData("city", city)
		b.Save()
		w.Write([]byte(resp))
	}
}

//更新昵称
func (a Account) UpdateNickname(w http.ResponseWriter, r *http.Request) {
	nickname := r.PostFormValue("nickname")
	if nickname == "" {
		http.Error(w, "昵称不能为空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["nickname"] = nickname
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/updatenickname",dataMap,heardMap)
	//_, err := cli.UpdateNickname(nickname)
	if err != nil {
		w.Write([]byte(resp))
		return
	}

	b, _ := models.NewBindWechat()
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	b.SetData("wechat_id", a.getCurrentWxId(r))
	b.Row()
	b.SetData("nickname", nickname)
	b.Save()
	//res, _ := utils.JsonEncode(0, nil, "更新成功")
	//w.Write(res)
	w.Write([]byte(resp))
}

//修改微信号
func (a Account) UpdateAlias(w http.ResponseWriter, r *http.Request) {
	alias := r.PostFormValue("alias")
	if alias == "" {
		http.Error(w, "别名(微信号)不能为空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	b, err := models.NewBindWechat()
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	wechatItem := b.GetByWechatID(a.getCurrentWxId(r))
	if wechatItem.GetString("wechat_alias") != "" {
		res, _ := utils.JsonEncode(-1, nil, "微信号(别名)已经设置过了,不能再修改")
		w.Write(res)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["alias"] = alias
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/setalias",dataMap,heardMap)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	w.Write([]byte(resp))
}




//同步联系人
func (a Account) SyncContacts(w http.ResponseWriter, r *http.Request) {
	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/synccontacts",dataMap,heardMap)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	w.Write([]byte(resp))
}

//获取联系人
func (a Account) GetContacts(w http.ResponseWriter, r *http.Request) {
	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/getcontacts",dataMap,heardMap)
	//resp, err := cli.GetHdHeadImage(cli.GetWxid())
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}

	//res, _ := utils.JsonEncode(0, resp, "")
	w.Write([]byte(resp))
}

//获取头像
func (a Account) GetHeadImg(w http.ResponseWriter, r *http.Request) {
	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	//TODO	获取头像		传微信ID
	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/gethdheadimage",dataMap,heardMap)
	//resp, err := cli.GetHdHeadImage(cli.GetWxid())
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}

	//res, _ := utils.JsonEncode(0, resp, "")
	w.Write([]byte(resp))
}

//修改头像
func (a Account) ModifyHeadImg(w http.ResponseWriter, r *http.Request) {
	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	imgData := r.PostFormValue("img_data")
	imgPath := r.PostFormValue("image_path")

	//var data []byte
	var err error
	if imgData == "" {
		if strings.HasPrefix(imgPath, "http") {
		} else if imgPath != "" {
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
		} else {
			err := r.ParseMultipartForm(MultipartFormMaxMemory)
			if err != nil {
				rel, _ := utils.JsonEncode(-1, nil, err.Error())
				w.Write(rel)
				return
			}

			f, ok := r.MultipartForm.File["image_path"]
			if !ok || len(f) == 0 {
				rel, _ := utils.JsonEncode(-1, nil, "请上传图片或者素材路径")
				w.Write(rel)
				return
			}
		}
	} else {
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
	}

	dataMap := make(map[string]interface{})
	if imgData != "" {
		dataMap["img_data"] = imgData
	}
	if imgPath != "" {
		dataMap["image_path"] = imgPath
	}
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	heardMap["Content-Type"] = "application/x-www-form-urlencoded"
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/modifyheadimg",dataMap,heardMap)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
	} else {
		//TODO	修改头像
		w.Write([]byte(resp))
	}
}

func (a Account) Logout(w http.ResponseWriter, r *http.Request) {
	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/logout",dataMap,heardMap)
	//_, err := cli.Logout()
	if err != nil {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}
	w.Write([]byte(resp))
}

func (a Account) AddContactLabel(w http.ResponseWriter, r *http.Request) {
	label := r.PostFormValue("label")
	if label == "" {
		http.Error(w, "标签不能为空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["label"] = label
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/addcontactlabel",dataMap,heardMap)
	//_, err := cli.AddContactLabel(label)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	w.Write([]byte(resp))
	//res, _ := utils.JsonEncode(0, nil, "创建成功")
	//w.Write(res)
}

func (a Account) DelContactLabel(w http.ResponseWriter, r *http.Request) {
	label := r.PostFormValue("label")
	if label == "" {
		http.Error(w, "标签不能为空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["label"] = label
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/delcontactlabel",dataMap,heardMap)
	//_, err := cli.DelContactLabel(label)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	w.Write([]byte(resp))
	//res, _ := utils.JsonEncode(0, nil, "删除成功")
	//w.Write(res)
}

// 添加好友到标签
func (a Account) ModifyContactLabelList(w http.ResponseWriter, r *http.Request) {
	label := r.PostFormValue("label")
	wxid := r.PostFormValue("wxid")
	if label == "" || wxid == "" {
		http.Error(w, "标签或微信id不能为空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["label"] = label
	dataMap["wxid"] = wxid
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/modifycontactlabellist",dataMap,heardMap)
	//_, err := cli.ModifyContactLabelList(wxid, label)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	w.Write([]byte(resp))
	//res, _ := utils.JsonEncode(0, nil, "添加成功")
	//w.Write(res)
}

// 获取标签列表
func (a Account) GetContactLabelList(w http.ResponseWriter, r *http.Request) {
	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/getcontactlabellist",dataMap,heardMap)
	//resp, err := cli.GetContactLabelList()
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}

	//res, _ := utils.JsonEncode(0, resp, "")
	w.Write([]byte(resp))
}

//删除好友
func (a Account) DelFriend(w http.ResponseWriter, r *http.Request) {
	wxid := r.PostFormValue("wxid")
	if wxid == "" {
		http.Error(w, "微信id不能为空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["wxid"] = wxid
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/delcontactlabel",dataMap,heardMap)
	//_, err := cli.DeleteFriend(wxid)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	w.Write([]byte(resp))
	//res, _ := utils.JsonEncode(0, nil, "删除成功")
	//w.Write(res)
}

//拉黑好友
func (a Account) BanFriend(w http.ResponseWriter, r *http.Request) {
	wxid := r.PostFormValue("wxid")
	if wxid == "" {
		http.Error(w, "微信id不能为空", http.StatusBadRequest)
		return
	}

	isLogined := a.isLogined(r,a.getCurrentWxId(r))
	if !isLogined {
		http.Error(w, "未登录", http.StatusInternalServerError)
		return
	}

	dataMap := make(map[string]interface{})
	dataMap["wxid"] = wxid
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/banfriend",dataMap,heardMap)
	//_, err := cli.BanFriend(wxid, true)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}
	w.Write([]byte(resp))
	//res, _ := utils.JsonEncode(0, nil, "拉黑成功")
	//w.Write(res)
}

//生成03数据
func (a Account) GenerateClientCheckData(w http.ResponseWriter, r *http.Request) {
	STData := r.PostFormValue("st_data")
	if STData == "" {
		http.Error(w, "客户端信息不能为空", http.StatusBadRequest)
		return
	}

	dataMap := make(map[string]interface{})
	//dataMap["wxid"] = a.getCurrentWxId(r)
	dataMap["st_data"] = STData
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/banfriend",dataMap,heardMap)
	//data, err := client.GenerateClientCheckData(STData)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}

	//res, _ := utils.JsonEncode(0, base64.StdEncoding.EncodeToString([]byte(data)), "")
	//w.Write(res)
	w.Write([]byte(data))
}

//搜索wxid或者群id
func (a Account) SearchContact(w http.ResponseWriter, r *http.Request) {
	dataMap := make(map[string]interface{})
	dataMap["id"] = a.getCurrentWxId(r)
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/searchcontact",dataMap,heardMap)
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(res)
		return
	}

	w.Write([]byte(data))
}

//授权登录手机端/ipad端
func (a Account) Accessqrlogin(w http.ResponseWriter, r *http.Request) {
	err := r.ParseMultipartForm(MultipartFormMaxMemory)
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}
	_, ok := r.MultipartForm.File["file"]
	if !ok {
		rel, _ := utils.JsonEncode(-1, nil, "数据文件不能为空")
		w.Write(rel)
		return
	}

	imgPathArrs, errs := a.uploadFile(r, "file",config.Sysconfig.FileSavePath + "/static/img/")

	if len(errs) > 0 {
		res, _ := utils.JsonEncode(-1, nil, errs[0].Error())
		w.Write(res)
		return
	}

	imgData, err := ioutil.ReadFile(config.Sysconfig.FileSavePath + "/" + imgPathArrs[0][2])
	if err != nil {
		res, _ := utils.JsonEncode(-1, nil, "文件读取错误: "+err.Error())
		w.Write(res)
		return
	}
	qrData := base64.StdEncoding.EncodeToString(imgData)

	dataMap := make(map[string]interface{})
	dataMap["QRData"] = qrData
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/accessqrlogin",dataMap,heardMap)
	//_, err := cli.BanFriend(wxid, true)
	if err != nil {
		resp, err = utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/authorizemanuallogin",dataMap,heardMap)
		if err != nil {
			res, _ := utils.JsonEncode(-1, nil, err.Error())
			w.Write(res)
			return
		}
	}
	w.Write([]byte(resp))
	//res, _ := utils.JsonEncode(0, nil, "拉黑成功")
	//w.Write(res)
}


//注意:没有UserID的
func (a Account) CheckFriendPassed(w http.ResponseWriter, r *http.Request) {

	//wechatID := r.PostFormValue("belong_wxid")	//属于谁的消息
	raw := r.PostFormValue("raw")	//消息内容
	fromwechatID := r.PostFormValue("from_id")	//发送给谁的		//手机号的微信ID
	robotWechatID := r.PostFormValue("to_id")	//发送给谁的			//机器人
	types := r.PostFormValue("type")	//消息类型
	//createTime := r.PostFormValue("create_time")	//create_time

	if types != "1" && types != "40" && types != "37" {
		return
	}

	if strings.Index(raw,"腾讯新闻") != -1 || fromwechatID == "weixin" || strings.Index(fromwechatID,"@chatroom") != -1{
		return
	}

	log.Println("type: ",types,",from_id: ",fromwechatID,"towechatID: ",robotWechatID,"raw: ",raw)

	if types == "40" {
		go dealWithUploadMcontact(robotWechatID,raw)
	}else if types == "1" {
		go dealWithPassFriend(fromwechatID,robotWechatID,raw)
	}else if types == "37" {	//加机器人回调处理
		go dealWithAddRobot(fromwechatID,robotWechatID,raw,types)
	}
}

//处理加机器人回调
func dealWithAddRobot(fromwechatID,robotWechatID,raw,types string) {
	wechatLog,err := models.NewWechatLog()
	if err != nil {
		return
	}
	wechatLog.SetData("from_wechat_id",fromwechatID)
	wechatLog.SetData("to_wechat_id",robotWechatID)
	wechatLog.SetData("types",types)
	wechatLog.SetData("raw",raw)
	err = wechatLog.Save()
	if err != nil {
		log.Println("wechatLog save error: ",err)
	}

	go dealwithAgainAddFriend(robotWechatID,raw)

	return
}

//二次请求
func dealwithAgainAddFriend(wechatID,raw string) {
	if strings.Index(raw,"<msg") != -1 {

		//对方微信号
		fromusername := raw[strings.Index(raw,"fromusername=\"")+14 : ]
		fromusername = fromusername[ : strings.Index(fromusername,"\"")]

		//V1
		encryptusername := raw[strings.Index(raw,"encryptusername=\"")+17 : ]
		encryptusername = encryptusername[ : strings.Index(encryptusername,"\"")]
		//V2
		ticket := raw[strings.Index(raw,"ticket=\"")+8 : ]
		ticket = ticket[ : strings.Index(ticket,"\"")]

		//replayaddfriendreq("1",wechatID,ticket,"找你有事,通过一下","10")

		//获取加人历史记录数据
		phoneV1v2,err := models.NewPhoneV1v2()
		if err != nil {
			return
		}
		phoneV1v2s := phoneV1v2.GetCollection()
		phoneV1v2s.AddFieldToFilter("wechat_id","eq",wechatID)
		phoneV1v2s.AddFieldToFilter("v1","eq",encryptusername)
		phoneV1v2s.Load()
		v1v2Items := phoneV1v2s.GetItems()
		if len(v1v2Items) > 0 {

			addPhone := v1v2Items[0].GetString("add_phone")
			userID := v1v2Items[0].GetString("user_id")


			addFriendLog,err := models.NewAddFriendLog()
			if err != nil {
				return
			}
			addFriendLogs := addFriendLog.GetCollection()
			addFriendLogs.AddFieldToFilter("wechat_id","eq",wechatID)
			addFriendLogs.AddFieldToFilter("add_phone","eq",addPhone)
			addFriendLogs.Load()
			addFriendLogItems := addFriendLogs.GetItems()
			if len(addFriendLogItems) > 0 {
				scene := addFriendLogItems[0].GetString("scene")
				addFriendPlanID := addFriendLogItems[0].GetInt64("add_friend_plan_id")
				addFriendPlan,err := models.NewAddFriendPlan()
				if err != nil {
					return
				}
				addFriendPlan.Load(addFriendPlanID)

				//TODO 获取二次请求验证语
				contents := task.GetMessage([]string{addPhone},addFriendPlan.GetString("verify_messages2"),wechatID)
				content := "通过了告诉你"
				if len(contents) > 0 {
					content = contents[addPhone]
				}

				replayaddfriendreq(userID,wechatID,ticket,content,scene)
			}


		}
	}
}

func replayaddfriendreq(userID,wechatID,v2,content,scene string) {
	//wxid  v2_ticket  content  scene
	dataMap := make(map[string]interface{})
	dataMap["wxid"] = wechatID
	dataMap["v2_ticket"] = v2
	dataMap["content"] = content
	dataMap["scene"] = scene
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,wechatID)
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/accessqrlogin",dataMap,heardMap)
	//_, err := cli.BanFriend(wxid, true)
	if err != nil {
		log.Println("account/accessqrlogin error: ",err)
	}
}

//处理上传通讯录回调
func dealWithUploadMcontact(robotWechatID,raw string) {
	if strings.Index(raw,"<msg") == -1 {
		log.Println("不是上传通讯录回调消息")
		return
	}
	time.Sleep(time.Minute * 2)

	if strings.Index(raw,"mobileidentify=\"") != -1 {

		fromusername := raw[strings.Index(raw,"fromusername=\"")+14 : ]
		fromusername = fromusername[ : strings.Index(fromusername,"\"")]

		mobileidentify := raw[strings.Index(raw,"mobileidentify=\"")+16 : ]
		mobileidentify = mobileidentify[ : strings.Index(mobileidentify,"\"")]

		antispamticket := raw[strings.Index(raw,"antispamticket=\"")+16 : ]
		antispamticket = antispamticket[ : strings.Index(antispamticket,"\"")]

		phoneV1v2,err := models.NewPhoneV1v2()
		if err != nil {
			return
		}

		phoneV1v2.SetData("wechat_id",robotWechatID)
		phoneV1v2.SetData("add_phone_md5",mobileidentify)
		phoneV1v2.Row()
		if phoneV1v2.GetId() != 0 {
			phoneV1v2.SetData("v1",fromusername)
			phoneV1v2.SetData("v2",antispamticket)
			phoneV1v2.SetData("state",3)
			if err := phoneV1v2.Save();err != nil {
				log.Println(" phoneV1v2 save error: ",err)
				return
			}
		}
	}
}

//处理加好友回调
func dealWithPassFriend(fromwechatID,robotWechatID,raw string) {
	if raw != "我通过了你的朋友验证请求，现在我们可以开始聊天了" {
		log.Println("不是好友通过消息")
		return
	}

	wechat,_ := models.NewBindWechat()
	wechat.SetData("wechat_id",robotWechatID)
	wechat.Row()
	userID := wechat.GetString("user_id")

	time.Sleep(time.Second * 10)

	addFriendLog,_ := models.NewAddFriendLog()
	addFriendLogs := addFriendLog.GetCollection()
	addFriendLogs.AddFieldToFilter("wechat_id","eq",robotWechatID)
	addFriendLogs.AddFieldToFilter("add_wechat_id","eq","")
	addFriendLogs.AddFieldToFilter("state","eq",2)
	addFriendLogs.AddOrder("create_date desc")
	addFriendLogs.Load()

	//wxid_vmz551rqzdw522
	//from_id:  wxid_iltchhxm10to22 towechatID:  wxid_vmz551rqzdw522 raw:  我通过了你的朋友验证请求，现在我们可以开始聊天了
	items := addFriendLogs.GetItems()
	for i := range items{
		item := items[i]
		addPhone := item.GetString("add_phone")

		//从本地取,取不到再搜索
		strangerWechatInfo,_ := models.NewStrangerWechatInfo()
		strangerWechatInfo.SetData("wechat_id",fromwechatID)
		strangerWechatInfo.Row()
		//swiItem := strangerWechatInfo.GetByWechatID(fromwechatID)
		friendWxID := strangerWechatInfo.GetString("wechat_id")
		friendPhone := strangerWechatInfo.GetString("phone")

		log.Println("获取本地陌生人微信ID: ",friendWxID,",手机号: ",friendPhone)

		if friendPhone != "" {
			if friendPhone == addPhone {
				item.SetData("add_wechat_id",friendWxID)
				item.SetData("state",1)
				item.SetData("is_oneway_fans",0)
				item.SetData("pass_date",time.Now().Format("2006-01-02 15:04:05"))
				err := item.Save()
				if err != nil {
					log.Println("addFriendLog save error: ",err)
				}
				break
			}
		}else {
			friendWxID = task.GetFriendWxID(userID,robotWechatID,addPhone)
			if friendWxID == fromwechatID {
				item.SetData("add_wechat_id",friendWxID)
				item.SetData("state",1)
				item.SetData("is_oneway_fans",0)
				item.SetData("pass_date",time.Now().Format("2006-01-02 15:04:05"))
				err := item.Save()
				if err != nil {
					log.Println("addFriendLog save error: ",err)
				}
				break
			}
		}
	}

	fmt.Println("自动发送消息任务:",time.Now().Format("2006-01-02 15:04:05"))
	go func() {
		time.Sleep(time.Second * 5)
		arrs := task.GetRandMsgs(userID)
		for i := range arrs{
			arr := arrs[i]
			if arr[0] == "0" {
				go task.SendMessage(robotWechatID, fromwechatID, userID, arr[1])
			}else {
				imgs := strings.Split(arr[1],",")
				for i := range imgs{
					go task.SendImgMessage(robotWechatID, fromwechatID, userID, imgs[i])
				}
			}
		}
	}()
}

