/*
@Time : 2019/5/13 15:44 
@Author : Lukebryan
@File : base.go
@Software: GoLand
*/
package api

import (
	"encoding/json"
	"fmt"
	"github.com/go-chi/jwtauth"
	"github.com/kataras/iris/core/errors"
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/utils"
	"wechatmanagent/web/middleware"
)

var tokenAuth *jwtauth.JWTAuth
var JWTAuthCxtKey = jwtauth.TokenCtxKey

const (
	ClaimSid  = "user_id"
	ClaimWxid = "wxid"

	MultipartFormMaxMemory = 1024 * 1024 * 100
	AccountFileSep         = "----"

	StaticDir = "static"
	ImgDir    = StaticDir + "/img"
	VideoDir  = StaticDir + "/video"
	ExcelDir  = StaticDir + "/excle"
)

type Base struct{}

//是否已登录
func (Base) isLogined(r *http.Request,wxid string) bool {

	userId := middleware.GetUserID(r.Header.Get("Authorization"))
	log.Println("login wxid: ",wxid,"   login userId: ",userId)
	if cast.ToString(wxid) == "" {
		return false
	}

	dataMap := make(map[string]interface{})
	dataMap["wxid_list"] = wxid	//"wxid1,wxid2,wxid3"
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(cast.ToString(userId),cast.ToString(wxid))
	resultBody, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/batchcheckloginstatus",dataMap,heardMap)
	if err != nil {
		log.Println(err)
		return false
	}
	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(resultBody),&maps)
	if err != nil {
		log.Println(err)
		return false
	}
	resultDataMap := make(map[string]interface{})
	b2,err := json.Marshal(maps["Data"])
	if err != nil {
		log.Println(err)
		return false
	}
	err = json.Unmarshal(b2,&resultDataMap)
	if err != nil {
		log.Println(err)
		return false
	}
	if cast.ToInt(resultDataMap[wxid]) == 0 {
		return false
	}

	return true
}

func (Base) getCurrentUserId(r *http.Request) string {
	userId := middleware.GetUserID(r.Header.Get("Authorization"))
	return cast.ToString(userId)
}

func (Base) getCurrentWxId(r *http.Request) string {
	wxId := r.Header.Get("Wechat-Id")
	return cast.ToString(wxId)
}

func (Base) saveFile(r *http.Request, key, toPath string) (paths []string, errs []error) {
	err := r.ParseMultipartForm(MultipartFormMaxMemory)
	if err != nil {
		return
	}

	imgs := r.MultipartForm.File[key]
	for _, img := range imgs {
		imgName := img.Filename
		fmt.Println("imgName:	",imgName)
		f, err := img.Open()
		defer f.Close()
		if err != nil {
			log.Println("img.Open error: ",err)
			errs = append(errs, err)
			paths = append(paths, "")
			continue
		}
		data, err := ioutil.ReadAll(f)
		if err != nil {
			log.Println("ioutil.ReadAll error: ",err)
			errs = append(errs, err)
			paths = append(paths, "")
			continue
		}

		imgMd5 := utils.Md5ByByte(data)
		ext := path.Ext(imgName)
		newName := path.Join(toPath, fmt.Sprintf("%s%s", imgMd5, ext))

		exist, _ := PathExists(config.Sysconfig.FileSavePath + "/" + toPath)
		if !exist {
			err := os.MkdirAll(config.Sysconfig.FileSavePath + "/" + toPath, os.ModePerm)
			if err != nil {
				log.Printf("mkdir failed![%v]\n", err)
				errs = append(errs, err)
				paths = append(paths, "")
				continue
			}
		}

		err = ioutil.WriteFile(config.Sysconfig.FileSavePath + "/" + newName, data, 0755)
		if err != nil {
			log.Println("ioutil.WriteFile error: ",err)
			errs = append(errs, err)
			paths = append(paths, "")
			continue
		}
		errs = append(errs, nil)
		paths = append(paths, newName)
	}
	return
}

func (Base) uploadFile(r *http.Request, key string,savePath string) (result [][3]string, errs []error) {

	err := r.ParseMultipartForm(MultipartFormMaxMemory)
	if err != nil {
		return
	}

	files := r.MultipartForm.File[key]
	for _, f := range files {

		var res [3]string

		fName := f.Filename
		res[0] = fName
		fSize := cast.ToFloat64(f.Size)/cast.ToFloat64(1024)
		uintStr := "KB"
		if fSize > 1024 {
			fSize = fSize/cast.ToFloat64(1024)
			uintStr = "MB"
		}
		fSizeStr := cast.ToString(fSize)
		res[1] = fSizeStr[0:strings.Index(fSizeStr,".")+3] + uintStr
		f, err := f.Open()
		defer f.Close()
		if err != nil {
			errs = append(errs, err)
			res[2] = ""
			result = append(result, res)
			continue
		}

		//获取当前时间戳作为文件名
		unixTime := utils.UniqueId()
		fileName := cast.ToString(unixTime)
		//截取后缀
		suffix := fName[strings.LastIndex(fName, "."):]
		//创建文件夹:当前时间年月日
		nowTime := time.Now()
		timeStr := nowTime.Format("2006") + "/" + nowTime.Format("0102")
		path := savePath + timeStr
		exist, _ := PathExists(path)
		if !exist {
			err := os.MkdirAll(path, os.ModePerm)
			if err != nil {
				log.Printf("mkdir failed![%v]\n", err)
				errs = append(errs, err)
				res[2] = ""
				result = append(result, res)
				continue
			}
		}

		//创建文件
		fW, err := os.Create(path + "/" + fileName + suffix)
		if err != nil {
			log.Println("文件创建失败")
			errs = append(errs, err)
			res[2] = ""
			result = append(result, res)
			continue
		}
		defer fW.Close()
		_, err = io.Copy(fW, f)
		if err != nil {
			log.Println("文件保存失败")
			errs = append(errs, errors.New("文件保存失败:"+err.Error()))
			res[2] = ""
			result = append(result, res)
			continue
		}

		if strings.Contains(savePath,"static/qrcode/") {
			res[2] = "static/qrcode/" + timeStr + "/" + fileName + suffix
		}else if strings.Contains(savePath,"static/excel/") {
			res[2] = "static/excel/" + timeStr + "/" + fileName + suffix
		}else if strings.Contains(savePath,"static/sns/") {
			res[2] = "static/sns/" + timeStr + "/" + fileName + suffix
		}else {
			res[2] = "static/img/" + timeStr + "/" + fileName + suffix
		}

		result = append(result, res)
	}

	return
}

func (Base) list(w http.ResponseWriter, c *db.Collection) {
	result := make(map[string]interface{})
	result["total"] = c.GetSize()
	result["list"] = c.GetMaps()
	rel, _ := utils.JsonEncode(0, result, "")
	w.Write(rel)
}

// 判断文件夹是否存在
func PathExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}