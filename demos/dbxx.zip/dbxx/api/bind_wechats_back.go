/*
@Time : 2019/7/22 21:48 
@Author : Lukebryan
@File : bind_wechats_back.go
@Software: GoLand
*/
package api

import (
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"log"
	"net/http"
	"strconv"
	"strings"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

//微信机器人
type BindWechatBack struct {
	Base
}

func (b BindWechatBack) Del(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("ids")
	userID := b.getCurrentUserId(r)
	secondPassword := r.PostFormValue("second_password")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	if secondPassword == "" {
		rel, _ := utils.JsonEncode(-1, nil, "二级密码不能为空")
		w.Write(rel)
		return
	}

	user,_ := models.NewUser()
	user.Load(cast.ToInt64(userID))
	if user.GetId() == 0 {
		rel, _ := utils.JsonEncode(-1, nil, "登录失效,请重新登录")
		w.Write(rel)
		return
	}

	secondPwd := getMd5Pwd(user.GetString("user_name"),secondPassword)
	if user.GetString("second_password") != secondPwd {
		rel, _ := utils.JsonEncode(-1, nil, "密码错误")
		w.Write(rel)
		return
	}

	m, err := models.NewBindWechatsBack()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("BindWechatsBack Delete Error: ",err)
			return
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}

func (b BindWechatBack) List(w http.ResponseWriter, r *http.Request) {
	pageStr := r.PostFormValue("page")
	sizeStr := r.PostFormValue("size")
	//groupIdStr := r.PostFormValue("group_id")
	state := r.PostFormValue("state")
	order := r.PostFormValue("order")
	wechatAlias := r.PostFormValue("wechat_alias")
	wechatMobile := r.PostFormValue("wechat_mobile")
	//groupId, err := strconv.ParseInt(groupIdStr, 10, 64)
	//if err != nil {
	//	groupId = 0
	//}

	page, err := strconv.ParseInt(pageStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	size, err := strconv.ParseInt(sizeStr, 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	m, err := models.NewBindWechatsBack()
	if err != nil {
		rel, _ := utils.JsonEncode(-1, nil, err.Error())
		w.Write(rel)
		return
	}

	c := m.GetCollection()
	c.AddFieldToSelect("*", "m")
	c.AddFieldToSelect("{(select count(ym_wechat_friends.id) from ym_wechat_friends where belong_wxid=m.wechat_id and contact_type=0)} as friends", "")
	//if groupId > 0 {
	//	c.AddFieldToFilter("group_id", "eq", groupId)
	//}

	var allWechatID []string
	d := m.GetCollection()
	d.AddFieldToFilter("user_id","eq",b.getCurrentUserId(r))
	d.Load()
	d.Each(func(item *db.Item) {
		allWechatID = append(allWechatID, item.GetString("wechat_id"))
	})

	if state != "" {
		if state == "0" {	//离线
			c.AddFieldToFilter("status", "eq", 1)
		}else if state == "-10001" {	//密码错误
			c.AddFieldToFilter("status", "eq", -10001)
		}else if state == "12008" {		//账号异常
			c.AddFieldToFilter("status", "eq", 2)
		}
	}

	if order != "" {
		c.AddOrder(order)
	}

	if wechatAlias != "" {
		c.AddFieldToFilter("wechat_alias", "like", "%"+wechatAlias+"%")
	}

	if wechatMobile != "" {
		c.AddFieldToFilter("wechat_mobile", "like", "%"+wechatMobile+"%")
	}

	c.AddFieldToFilter("user_id", "eq", b.getCurrentUserId(r))
	c.SetPageSize(size)
	c.SetCurPage(page)
	c.AddOrder("last_login_date desc")
	c.Load()
	c.Each(func(item *db.Item) {
		addFriendLog,_ := models.NewAddFriendLog()
		addFriendLogs := addFriendLog.GetCollection()
		addFriendLogs.AddFieldToFilter("wechat_id","eq",item.GetString("wechat_id"))
		addFriendLogs.AddFieldToFilter("state","eq",1)
		fansCount := addFriendLogs.GetSize()
		item.SetData("fans_count",fansCount)
	})
	b.list(w, c)
}

//恢复
func (BindWechatBack) Back(w http.ResponseWriter, r *http.Request) {
	idStr := r.PostFormValue("ids")
	ids := strings.Split(idStr,",")
	if len(ids) < 1 {
		rel, _ := utils.JsonEncode(-1, nil, "id不能为空")
		w.Write(rel)
		return
	}

	m, err := models.NewBindWechatsBack()
	c := m.GetCollection()
	c.AddFieldToFilter("id","in",strings.Join(ids,"','"))
	c.Load()

	var fails []map[string]interface{}
	c.Each(func(item *db.Item) {
		err = item.Delete()
		if err != nil {
			fails = append(fails, item.GetMap())
			log.Println("BindWechatsBack Delete Error: ",err)
			return
		}

		bindWechat,_ := models.NewBindWechat()
		//bindWechat.SetId(cast.ToInt64(item.GetId()))
		bindWechat.SetData("user_id",item.GetString("user_id"))
		bindWechat.SetData("wechat_id",item.GetString("wechat_id"))
		bindWechat.SetData("wechat_password",item.GetString("wechat_password"))
		bindWechat.SetData("socks_ip",item.GetString("socks_ip"))
		bindWechat.SetData("wechat_alias",item.GetString("wechat_alias"))
		bindWechat.SetData("wechat_mobile",item.GetString("wechat_mobile"))
		bindWechat.SetData("nickname",item.GetString("nickname"))
		bindWechat.SetData("sex",item.GetInt("sex"))
		bindWechat.SetData("signature",item.GetString("signature"))
		bindWechat.SetData("country",item.GetString("country"))
		bindWechat.SetData("province",item.GetString("province"))
		bindWechat.SetData("city",item.GetString("city"))
		bindWechat.SetData("small_headimg_url",item.GetString("small_headimg_url"))
		bindWechat.SetData("group_id",item.GetInt("group_id"))
		bindWechat.SetData("verify_friend_switch",item.GetString("verify_friend_switch"))
		bindWechat.SetData("last_login_date",item.GetString("last_login_date"))
		bindWechat.SetData("wechat_token",item.GetString("wechat_token"))
		bindWechat.SetData("login_device_data",item.GetString("login_device_data"))
		bindWechat.SetData("status",item.GetInt("status"))
		bindWechat.SetData("android_device_data",item.GetString("android_device_data"))
		bindWechat.SetData("wechat_file_id",item.GetInt("wechat_file_id"))
		bindWechat.SetData("create_date",item.GetString("create_date"))
		if err := bindWechat.Save();err != nil {
			log.Println("bindWechat save error: ",err)
		}
	})

	rel, _ := utils.JsonEncode(0, fails, "删除成功")
	w.Write(rel)
}