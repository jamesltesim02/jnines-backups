package api

import (
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"wechatmanagent/config"
	"wechatmanagent/utils"

	"github.com/go-chi/jwtauth"
)

type Article struct {
	Base
}

// GetStaticURL 临时 URL 赚永久 URL
func (a Article) GetStaticURL(w http.ResponseWriter, r *http.Request) {
	_ = r.ParseForm()
	fmt.Println(r.Context().Value(jwtauth.TokenCtxKey))

	tmpURL := r.FormValue("url")
	if err := checkURL(tmpURL); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	dataMap := make(map[string]interface{})
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(a.getCurrentUserId(r),a.getCurrentWxId(r))
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/get_static_url",dataMap,heardMap)
	if err != nil {
		http.Error(w, "临时 URL 转换失败", http.StatusInternalServerError)
		return
	}
	//TODO	client.ClentPool.Get()
	//cli := client.ClentPool.Get()
	//if cli == nil {
	//	http.Error(w, "当前服务器很忙很忙很忙，没有空余的资源服务。", http.StatusInternalServerError)
	//	return
	//}

	//tmpURL, err := busines.GetArticleStaticURL(cli.LongLink, tmpURL)


	_, _ = w.Write([]byte(tmpURL))
}

//// GetBizHistoryList 获取公众号历史消息
//func (Article) GetBizHistoryList(w http.ResponseWriter, r *http.Request) {
//	_ = r.ParseForm()
//
//	tmpURL := r.FormValue("url")
//	if err := checkURL(tmpURL); err != nil {
//		http.Error(w, err.Error(), http.StatusBadRequest)
//		return
//	}
//
//	uri, err := url.Parse(tmpURL)
//	if err != nil {
//		http.Error(w, "永久 URL 不合法", http.StatusBadRequest)
//		return
//	}
//
//	biz := uri.Query().Get("__biz")
//	if len(strings.TrimSpace(biz)) == 0 {
//		http.Error(w, "永久 URL 不合法, 没有携带 __biz 参数", http.StatusBadRequest)
//		return
//	}
//
//	cli := client.Wechats.Pop()
//	if cli == nil {
//		http.Error(w, "当前服务器很忙很忙很忙，没有空余的资源服务。", http.StatusInternalServerError)
//		return
//	}
//	defer client.Wechats.Push(cli)
//
//	offset := uri.Query().Get("offset")
//	if len(strings.TrimSpace(offset)) == 0 {
//		offset = "10"
//	}
//
//	tmpURL = fmt.Sprintf("http://mp.weixin.qq.com/mp/profile_ext?action=getmsg&__biz=%s&offset=%s", biz, offset)
//	content, err := busines.GetBizHistoryList(cli.LongLink, tmpURL)
//	if err != nil {
//		http.Error(w, "没有获取到公众号历史消息列表", http.StatusInternalServerError)
//		return
//	}
//
//	_, _ = w.Write(content)
//}
//
//// GetArticleContent 获取永久 URL 的文章内容
//func (Article) GetArticleContent(w http.ResponseWriter, r *http.Request) {
//	_ = r.ParseForm()
//
//	tmpURL := r.FormValue("url")
//	if err := checkURL(tmpURL); err != nil {
//		http.Error(w, err.Error(), http.StatusBadRequest)
//		return
//	}
//
//	cli := client.Wechats.Pop()
//	if cli == nil {
//		http.Error(w, "当前服务器很忙很忙很忙，没有空余的资源服务。", http.StatusInternalServerError)
//		return
//	}
//	defer client.Wechats.Push(cli)
//
//	content, _, _, err := busines.GetArticleContent(cli.LongLink, tmpURL)
//	if err != nil {
//		http.Error(w, "获取永久 URL 内容失败", http.StatusInternalServerError)
//		return
//	}
//
//	_, _ = w.Write([]byte(content))
//}
//
//// GetArticleExtInfo 获取文章扩展信息，点赞数，阅读数等
//func (Article) GetArticleExtInfo(w http.ResponseWriter, r *http.Request) {
//	_ = r.ParseForm()
//
//	tmpURL := r.FormValue("url")
//	if err := checkURL(tmpURL); err != nil {
//		http.Error(w, err.Error(), http.StatusBadRequest)
//		return
//	}
//
//	cli := client.Wechats.Pop()
//	if cli == nil {
//		http.Error(w, "当前服务器很忙很忙很忙，没有空余的资源服务。", http.StatusInternalServerError)
//		return
//	}
//	defer client.Wechats.Push(cli)
//
//	content, uin, key, err := busines.GetArticleContent(cli.LongLink, tmpURL)
//	if err != nil {
//		http.Error(w, "获取文章信息失败", http.StatusInternalServerError)
//		return
//	}
//
//	commentId := jsoniter.Get([]byte(content), "comment_id").ToString()
//	ext, err := busines.GetArticleExtInfo(uin, key, commentId, tmpURL)
//	if err != nil {
//		http.Error(w, "获取文章评论扩展信息失败", http.StatusInternalServerError)
//		return
//	}
//
//	merge := r.FormValue("merge")
//	if merge == "1" {
//		var extMap map[string]interface{}
//		if err := jsoniter.Unmarshal([]byte(ext), &extMap); err != nil {
//			http.Error(w, "获取文章评论扩展信息失败", http.StatusInternalServerError)
//			return
//		}
//
//		var contentMap map[string]interface{}
//		if err := jsoniter.Unmarshal([]byte(content), &contentMap); err != nil {
//			http.Error(w, "获取文章评论扩展信息失败", http.StatusInternalServerError)
//			return
//		}
//
//		contentMap["read_num"] = extMap["read_num"]
//		contentMap["like_num"] = extMap["like_num"]
//		contentMap["comment_num"] = extMap["comment_num"]
//
//		ext, err = jsoniter.MarshalToString(&contentMap)
//		if err != nil {
//			http.Error(w, "获取文章评论扩展信息失败", http.StatusInternalServerError)
//			return
//		}
//	}
//
//	_, _ = w.Write([]byte(ext))
//}
//
//// GetArticleReadLikeNum 只获取阅读数，点赞数
//func (Article) GetArticleReadLikeNum(w http.ResponseWriter, r *http.Request) {
//	_ = r.ParseForm()
//
//	tmpURL := r.FormValue("url")
//	if err := checkURL(tmpURL); err != nil {
//		http.Error(w, err.Error(), http.StatusBadRequest)
//		return
//	}
//
//	cli := client.Wechats.Pop()
//	if cli == nil {
//		http.Error(w, "当前服务器很忙很忙很忙，没有空余的资源服务。", http.StatusInternalServerError)
//		return
//	}
//	defer client.Wechats.Push(cli)
//
//	content, err := busines.GetArticleReadLikeNum(cli.LongLink, tmpURL)
//	if err != nil {
//		if err.Error() == "读赞数对象不存在" {
//			http.Error(w, "没有读赞数", http.StatusInternalServerError)
//			return
//		}
//
//		http.Error(w, "获取文章阅读数点赞数失败", http.StatusInternalServerError)
//		return
//	}
//
//	_, _ = w.Write([]byte(content))
//}

func checkURL(uri string) error {
	if len(strings.TrimSpace(uri)) == 0 {
		return errors.New("永久 URL 不允许为空")
	}

	if _, err := url.Parse(uri); err != nil {
		return errors.New("永久 URL 不合法")
	}

	if !strings.Contains(uri, "://mp.weixin.qq.com/") {
		return errors.New("永久 URL 不合法")
	}

	return nil
}
