/*
@Time : 2019/6/10 11:44 
@Author : Lukebryan
@File : wechat_file.go
@Software: GoLand
*/
package api

import (
	"github.com/liuzhiyi/go-db"
	"github.com/spf13/cast"
	"net/http"
	"strings"
	"wechatmanagent/models"
)


type WechatFile struct {
	Base
}

var StatusMap = map[int]string{
	0 : "未登录",
	120000 : "等待扫码中",
	120001 : "扫码超时",
	120002 : "等待pushlogin confirm",
	120003 : "等待pushlogin confirm超时",
	120005 : "重新登录换ip",
	12007 : "在线",
	12008 : "需要安全验证",
	12009 : "断线重连",
	12010 : "已退出",
	-10001 : "密码错误",
	-10000 : "未知错误",
	-10002 : "账号被封",
}

//列表
func (s WechatFile) List(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")

	m, err := models.NewWechatFile()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	c.AddFieldToFilter("user_id","eq",s.getCurrentUserId(r))
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.AddOrder("id desc")
	c.Load()
	s.list(w, c)
}

//结果
func (s WechatFile) LoginLogs(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	wechatFileID := r.PostFormValue("wechat_file_id")

	m, err := models.NewLoginLog()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	c := m.GetCollection()
	c.AddFieldToFilter("wechat_file_id","eq",wechatFileID)
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}
	c.AddOrder("id desc")
	c.Load()

	var phones []string
	c.Each(func(item *db.Item) {
		phones = append(phones, item.GetString("wechat_id"))
	})

	wechat,_ := models.NewBindWechat()
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("wechat_mobile","in",strings.Join(phones,"','"))
	wechats.Load()

	wechatMap := make(map[string]*db.Item)
	var loginWechats []string
	wechats.Each(func(item *db.Item) {
		wechatMap[item.GetString("wechat_mobile")] = item
		loginWechats = append(loginWechats, item.GetString("wechat_id"))
	})

	loginMap := getLoginMap(loginWechats,s.getCurrentUserId(r),s.getCurrentWxId(r))

	c.Each(func(item *db.Item) {
		state := item.GetString("state")
		mobile := item.GetString("wechat_id")
		if state != "" {
			if _,ok := wechatMap[mobile]; ok {
				wechatItem := wechatMap[mobile]
				wechatID := wechatItem.GetString("wechat_id")
				state = cast.ToString(loginMap[wechatID])
			}
			//state = cast.ToString(loginMap[wechatMap[mobile].GetString("wechat_id")])
			item.SetData("state",state)
		}
	})
	s.list(w, c)
}

//预览
func (s WechatFile) FileItems(w http.ResponseWriter, r *http.Request) {
	page := r.PostFormValue("page")
	size := r.PostFormValue("size")
	wechatFileID := r.PostFormValue("wechat_file_id")

	m, err := models.NewBindWechat()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	c := m.GetCollection()
	c.AddFieldToFilter("wechat_file_id","eq",wechatFileID)
	if size != "" {
		c.SetPageSize(cast.ToInt64(size))
		c.SetCurPage(cast.ToInt64(page))
	}

	c.AddOrder("id desc")
	c.Load()
	s.list(w, c)
}