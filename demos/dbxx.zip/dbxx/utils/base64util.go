/*
@Time : 2019/5/24 9:46 
@Author : Lukebryan
@File : base64util.go
@Software: GoLand
*/
package utils

import "encoding/base64"

//解密
func Base64DecodeString(s string) string {
	by,err := base64.StdEncoding.DecodeString(s)
	if err != nil {
		return ""
	}
	return string(by)
}

//加密
func Base64EncodeToString(bytes []byte) string {
	return base64.StdEncoding.EncodeToString(bytes)
}