/*
@Time : 2019/5/14 10:40 
@Author : Lukebryan
@File : tokenutil.go
@Software: GoLand
*/
package utils

import (
	"github.com/dgrijalva/jwt-go"
	"time"
)

var ApiToken = make(map[string]string)

func GentToken(userID string,wechat_id string) string {
	//fmt.Println("生成apitoken时的用户ID: ",userID,",微信ID",wechat_id)
	t := jwt.NewWithClaims(jwt.SigningMethodHS256,jwt.MapClaims{
		"timestamp" : time.Now().Unix(),
		"user_id" : ApiToken[userID],
		"wxid" : wechat_id,
	})
	token,_ := t.SignedString([]byte("secret"))
	return "BEARER " + token
}
