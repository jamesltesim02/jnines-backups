/*
@Time : 2019/6/5 16:21
@Author : Lukebryan
@File : timeutil.go
@Software: GoLand
*/
package utils

import "testing"

func TestCompareTime(t *testing.T) {
	type args struct {
		queryTime  string
		targetTime string
	}
	tests := []struct {
		name    string
		args    args
		want    int
		wantErr bool
	}{
		// TODO: Add test cases.
		{
			"test1",
			args{
				"23:10",
				"23:00"},
			2,
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := CompareTime(tt.args.queryTime, tt.args.targetTime)
			if (err != nil) != tt.wantErr {
				t.Errorf("CompareTime() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if got != tt.want {
				t.Errorf("CompareTime() = %v, want %v", got, tt.want)
			}
		})
	}
}
