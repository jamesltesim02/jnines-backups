/*
@Time : 2019/5/27 15:01 
@Author : Lukebryan
@File : percentage_util.go		百分比
@Software: GoLand
*/
package utils

import (
	"github.com/spf13/cast"
	"strings"
)

/*
i除数
j被除数
d保留位数
simple :
d = 2
i / j = 100.00%
 */
func GetPercentage(i,j float64,d int) string {

	if j == 0 {
		str := ""
		for i := 0;i < d;i ++{
			str += "0"
		}
		return "0."+str+"%"
	}

	rs := cast.ToString(i / j * 100)

	//整数
	integer := rs
	if strings.Index(rs,".") != -1 {
		integer = rs[ : strings.Index(rs,".")]
	}
	//小数
	decimal := ""
	if strings.Index(rs,".") != -1 {
		decimal = rs[strings.Index(rs,".") +1 : ]
	}

	needCount := 0
	if d <= len(decimal) {
		return rs[ : strings.Index(rs,".") +1 + d]+"%"
	}else {
		needCount = d - len(decimal)
	}

	str := ""
	for i := 0;i < needCount;i ++{
		str += "0"
	}

	return integer+"."+decimal+str+"%"
}