/*
@Time : 2019/8/7 9:18 
@Author : Lukebryan
@File : queue.go
@Software: GoLand
*/
package utils

import "sync"

type Item interface {}

// 队列结构体
type Queue struct {
	Items []Item
}

// 新建
func (q *Queue)New() *Queue  {
	q.Items = []Item{}
	return q
}

// 入队
func (q *Queue) Enqueue(data Item)  {
	q.Items = append(q.Items, data)
}

var mutex sync.Mutex
// 出队
func (q *Queue) Dequeue() *Item {
	// 由于是先进先出，0为队首
	if q.IsEmpty() {
		item := make([]Item,1)
		return &item[0]
	}
	item := q.Items[0]
	q.Items = q.Items[1: len(q.Items)]
	return &item
}

// 队列是否为空
func (q *Queue) IsEmpty() bool  {
	return len(q.Items) == 0
}

// 队列长度
func (q *Queue) Size() int  {
	return len(q.Items)
}

func NewQueue() *Queue  {
	q := Queue{}
	queue := q.New()
	return queue
}
