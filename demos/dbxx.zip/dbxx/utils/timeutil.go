/*
@Time : 2019/6/5 16:21 
@Author : Lukebryan
@File : timeutil.go
@Software: GoLand
*/
package utils

import (
	"errors"
	"fmt"
	"github.com/spf13/cast"
	"log"
	"strings"
	"time"
)

/*
24小时内获取两个时间间隔(单位:分钟)
例如:beginTime = 23:00  endTime = "1:00" return 120
 */
func GetMinCount(beginTime,endTime string) int {
	bTime,_ := time.Parse("2006-01-02 15:04:05",time.Now().Format("2006-01-02") + " " + beginTime + ":00")
	eTime,_ := time.Parse("2006-01-02 15:04:05",time.Now().Format("2006-01-02") + " " + endTime + ":00")
	bTimeUnix := cast.ToInt(bTime.Unix())
	eTimeUnix := cast.ToInt(eTime.Unix())
	//之后

	fmt.Println("bTime: ",bTime,",eTime: ",eTime)
	fmt.Println("bTimeUnix: ",bTimeUnix,",eTimeUnix: ",eTimeUnix)

	oneDaySecond := 24 * 60 * 60
	if bTime.After(eTime) {
		differUnix := bTimeUnix - eTimeUnix
		oneDaySecond = oneDaySecond - differUnix
	}else {
		differUnix := eTimeUnix - bTimeUnix
		oneDaySecond = differUnix
	}

	return oneDaySecond / 60
	//fmt.Println("beginTime: ",beginTime,",endTime",endTime)
	//if beginTime == "" || strings.Index(beginTime,":") == -1 {
	//	beginTime = "00:00"
	//}
	//if endTime == "" || strings.Index(endTime,":") == -1 {
	//	endTime = "00:00"
	//}
	//
	////时钟
	//nowHourStr := beginTime[:strings.Index(beginTime, ":")]
	//if strings.HasPrefix(nowHourStr,"0") {
	//	nowHourStr = nowHourStr[ 1: ]
	//}
	//nowHour := cast.ToInt(nowHourStr)
	////分钟
	//nowMinStr := beginTime[ strings.Index(beginTime, ":")+1:]
	//if strings.HasPrefix(nowMinStr,"0") {
	//	nowMinStr = nowMinStr[ 1: ]
	//}
	//nowMin :=  cast.ToInt(nowMinStr)
	//
	////时钟
	//hourStr := endTime[:strings.Index(endTime, ":")]
	//if strings.HasPrefix(hourStr,"0") {
	//	hourStr = hourStr[ 1: ]
	//}
	//hour := cast.ToInt(hourStr)
	////分钟
	//minStr := endTime[ strings.Index(endTime, ":")+1:]
	//if strings.HasPrefix(minStr,"0") {
	//	minStr = minStr[ 1: ]
	//}
	//min := cast.ToInt(minStr)
	//
	//fmt.Println(nowHour,"---",nowMin)
	//fmt.Println(hour,"---",min)
	//
	//subHour := 0
	//subMin := 0
	//if hour >= nowHour {
	//	subHour = hour - nowHour
	//} else {
	//	subHour = 24 - nowHour + hour
	//}
	//if min >= nowMin {
	//	subMin = min - nowMin
	//} else {
	//	subMin = 60 - nowMin + min
	//}
	//
	//minute := subHour*60 + subMin
	//return minute
}

//同一天之内比较两时间:之前,相等,之后
//queryTime:13:10,targetTime:14:10	return 0
//return
// 0:之前 before
// 1:相等 eq
// 2:之后 after
func CompareTime(queryTime,targetTime string) (int,error) {

	if queryTime == "" || targetTime == "" {
		return 1,errors.New("queryTime or targetTime can not be null")
	}

	if strings.Index(queryTime,":") == -1 || strings.Index(targetTime,":") == -1 {
		return 1,errors.New("queryTime or targetTime error")
	}

	if queryTime == targetTime {
		return 1,nil
	}

	nowTime := time.Now().Format("2006-01-02")
	queryTimeStr := nowTime + " " + queryTime + ":00"
	targetTimeStr := nowTime + " " + targetTime + ":00"

	qtime := cast.ToTime(queryTimeStr)
	ttime := cast.ToTime(targetTimeStr)

	log.Println("qtime: ",qtime,"ttime: ",ttime)

	//之后
	if qtime.After(ttime) {
		return 2,nil
	}
	//之前
	if qtime.Before(ttime) {
		return 0,nil
	}

	return 1,nil
}