/*
@Time : 2019/6/11 15:25 
@Author : Lukebryan
@File : fileutil.go
@Software: GoLand
*/
package utils

import (
	"crypto/md5"
	"crypto/sha256"
	"encoding/base64"
	"io"
	"io/ioutil"
	"log"
	"os"
)

func ChangeImgMD5(filePath string) bool {
	log.Println("GetFileMD5 Before",GetFileMD5(filePath))
	b, err := ioutil.ReadFile(filePath)
	if err != nil {
		log.Println("ReadFile Error: ",err)
		return false
	}
	content := string(b)+ GetRandomString(10)
	datasource := base64.StdEncoding.EncodeToString([]byte(content))
	ddd, err := base64.StdEncoding.DecodeString(datasource)
	if err != nil {
		//不用管
		log.Println("base64.StdEncoding.DecodeString Error: ",err)
	}
	err = ioutil.WriteFile(filePath, ddd, 0666)
	if err != nil {
		log.Println("WriteFile Error: ",err)
		return false
	}

	log.Println("GetFileMD5 After",GetFileMD5(filePath))

	return true
}

func GetFileSHA256(filePath string) string {
	file, err := os.Open(filePath)
	if err != nil {
		return ""
	}
	defer file.Close()
	h := sha256.New()
	_, erro := io.Copy(h, file)
	if erro != nil {
		return ""
	}
	return string(h.Sum(nil))
}


func GetFileMD5(filePath string) string {
	file, err := os.Open(filePath)
	if err != nil {
		return ""
	}
	defer file.Close()
	h := md5.New()
	_, erro := io.Copy(h, file)
	if erro != nil {
		return ""
	}
	return string(h.Sum(nil))
}