package route

import (
	"github.com/kataras/iris"
	"github.com/kataras/iris/middleware/pprof"
	"github.com/kataras/iris/mvc"
	"net/http"
	"wechatmanagent/web/controllers"
	"wechatmanagent/web/middleware"
)

func InitRouter(app *iris.Application) {
	//app.Use(middleware.CheckSession)
	app.Use(middleware.GetJWT().Serve)
	//app.Use(CrossAccess)
	bathPath := "/api/v1"
	mvc.New(app.Party(bathPath+"/user")).Handle(controllers.NewUserController())
	mvc.New(app.Party(bathPath+"/bindwechatgroup")).Handle(controllers.NewBindWechatGroupController())
	mvc.New(app.Party(bathPath+"/bindwechat")).Handle(controllers.NewBindWechatController())
	mvc.New(app.Party(bathPath+"/materialcategory")).Handle(controllers.NewMaterialCategoryController())
	mvc.New(app.Party(bathPath+"/material")).Handle(controllers.NewMaterialController())
	mvc.New(app.Party(bathPath+"/taskcategory")).Handle(controllers.NewTaskCategoryController())
	mvc.New(app.Party(bathPath+"/task")).Handle(controllers.NewTaskController())
	mvc.New(app.Party(bathPath+"/socks")).Handle(controllers.NewSocksController())
	mvc.New(app.Party(bathPath+"/")).Handle(controllers.NewBaseController())
	mvc.New(app.Party(bathPath+"/chatroom")).Handle(controllers.NewChatroomController())
	mvc.New(app.Party(bathPath+"/account")).Handle(controllers.NewAccountController())
	mvc.New(app.Party(bathPath+"/message")).Handle(controllers.NewMessageController())
	mvc.New(app.Party(bathPath+"/wallet")).Handle(controllers.NewWalletController())
	mvc.New(app.Party(bathPath+"/verifymessage")).Handle(controllers.NewVerifyMessageGroupController())
	mvc.New(app.Party(bathPath+"/importfile")).Handle(controllers.NewImportFileController())
	mvc.New(app.Party(bathPath+"/addfriendplan")).Handle(controllers.NewAddFriendPlanController())
	mvc.New(app.Party(bathPath+"/customer")).Handle(controllers.NewCustomerController())
	mvc.New(app.Party(bathPath+"/uploadfile")).Handle(controllers.NewUploadFileController())
	mvc.New(app.Party(bathPath+"/pullchatroom")).Handle(controllers.NewPullChatroomController())
	mvc.New(app.Party(bathPath+"/sns")).Handle(controllers.NewSnsController())
	mvc.New(app.Party(bathPath+"/talk")).Handle(controllers.NewTalkController())
	mvc.New(app.Party(bathPath+"/wechatfile")).Handle(controllers.NewWechatFileController())
	mvc.New(app.Party(bathPath+"/msg")).Handle(controllers.NewMsgController())


	app.Any("/debug/pprof", pprof.New())
	app.Any("/debug/pprof/{action:path}", pprof.New())
}

func CrossAccess11(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Add("Access-Control-Allow-Origin", "*")
		next.ServeHTTP(w, r)
	})
}
func CrossAccess(ctx iris.Context) {
	ctx.ResponseWriter().Header().Add("Access-Control-Allow-Origin", "*")
}
