package config

import (
	"encoding/json"
	"io/ioutil"
)

var Sysconfig = &sysconfig{}

func init() {
	b, err := ioutil.ReadFile("config.json")
	if err != nil {
		panic("Sys config read err")
	}
	err = json.Unmarshal(b, Sysconfig)
	if err != nil {
		panic(err)
	}

}

type sysconfig struct {
	Port       string    `json:"Port"`
	DBUserName   string `json:"DBUserName"`
	DBPassword string    `json:"DBPassword"`
	DBIp   string    `json:"DBIp"`
	DBPort    string    `json:"DBPort"`
	DBName string    `json:"DBName"`
	QrcodeServerAddr string    `json:"QrcodeServerAddr"`
	WechatServerAddr string    `json:"WechatServerAddr"`
	LocalhostAddr string    `json:"LocalhostAddr"`
	FileSavePath string    `json:"FileSavePath"`
}

