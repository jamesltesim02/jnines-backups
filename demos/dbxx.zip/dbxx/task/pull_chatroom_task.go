/*
@Time : 2019/5/20 20:11 
@Author : Lukebryan
@File : pull_chatroom_task.go	拉人进群任务
@Software: GoLand
*/
package task

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/kataras/iris/core/errors"
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"github.com/spf13/cast"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

func init() {
	//初始化使用状态
	//wechatUseState,err := models.NewWechatUseState()
	//if err != nil {
	//	log.Println("wechatUseState init error: ",err)
	//}
	//
	//wechatUseStates := wechatUseState.GetCollection()
	//_,err = wechatUseStates.GetAdapter().Exec("update ym_wechat_use_state set state = 0")
	//if err != nil {
	//	log.Println("wechatUseState update 0 error: ",err)
	//}


	//重启今日未完成的任务
	plan, err := models.NewPullChatroomPlan()
	if err != nil {
		return
	}
	plans := plan.GetCollection()
	plans.AddFieldToFilter("state","lt",2)
	plans.AddFieldToFilter("start_time","like",time.Now().Format("2006-01-02")+"%")
	plans.Load()
	plansItems := plans.GetItems()

	//不同客户协程进行,同客户顺序进行
	customerChartroomMap := make(map[[6]string][]*db.Item)
	for p := range plansItems {
		id := plansItems[p].GetId()
		runCount := plansItems[p].GetString("run_count")
		fansType := plansItems[p].GetString("fans_type")
		customerID := plansItems[p].GetString("customer_id")
		startTime := plansItems[p].GetString("start_time")
		useCount := cast.ToString(plansItems[p].GetInt("handle_fans_id") - 1)

		customer,err := models.NewCustomer()
		if err != nil {
			log.Println(err)
			continue
		}
		customer.Load(cast.ToInt64(customerID))

		if startTime == "" {
			startTime = time.Now().Add(time.Minute * 3).Format("2006-01-02 15:04:05")
		}

		m, err := models.NewPullChatroom()
		if err != nil {
			continue
		}
		d := m.GetCollection()
		d.AddFieldToFilter("pull_chatroom_plan_id", "eq", id)
		d.AddFieldToFilter("state", "lt", 4)
		d.Load()
		items := d.GetItems()

		for i := range items {
			k := [6]string{startTime,customerID,runCount,fansType,useCount,cast.ToString(id)}
			if _, ok := customerChartroomMap[k]; !ok {
				customerChartroomMap[k] = []*db.Item{items[i]}
			} else {
				customerChartroomMap[k] = append(customerChartroomMap[k], items[i])
			}

		}
	}

	for k, pullChatrooms := range customerChartroomMap {
		startTime,customerID,runCount,fansType,useCount,id := k[0],k[1],k[2],k[3],k[4],k[5]
		time.Sleep(time.Second * 1)
		//不同客户协程并发进行,同客户顺序进行
		go DealWithChatroomData(startTime,cast.ToInt(runCount),cast.ToInt(fansType),cast.ToInt(useCount),cast.ToInt(customerID),cast.ToInt(id),pullChatrooms)
	}
}

//拉人进群
func (t Task) PullChatRoomTask() {

	spec := "0 1 0 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {

		plan, err := models.NewPullChatroomPlan()
		if err != nil {
			return
		}
		plans := plan.GetCollection()
		plans.AddFieldToFilter("state","lt",2)
		//plans.JoinLeft("ym_customer as dl", "m.customer_id=dl.id", "dl.start_time")
		plans.AddFieldToFilter("start_time","like",time.Now().Format("2006-01-02")+"%")
		plans.Load()
		plansItems := plans.GetItems()

		fmt.Println(plans)

		//不同客户协程进行,同客户顺序进行
		customerChartroomMap := make(map[[6]string][]*db.Item)
		for p := range plansItems {



			id := plansItems[p].GetId()
			runCount := plansItems[p].GetString("run_count")
			fansType := plansItems[p].GetString("fans_type")
			customerID := plansItems[p].GetString("customer_id")
			startTime := plansItems[p].GetString("start_time")
			useCount := cast.ToString(plansItems[p].GetInt("handle_fans_id") - 1)

			customer,err := models.NewCustomer()
			if err != nil {
				log.Println(err)
				continue
			}
			customer.Load(cast.ToInt64(customerID))

			if startTime == "" {
				startTime = "0:30"
			}

			m, err := models.NewPullChatroom()
			if err != nil {
				continue
			}
			d := m.GetCollection()
			d.AddFieldToFilter("pull_chatroom_plan_id", "eq", id)
			d.AddFieldToFilter("state", "lt", 4)
			d.Load()
			items := d.GetItems()

			for i := range items {
				k := [6]string{startTime,customerID,runCount,fansType,useCount,cast.ToString(id)}
				if _, ok := customerChartroomMap[k]; !ok {
					customerChartroomMap[k] = []*db.Item{items[i]}
				} else {
					customerChartroomMap[k] = append(customerChartroomMap[k], items[i])
				}

			}
		}


		for k, pullChatrooms := range customerChartroomMap {
			startTime,customerID,runCount,fansType,useCount,id := k[0],k[1],k[2],k[3],k[4],k[5]

			//不同客户协程并发进行,同客户顺序进行
			go DealWithChatroomData(startTime,cast.ToInt(runCount),cast.ToInt(fansType),cast.ToInt(useCount),cast.ToInt(customerID),cast.ToInt(id),pullChatrooms)
		}

	})
	c.Start()
	select {}
}

func DealWithChatroomData(startTime string,runCount,fansType,useCount ,customerID,id int,pullChatrooms []*db.Item) {

	if len(pullChatrooms) == 0 {
		log.Println("没有群可拉")
		return
	}

	go updatePlanStatus(id,1)

	if strings.Index(startTime,time.Now().Format("2006-01-02")) == -1 {
		log.Println("不是今天的任务")
		return
	}

	userID := pullChatrooms[0].GetString("user_id")

	sTime, err := time.Parse("2006-01-02 15:04:05", startTime)
	nowTime, _ := time.Parse("2006-01-02 15:04:05", time.Now().Format("2006-01-02 15:04:05"))
	if err != nil {
		sTime, _ = time.Parse("2006-01-02 15:04", startTime)
		nowTime, _ = time.Parse("2006-01-02 15:04", time.Now().Format("2006-01-02 15:04"))
	}
	fmt.Println("sTime: ",sTime,",nowTime: ",nowTime)

	addTime := 0
	//执行时间在现在时间之后
	if sTime.After(nowTime) {
		addTime = utils.GetMinCount(time.Now().Format("15:04"), sTime.Format("15:04"))
	}

	fmt.Println(addTime, "分钟后执行拉群",id)
	time.AfterFunc(time.Minute*cast.ToDuration(addTime), func() {

		if checkChatRoomIsStop(id) {
			log.Println("拉群任务已手动取消")
			return
		}

		ch := make(chan int, runCount)
		wg := sync.WaitGroup{}
		for i := 0; i < len(pullChatrooms); i++ {
			ch <- 1
			wg.Add(1)
			time.Sleep(time.Second * 1)
			go runPullChatRoom(&wg, userID,pullChatrooms[i].GetString("id"),customerID,fansType,useCount,id, ch)
		}
		wg.Wait()
		fmt.Println("拉群结束")
		go updatePlanStatus(id,2)
	})
}

//修改计划状态
func updatePlanStatus(id int, state int) {
	pullChatroomPlan,err := models.NewPullChatroomPlan()
	if err != nil {
		log.Println("pullChatroomPlan init error: ",err)
		return
	}
	pullChatroomPlan.SetId(cast.ToInt64(id))
	pullChatroomPlan.SetData("state",state)
	if err = pullChatroomPlan.Save();err != nil {
		log.Println("pullChatroomPlan save error: ",err)
	}
	return

}

func runPullChatRoom(wg *sync.WaitGroup, userID,pullChatRoomID string,customerID,fansType,useCount,id int, ch chan int) {
	fmt.Println("拉群任务: ", "二维码: ", pullChatRoomID)
	//fmt.Println("all wechatQueue: ",wechatQueue)

	defer func() {
		wg.Done()
		<-ch
	}()

	//30分钟没拉满强制退出
	flag := true
	go func() {
		time.AfterFunc(time.Minute * 30, func() {
			flag = false
		})
	}()

	for {
		wechatID := getPullWechat(userID,customerID,useCount,fansType)
		//wechatID := wechatQueue.Dequeue()
		if wechatID == "" {
			log.Println("没有人可拉了")
			break
		}

		needLoop := false
		if fansType == 0 {
			needLoop = AddOldFriendsTask(id,useCount,pullChatRoomID,wechatID)

		}else {
			needLoop = AddPullChatRoomTask(id,useCount,pullChatRoomID,wechatID)
		}
		if !needLoop {
			//回收机器人
			backWechat(wechatID)
			break
		}else {
			if !flag {
				changePullChatroom(cast.ToInt64(pullChatRoomID), map[string]interface{}{"state": 6})
				break
			}

			go func(wxID string) {
				time.AfterFunc(time.Minute * 30, func() {
					backWechat(wxID)
				})
			}(wechatID)
		}

		randData := rands.Intn(20)
		time.Sleep(time.Second * cast.ToDuration(10 + randData))
	}
	fmt.Println(pullChatRoomID,"的拉群结束")
}

//回退机器人使用状态
func backWechat(wechatID string) {
	wechatUseState,err := models.NewWechatUseState()
	if err != nil {
		return
	}
	wechatUseStates := wechatUseState.GetCollection()
	wechatUseStates.AddFieldToFilter("wechat_id","eq",wechatID)
	wechatUseStates.Load()
	wechatUseStates.Each(func(item *db.Item) {
		item.SetData("state",0)
		err := item.Save()
		if err != nil {
			log.Println("wechatUseState update 0 error: ",err)
		}
	})

}

var mutex3 sync.Mutex

func getPullWechat (userID string,customerID,useCount,fansType int) string {
	mutex3.Lock()
	defer mutex3.Unlock()

	finalWechatID := ""
	//几手粉
	if useCount < 0 {
		useCount = 0
	}

	if fansType == 0 {
		//原始粉
		oldFriends, _ := models.NewOldFriends()
		oldFriendses := oldFriends.GetCollection()
		oldFriendses.AddFieldToSelect("m.belon_wxid as wechat_id", "")
		oldFriendses.AddFieldToFilter("m.used_count", "eq", useCount)
		oldFriendses.AddFieldToFilter("m.user_id", "eq", userID)
		oldFriendses.AddFieldToFilter("dl.state", "eq", 0)
		oldFriendses.Join("ym_wechat_use_state as dl", "m.belon_wxid=dl.wechat_id", "dl.state as dlstate,dl.id as dlid")
		oldFriendses.Load()

		oldFriendsesItems := oldFriendses.GetItems()

		//所有微信号状态
		loginedMap := getWechatLoginMap(userID, oldFriendsesItems)

		for i := range oldFriendsesItems {
			belonWxid := oldFriendsesItems[i].GetString("wechat_id")
			wechatUseStateID := oldFriendsesItems[i].GetString("dlid")
			if loginedMap[belonWxid] == 12007 {
				finalWechatID = belonWxid

				wechatUseState,err := models.NewWechatUseState()
				if err != nil {
					continue
				}
				wechatUseState.SetId(cast.ToInt64(wechatUseStateID))
				wechatUseState.SetData("state",1)
				err = wechatUseState.Save()
				if err != nil {
					continue
				}
				break
			}
		}
	}else {
		//通讯录粉
		//获取加人数据
		addFriendLog, _ := models.NewAddFriendLog()
		addFriendLogs := addFriendLog.GetCollection()
		addFriendLogs.AddFieldToSelect("m.wechat_id", "")
		addFriendLogs.AddFieldToFilter("m.customer_id", "eq", customerID)
		addFriendLogs.AddFieldToFilter("m.state", "eq", 1)
		addFriendLogs.AddFieldToFilter("m.is_oneway_fans", "eq", 0)
		addFriendLogs.AddFieldToFilter("m.used_count", "eq", useCount)
		addFriendLogs.AddFieldToFilter("dl.state", "eq", 0)
		addFriendLogs.JoinLeft("ym_wechat_use_state as dl", "m.wechat_id=dl.wechat_id", "dl.state as dlstate,dl.id as dlid")
		addFriendLogs.Load()
		addFriendLogItems := addFriendLogs.GetItems()
		//所有微信号状态
		loginedMap := getWechatLoginMap(userID, addFriendLogItems)

		for i := range addFriendLogItems {
			wechatID := addFriendLogItems[i].GetString("wechat_id")
			wechatUseStateID := addFriendLogItems[i].GetString("dlid")
			if loginedMap[wechatID] == 12007 {
				finalWechatID = wechatID

				wechatUseState,err := models.NewWechatUseState()
				if err != nil {
					continue
				}
				wechatUseState.SetId(cast.ToInt64(wechatUseStateID))
				wechatUseState.SetData("state",1)
				err = wechatUseState.Save()
				if err != nil {
					continue
				}
				break
			}
		}
	}

	return finalWechatID
}

func splitArr(items []*db.Item,count int) [][]*db.Item {
	arrs := make([][]*db.Item,0)

	arr := make([]*db.Item,0)
	for i := range items {
		arr = append(arr, items[i])
		if len(arr) == count {
			arrs = append(arrs, arr)
			arr = []*db.Item{}
		}
		if i == len(items) - 1 {
			arrs = append(arrs, arr)
		}
	}
	return arrs
}

//注意每次需要重新查询获取最新值
func AddOldFriendsTask(id,useCount int,pullChatRoomID string,wechatID string) (flag bool) {

	if checkChatRoomIsStop(id) {
		log.Println("拉群任务已手动取消")
		return false
	}

	pullChatRoom,err := models.NewPullChatroom()
	if err != nil {
		return true
	}
	pullChatRoom.Load(cast.ToInt64(pullChatRoomID))

	if pullChatRoom.GetString("user_id") == "" {
		log.Println("获取userID失败")
		return false
	}

	oldFriends, err := models.NewOldFriends()
	if err != nil {
		return true
	}


	chatroomID := pullChatRoom.GetString("chatroom_id")                           //ID
	state := pullChatRoom.GetInt("state")                           //ID
	userID := pullChatRoom.GetString("user_id")                  //用户ID
	addCount := pullChatRoom.GetInt("add_chatroom_people_count") //加人数量(目标数量)	10
	oldItems := getPulledRoomItems(cast.ToString(pullChatRoom.GetId()), "0") //原始成员	6
	codeImgPath := pullChatRoom.GetString("code_img_path")       //二维码存放地址
	url := pullChatRoom.GetString("url")       //url
	oldCount := len(oldItems)
	needAddCount := oldCount - addCount	//
	if needAddCount < 0 {
		needAddCount = addCount - oldCount
	}else {
		log.Println("群原始成员数量够了,不再添加")
		return false
	}

	oldFriendses := oldFriends.GetCollection()
	oldFriendses.AddFieldToFilter("belon_wxid","eq",wechatID)
	oldFriendses.AddFieldToFilter("used_count","eq",useCount)
	oldFriendses.Load()

	addFriendLogMap := make(map[string]*db.Item)
	for i := range oldFriendses.GetItems() {
		addFriendLogMap[oldFriendses.GetItems()[i].GetString("wechat_id")] = oldFriendses.GetItems()[i]
	}

	var addFriendLogItems []*db.Item
	for _, v := range addFriendLogMap {
		addFriendLogItems = append(addFriendLogItems, v)
	}

	addDatas := splitArr(addFriendLogItems,8)

	//修改状态为小号进群
	if state == 0 {
		flag := changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 1})
		if !flag {
			return true
		}
	}

	//获取群信息&原始成员
	if oldCount == 0 && chatroomID == "" {
		roomID,err := QrcodeIntoRoom(userID,url,codeImgPath,wechatID)
		if err != nil {
			if strings.Index(err.Error(),"connection refused") != -1 || strings.Index(err.Error(),"proxyconnect") != -1 {
				return true
			}

			log.Println(url+"机器人扫码进群失败")
			changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 6})
			return false
		}

		pullChatRoom.SetData("chatroom_id", roomID)

		chatroomName := getChatRoomName(userID,wechatID,roomID)
		pullChatRoom.SetData("chatroom_name", chatroomName)

		err = pullChatRoom.Save()
		if err != nil {
			log.Println(" pullChatroom save error: ",err)
		}else {
			//获取群原始成员列表
			membersMapArr := GetChatroomMembers(userID, roomID, wechatID)

			for i := range membersMapArr {
				userName := cast.ToString(membersMapArr[i]["UserName"])
				nickName := cast.ToString(membersMapArr[i]["NickName"])
				//机器人除外
				if userName == wechatID {
					continue
				}
				SavePullChatroomItem(pullChatRoom.GetString("id"), userName, "", nickName, "群内原始成员",0)
			}
			oldCount = len(membersMapArr) - 1
		}
		chatroomID = roomID

	}else {
		log.Println("扫码进群")
		//扫码进群
		_, err := QrcodeIntoRoom(userID, url,codeImgPath, wechatID)
		if err != nil {
			log.Println("扫码进群失败")
			return true
		}
	}

	defer func() {
		//最后检查一遍
		roomMembers := GetChatroomMembers(userID, chatroomID, wechatID)
		log.Println(wechatID,"机器人退群",chatroomID,"退群前群实际人数:", len(roomMembers))
		//最后一个机器人退群
		flag := OutRoom(userID, chatroomID, wechatID)
		if !flag {
			log.Println(wechatID,"退群",chatroomID,"失败")
		}
	}()

	//数量够了不再添加
	pullPassItems := getPulledRoomItems(cast.ToString(pullChatRoom.GetId()), "1") //拉群通过的
	if len(pullPassItems) > 0 && len(pullPassItems) + oldCount >= addCount {
		log.Println("数量够了,不再添加")

		changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 4})
		return false
	}

	for addIndex := range addDatas {
		if addIndex == 2 {
			return true
		}
		addDataArr := addDatas[addIndex]
		if len(addDataArr) > 0 {


			//数量够了不再添加
			//roomMembers := GetChatroomMembers(userID, chatroomID, wechatID)
			////pullPassItems := getPulledRoomItems(cast.ToString(pullChatRoom.GetId()), "1") //拉群通过的
			//if len(roomMembers) >= addCount +1{
			//	log.Println(chatroomID,"群成员已满"+cast.ToString(len(roomMembers))+",不再添加")
			//
			//	////最后一个机器人退群
			//	//flag := OutRoom(userID, chatroomID, wechatID)
			//	//if !flag {
			//	//	log.Println(wechatID,"退群",chatroomID,"失败")
			//	//}
			//
			//	changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 4})
			//	return false
			//}


			pullPassItems := getPulledRoomItems(cast.ToString(pullChatRoom.GetId()), "1") //拉群通过的
			if len(pullPassItems) > 0 && len(pullPassItems) + oldCount >= addCount {
					log.Println(chatroomID,"群成员已满"+cast.ToString(len(pullPassItems) + oldCount)+",不再添加")

					changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 4})
					return false
			}else {
				needAddCount = addCount - oldCount - len(pullPassItems)
				if needAddCount > 8 {
					needAddCount = 8

				}
			}

			if needAddCount <= 0 {
				log.Println("不需要再拉人")
				changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 4})
				return false
			}

			//取数据
			addWechatIDs := make([]string,0)
			needAddWechats := make([]*db.Item,0)
			for e := range addDataArr {
				if e == needAddCount {
					break
				}
				addWechatIDs = append(addWechatIDs, addDataArr[e].GetString("wechat_id"))
				needAddWechats = append(needAddWechats, addDataArr[e])
			}

			fmt.Println("chatroomID: ",chatroomID,",wechatID:",wechatID,",addWechatIDs: ",addWechatIDs)

			//修改状态为小号进群成功
			if state < 2{
				flag := changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 2})
				if !flag {
					return true
				}
			}

			for index := range needAddWechats {
				item := needAddWechats[index]
				//修改使用次数
				item.SetData("used_count", useCount+1)
				err := item.Save()
				if err != nil {
					log.Println("修改加人记录使用次数失败,", err)
					continue
				}
			}

			//修改状态为小号正在拉人3
			if state < 3 {
				flag := changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 3})
				if !flag {
					return true
				}
			}

			//拉人进群
			fmt.Println(chatroomID,"通过",wechatID,"拉", len(addWechatIDs),"个人",addWechatIDs)
			_,pullerr := pullIntoRoom(userID, chatroomID, wechatID, addWechatIDs)
			if pullerr != nil {
				log.Println("本次拉人进群返回失败!",pullerr)
			}
			time.Sleep(time.Second * 6)
			//实时获取拉人列表
			membersMapArr := GetChatroomMembers(userID, chatroomID, wechatID)
			//在群里的
			successFriendsMap := make(map[string]int)
			for i := range membersMapArr {
				for j := range addWechatIDs {
					nickName := ""
					if addWechatIDs[j] == cast.ToString(membersMapArr[i]["UserName"]) {
						nickName = cast.ToString(membersMapArr[i]["NickName"])
						if nickName != ""{
							successFriendsMap[addWechatIDs[j]] = 1
							SavePullChatroomItem(pullChatRoom.GetString("id"), addWechatIDs[j], "", nickName, "进群成功",1)
						}
						break
					}
				}
			}

			//没在群里的为失败的
			for i := range addWechatIDs {
				if _,ok := successFriendsMap[addWechatIDs[i]];!ok {
					SavePullChatroomItem(pullChatRoom.GetString("id"), addWechatIDs[i], "", "", "进群失败",2 )
				}
			}

			if pullerr != nil {
				if strings.Index(pullerr.Error(),"该群因违规已被限制使用，无法添加群成员") != -1 {
					changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 6})
					return false
				}

			}


			randData := rands.Intn(5)
			time.Sleep(time.Second * cast.ToDuration(5 + randData))
		}
	}

	return true
}

//注意每次需要重新查询获取最新值
func AddPullChatRoomTask(id,useCount int,pullChatRoomID string,wechatID string) (flag bool) {

	if checkChatRoomIsStop(id) {
		log.Println("拉群任务已手动取消")
		return false
	}


	pullChatRoom,err := models.NewPullChatroom()
	if err != nil {
		return true
	}
	pullChatRoom.Load(cast.ToInt64(pullChatRoomID))

	if pullChatRoom.GetString("user_id") == "" {
		log.Println("获取userID失败")
		return false
	}

	addFriendLog, err := models.NewAddFriendLog()
	if err != nil {
		return true
	}


	chatroomID := pullChatRoom.GetString("chatroom_id")                           //ID
	state := pullChatRoom.GetInt("state")                           //ID
	userID := pullChatRoom.GetString("user_id")                  //用户ID
	addCount := pullChatRoom.GetInt("add_chatroom_people_count") //加人数量(目标数量)	10
	oldItems := getPulledRoomItems(cast.ToString(pullChatRoom.GetId()), "0") //原始成员	6
	codeImgPath := pullChatRoom.GetString("code_img_path")       //二维码存放地址
	url := pullChatRoom.GetString("url")       //url
	oldCount := len(oldItems)
	needAddCount := oldCount - addCount	//
	if needAddCount < 0 {
		needAddCount = addCount - oldCount
	}else {
		log.Println("群原始成员数量够了,不再添加")
		return false
	}

	addFriendLogs := addFriendLog.GetCollection()
	addFriendLogs.AddFieldToFilter("wechat_id","eq",wechatID)
	addFriendLogs.AddFieldToFilter("used_count","eq",useCount)
	addFriendLogs.AddFieldToFilter("state","eq",1)
	addFriendLogs.Load()
	addFriendLogItems := addFriendLogs.GetItems()

	addDatas := splitArr(addFriendLogItems,8)

	wechatIDPhoneMap := make(map[string]string)
	for i := range addFriendLogItems {
		wechatIDPhoneMap[addFriendLogItems[i].GetString("add_wechat_id")] = addFriendLogItems[i].GetString("add_phone")
	}




	//修改状态为小号进群
	if state == 0 {
		flag := changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 1})
		if !flag {
			return true
		}
	}

	//获取群信息&原始成员
	if oldCount == 0  && chatroomID == "" {
		roomID,err := QrcodeIntoRoom(userID,url,codeImgPath,wechatID)
		if err != nil {

			if strings.Index(err.Error(),"connection refused") != -1 {
				return true
			}

			log.Println(codeImgPath+"机器人扫码进群失败")
			changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 6})
			return false
		}

		pullChatRoom.SetData("chatroom_id", roomID)

		chatroomName := getChatRoomName(userID,wechatID,roomID)
		pullChatRoom.SetData("chatroom_name", chatroomName)

		err = pullChatRoom.Save()
		if err != nil {
			log.Println(" pullChatroom save error: ",err)
			return false
		}else {
			//获取群原始成员列表
			membersMapArr := GetChatroomMembers(userID, roomID, wechatID)

			for i := range membersMapArr {
				userName := cast.ToString(membersMapArr[i]["UserName"])
				nickName := cast.ToString(membersMapArr[i]["NickName"])
				//机器人除外
				if userName == wechatID {
					continue
				}
				SavePullChatroomItem(pullChatRoom.GetString("id"), userName, wechatIDPhoneMap[userName], nickName, "群内原始成员",0)
			}
			oldCount = len(membersMapArr) - 1
		}
		chatroomID = roomID
	}else {
		log.Println("扫码进群")
		//扫码进群
		_, err := QrcodeIntoRoom(userID,url, codeImgPath, wechatID)
		if err != nil {
			log.Println("扫码进群失败")
			return true
		}
	}

	defer func() {
		roomMembers := GetChatroomMembers(userID, chatroomID, wechatID)
		log.Println(wechatID,"机器人退群",chatroomID,"退群前群实际人数:", len(roomMembers))
		//最后一个机器人退群
		flag := OutRoom(userID, chatroomID, wechatID)
		if !flag {
			log.Println(wechatID,"退群",chatroomID,"失败")
		}
	}()

	//数量够了不再添加
	pullPassItems := getPulledRoomItems(cast.ToString(pullChatRoom.GetId()), "1") //拉群通过的
	if len(pullPassItems) > 0 && len(pullPassItems) + oldCount >= addCount {
		log.Println("数量够了,不再添加")
		changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 4})
		return false
	}

	for addIndex := range addDatas {
		if addIndex == 2 {
			return true
		}
		addDataArr := addDatas[addIndex]
		if len(addDataArr) > 0 {

			//数量够了不再添加
			//roomMembers := GetChatroomMembers(userID, chatroomID, wechatID)
			////pullPassItems := getPulledRoomItems(cast.ToString(pullChatRoom.GetId()), "1") //拉群通过的
			//if len(roomMembers) >= addCount +1{
			//	log.Println(chatroomID,"群成员已满"+cast.ToString(len(roomMembers))+",不再添加")
			//
			//	////最后一个机器人退群
			//	//flag := OutRoom(userID, chatroomID, wechatID)
			//	//if !flag {
			//	//	log.Println(wechatID,"退群",chatroomID,"失败")
			//	//}
			//
			//	changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 4})
			//	return false
			//}

			pullPassItems := getPulledRoomItems(cast.ToString(pullChatRoom.GetId()), "1") //拉群通过的
			if len(pullPassItems) > 0 && len(pullPassItems) + oldCount >= addCount {
				log.Println(chatroomID,"群成员已满"+cast.ToString(len(pullPassItems) + oldCount)+",不再添加")

				changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 4})
				return false
			}else {
				needAddCount = addCount - oldCount - len(pullPassItems)
				if needAddCount > 8 {
					needAddCount = 8

				}
			}

			if needAddCount <= 0 {
				log.Println("不需要再拉人")
				changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 4})
				return false
			}

			//取数据
			addWechatIDs := make([]string,0)
			needAddWechats := make([]*db.Item,0)
			for e := range addDataArr {
				if e == needAddCount {
					break
				}
				addWechatIDs = append(addWechatIDs, addDataArr[e].GetString("wechat_id"))
				needAddWechats = append(needAddWechats, addDataArr[e])
			}

			fmt.Println("chatroomID: ",chatroomID,",wechatID:",wechatID,",addWechatIDs: ",addWechatIDs)

			//修改状态为小号进群成功
			if state < 2{
				flag := changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 2})
				if !flag {
					return true
				}
			}

			for index := range needAddWechats {
				item := needAddWechats[index]
				//修改使用次数
				item.SetData("used_count", useCount+1)
				err := item.Save()
				if err != nil {
					log.Println("修改加人记录使用次数失败,", err)
					continue
				}
			}

			//修改状态为小号正在拉人3
			if state < 3 {
				flag := changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 3})
				if !flag {
					return true
				}
			}

			//拉人进群
			fmt.Println(chatroomID,"通过",wechatID,"拉", len(addWechatIDs),"个人",addWechatIDs)
			_,pullerr := pullIntoRoom(userID, chatroomID, wechatID, addWechatIDs)
			if pullerr != nil {
				log.Println("本次拉人进群返回失败!",pullerr)
			}
			time.Sleep(time.Second * 6)
			//实时获取拉人列表
			membersMapArr := GetChatroomMembers(userID, chatroomID, wechatID)
			//在群里的
			successFriendsMap := make(map[string]int)
			for i := range membersMapArr {
				for j := range addWechatIDs {
					nickName := ""
					if addWechatIDs[j] == cast.ToString(membersMapArr[i]["UserName"]) {
						nickName = cast.ToString(membersMapArr[i]["NickName"])
						if nickName != ""{
							successFriendsMap[addWechatIDs[j]] = 1
							SavePullChatroomItem(pullChatRoom.GetString("id"), addWechatIDs[j], wechatIDPhoneMap[addWechatIDs[j]], nickName, "进群成功",1)
						}
						break
					}
				}
			}

			//没在群里的为失败的
			for i := range addWechatIDs {
				if _,ok := successFriendsMap[addWechatIDs[i]];!ok {

					SavePullChatroomItem(pullChatRoom.GetString("id"), addWechatIDs[i], wechatIDPhoneMap[addWechatIDs[i]], "", "进群失败",2 )
				}
			}

			if pullerr != nil {
				if strings.Index(pullerr.Error(),"该群因违规已被限制使用，无法添加群成员") != -1 {
					changePullChatroom(cast.ToInt64(pullChatRoom.GetId()), map[string]interface{}{"state": 6})
					return false
				}

			}

			randData := rands.Intn(5)
			time.Sleep(time.Second * cast.ToDuration(5 + randData))
		}
	}
	return true
}

func getChatRoomName(userID,wechatID,roomID string) string {
	dataMap := make(map[string]interface{})
	dataMap["id"] = roomID
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,wechatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/getcontact",dataMap,heardMap)
	if err != nil {
		log.Println("getcontact error: ",err)
	}

	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(resp),&maps)
	if err != nil {
		log.Println("getcontact json.Unmarshal error: ",err)
	}

	contactResponse := models.ContactResponse{}
	b2,err := json.Marshal(maps["Data"])
	if err != nil {
		log.Println("searchContactResponse json.Marshal error: ",err)
	}
	err = json.Unmarshal(b2,&contactResponse)
	if err != nil {
		log.Println("searchContactResponse json.Unmarshal error: ",err)
	}
	//{"Code":0,"Data":{"BaseResponse":{"Ret":0,"ErrMsg":{}},"ContactCount":1,"ContactList":[{"UserName":{"String":"23278043515@chatroom"},"NickName":{"String":"四大天王"},"PYInitial":{"String":"SDTW"},"QuanPin":{"String":"sidatianwang"},"Sex":0,"ImgBuf":{"iLen":0},"BitMask":4294967295,"BitVal":2,"ImgFlag":3,"Remark":{},"RemarkPYInitial":{},"RemarkQuanPin":{},"ContactType":0,"RoomInfoCount":0,"DomainList":{},"ChatRoomNotify":1,"AddContactScene":0,"PersonalCard":0,"HasWeiXinHdHeadImg":0,"VerifyFlag":0,"Level":0,"Source":0,"ChatRoomOwner":"wxid_iltchhxm10to22","WeiboFlag":0,"AlbumStyle":0,"AlbumFlag":0,"SnsUserInfo":{"SnsFlag":0,"SnsBGObjectID":0,"SnsFlagEx":0},"SmallHeadImgUrl":"http://wx.qlogo.cn/mmcrhead/ucCIFkMVsPWlAwEhMgMIKBav0sDD6CMBV8KEY2Kj4MrBibia6rjpric1EvL87ul6ISkLy96bZhoE9N3v6dr10xMByn9gReAy9kO/0","CustomizedInfo":{"BrandFlag":0},"EncryptUserName":"v1_a5113efc2aadef892f23475622f13b027651a269007c773f6f5452e9d4b532ac6c76ea29570798a3dddb26824991e022@stranger","AdditionalContactList":{"LinkedinContactItem":{}},"ChatroomVersion":700000070,"ChatroomMaxCount":500,"ChatroomType":0,"NewChatroomData":{"MemberCount":21,"ChatRoomMember":[{"UserName":"wxid_d9d01lwjatzz22","NickName":"花无名","ChatroomMemberFlag":0},{"UserName":"wxid_iltchhxm10to22","NickName":"lukebryan","ChatroomMemberFlag":1},{"UserName":"wxid_0f11e48jn3ag22","NickName":"ぬTheatheや","ChatroomMemberFlag":0},{"UserName":"zhoudongfei1986","NickName":"周东飞","ChatroomMemberFlag":1},{"UserName":"wxid_6yopanh209fq22","NickName":"やShidaや","ChatroomMemberFlag":0},{"UserName":"wxid_btd4blipfdsr22","NickName":"琅琊","ChatroomMemberFlag":1},{"UserName":"wxid_7oau0za2xjqs12","NickName":"张阳灰","ChatroomMemberFlag":0},{"UserName":"wxid_fjgylqidz4uq12","NickName":"董琦宁","ChatroomMemberFlag":0},{"UserName":"wxid_sw50z0pq9gzj21","NickName":"影子传说","ChatroomMemberFlag":1},{"UserName":"wxid_v96i4s1sug4722","NickName":"こMaphasけ","ChatroomMemberFlag":0},{"UserName":"wxid_k185kwjyixz322","NickName":"花无名","ChatroomMemberFlag":0},{"UserName":"wxid_tehd7ooigh8b12","NickName":"高基育","ChatroomMemberFlag":1},{"UserName":"wxid_u2a6uofxyl3y22","NickName":"ひCosouthま","ChatroomMemberFlag":0},{"UserName":"wxid_tlyg3zmmvhm522","NickName":"一袭素衫","ChatroomMemberFlag":0},{"UserName":"wxid_lvzggmmml7bm22","NickName":"扎兰屯微平台清粉中","ChatroomMemberFlag":1},{"UserName":"wxid_cs2v54z60xrr22","NickName":"查干","ChatroomMemberFlag":1},{"UserName":"wxid_orlr8102rqlm22","NickName":"A.腾龙社🔱鬼刃","ChatroomMemberFlag":1},{"UserName":"hjgsjd2009","NickName":"薛瑞成📲18047193429","ChatroomMemberFlag":1},{"UserName":"wxid_3kfzwmbi8wxu22","NickName":"一把火","ChatroomMemberFlag":0},{"UserName":"wxid_vz7z62md6tp912","NickName":"Quỳnh Quỳnh","ChatroomMemberFlag":1},{"UserName":"wxid_shu2vwptquqs22","NickName":"贺圆章","ChatroomMemberFlag":0}],"InfoMask":1},"DeleteFlag":0}],"Ret":[0]},"Msg":"获取成功"}
	roomName := ""
	if len(contactResponse.ContactList) > 0 {
		if contactResponse.ContactList[0].NickName.String_ != nil {
			roomName = fmt.Sprint(*contactResponse.ContactList[0].NickName.String_)
		}
	}
	//username := ""
	//if contactResponse.ContactCount > 0 {
	//	if contactResponse.ContactList[0].UserName.String_ != nil {
	//		username = fmt.Sprint(*contactResponse.ContactList[0].UserName.String_)
	//	}
	//
	//}

	return roomName
}

func SavePullChatroomItem(pullChatroomID, wechatID, phone, nickName, msg string,state int) {
	pullChatroomItem, _ := models.NewPullChatroomItem()

	pullChatroomItems := pullChatroomItem.GetCollection()
	pullChatroomItems.AddFieldToFilter("pull_chatroom_id","eq",pullChatroomID)
	pullChatroomItems.AddFieldToFilter("wechat_id","eq",wechatID)
	//pullChatroomItems.AddFieldToFilter("state","eq",state)
	if pullChatroomItems.GetSize() > 0 {
		return
	}

	pullChatroomItem.SetData("pull_chatroom_id", pullChatroomID)
	pullChatroomItem.SetData("wechat_id", wechatID)
	pullChatroomItem.SetData("phone", phone)
	pullChatroomItem.SetData("wechat_nickname", nickName)
	pullChatroomItem.SetData("state", state)
	pullChatroomItem.SetData("msg", msg)
	err := pullChatroomItem.Save()
	if err != nil {
		log.Println("pullChatroomItem Save Error: ", err)
		pullChatroomItem.SetData("wechat_nickname", "")
		err = pullChatroomItem.Save()
		if err != nil {
			log.Println("pullChatroomItem Save Error2: ", err)
		}
		return
	}
}

//获取
func getWechatLoginMap(userID string, items []*db.Item) map[string]int {
	finalMap := make(map[string]int)

	wechatMaps := make(map[string]string)
	for i := range items {
		wechatMaps[items[i].GetString("wechat_id")] = items[i].GetString("wechat_id")
	}
	var wechatArr []string
	for _, v := range wechatMaps {
		wechatArr = append(wechatArr, v)
	}

	//获取登录状态
	dataMap := make(map[string]interface{})
	dataMap["wxid_list"] = strings.Join(wechatArr, ",")
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, "")
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/batchcheckloginstatus", dataMap, heardMap)
	if err != nil {
		log.Println("batchcheckloginstatus error: ", err)
		return finalMap
	}

	fmt.Println("登录状态返回数据:", data)

	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(data), &maps)
	if err != nil {
		log.Println("batchcheckloginstatus json.Unmarshal Error: ", err)
		return finalMap
	}

	b, err := json.Marshal(maps["Data"])
	if err != nil {
		log.Println("batchcheckloginstatus json.Marshal Error: ", err)
		return finalMap
	}
	err = json.Unmarshal(b, &finalMap)
	if err != nil {
		log.Println("batchcheckloginstatus json.Unmarshal Error: ", err)
		return finalMap
	}

	return finalMap
}

func OutRoom(userID, roomID, weChatID string) bool {
	dataMap := make(map[string]interface{})
	dataMap["room_id"] = roomID
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, weChatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/quit", dataMap, heardMap)
	if err != nil {
		log.Println("PostFormRequest Error: ", err)
		return false
	}
	log.Println("quit resp: ", resp)
	respMap := make(map[string]interface{})
	err = json.Unmarshal([]byte(resp), &respMap)
	if err != nil {
		log.Println("json.Unmarshal Error: ", err)
		return false
	}
	if cast.ToString(respMap["Code"]) == "-1" {
		return false
	}

	return true
}

func GetCodeUrl(codeImgPath string) string {
	imgPath := config.Sysconfig.FileSavePath + "/" + codeImgPath
	log.Println("二维码: ", imgPath)
	imgPath = strings.Replace(imgPath, "\\", "/", 0)
	filename := imgPath [strings.LastIndex(imgPath, "/")+1:]
	//解析二维码
	bodyBuf := &bytes.Buffer{}
	bodyWriter := multipart.NewWriter(bodyBuf)

	fileWriter, err := bodyWriter.CreateFormFile("fileName", filename)
	if err != nil {
		fmt.Println("error writing to buffer")
		return ""
	}

	//打开文件句柄操作
	fh, err := os.Open(imgPath)
	if err != nil {
		fmt.Println("error opening file")
		return ""
	}
	defer fh.Close()

	//iocopy
	_, err = io.Copy(fileWriter, fh)
	if err != nil {
		log.Println("io.Copy Error: ", err)
		return ""
	}

	contentType := bodyWriter.FormDataContentType()
	bodyWriter.Close()

	resp, err := http.Post(config.Sysconfig.QrcodeServerAddr+"/decode", contentType, bodyBuf)
	if err != nil {
		log.Println(config.Sysconfig.QrcodeServerAddr+"/decode"+" Error: ", err)
		return ""
	}
	defer resp.Body.Close()
	respBody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Println("ioutil.ReadAll(resp.Body) Error: ", err)
		return ""
	}
	fmt.Println(resp.Status)
	fmt.Println(string(respBody))

	respMap := make(map[string]interface{})
	err = json.Unmarshal(respBody, &respMap)
	if err != nil {
		log.Println("json.Unmarshal Error: ", err)
		return ""
	}

	url := cast.ToString(respMap["data"])

	return url
}

//扫码进群
func QrcodeIntoRoom(userID, url,codeImgPath, wechatID string) (string, error) {

	if url == "" {
		url = GetCodeUrl(codeImgPath)
		if url == "" {
			return "",errors.New("解析二维码失败")
		}
	}

	loopCount := 0
	for {
		dataMap := make(map[string]interface{})
		dataMap["url"] = url
		heardMap := make(map[string]string)
		heardMap["Authorization"] = utils.GentToken(userID, wechatID)
		resp2, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/joinbyurl", dataMap, heardMap)
		if err != nil {
			log.Println("PostFormRequest Error: ", err)
			if strings.Index(err.Error(),"Timeout") != -1 {
				loopCount ++
				if loopCount > 2 {
					return "", err
				}
				time.Sleep(time.Second * 60)
				continue
			}
			return "", err
		}
		log.Println("scanqrjoin resp: ", resp2)
		respMap2 := make(map[string]interface{})
		err = json.Unmarshal([]byte(resp2), &respMap2)
		if err != nil {
			log.Println("json.Unmarshal Error: ", err)
			return "", err
		}
		if cast.ToString(respMap2["Code"]) == "-1" {
			return "", err
		}

		//"Data":{"Op":"Post","URL":"weixin://jump/mainframe/23072140691@chatroom","Err":{}}

		b, err := json.Marshal(respMap2["Data"])
		if err != nil {
			log.Println("json.Marshal Error: ", err)
			return "", err
		}
		err = json.Unmarshal(b, &respMap2)
		if err != nil {
			log.Println("json.Unmarshal Error: ", err)
			return "", err
		}
		data := cast.ToString(respMap2["URL"])

		if strings.Index(data, "@chatroom") >= 0 {
			data = data[:strings.Index(data, "@chatroom")+9]
		}
		if strings.Index(data, "/") >= 0 {
			data = data[strings.LastIndex(data, "/")+1:]
		}

		if strings.Index(data, "@chatroom") == -1 {
			data = ""
		}

		if data == "" {
			return "", err
		}

		fmt.Println(respMap2["Data"], "扫码进群后获取到的roomID: ", data)
		return data, nil
	}
	
}

//拉人
func pullIntoRoom(userID, roomID, wechatID string,addWechatIDs []string) ([]models.MemberList,error) {
	var memberList []models.MemberList

	if roomID == "" || wechatID == "" || len(addWechatIDs) == 0 {
		return memberList,errors.New("缺少拉人必要数据"+roomID+wechatID)
	}

	dataMap := make(map[string]interface{})
	dataMap["room_id"] = roomID //"9291272115@chatroom"//"6976946239@chatroom"

	//friendWxID := GetFriendWxID(userID, wechatID, addPhone)
	dataMap["members"] = strings.Join(addWechatIDs,",") //"wxid_57h9ejzu50wf22"		//"abc891709"
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wechatID)
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/addnewmembers", dataMap, heardMap)
	if err != nil {
		log.Println("PostFormRequest Error: ", err)
		return memberList,err
	}

	//b3,err := json.Marshal(data)
	//if err != nil {
	//	log.Println("PostFormRequest Error: ", err)
	//	return memberList,err
	//}

	addRespMap := make(map[string]interface{})
	err = json.Unmarshal([]byte(data), &addRespMap)
	if err != nil {
		log.Println("chatroom/addnewmembers json.Unmarshal3 Error: ", err)
		return memberList,err
	}
	if cast.ToString(addRespMap["Code"]) == "-1" {
		return memberList,errors.New(cast.ToString(addRespMap["Msg"]))
	}

	//"Data":{"BaseResponse":{"Ret":0,"ErrMsg":{"String":"Everything is OK"}},"MemberCount":2,
	//	"MemberList":[{"MemberName":{"String":"wxid_tkzhhyyfrehb22"},"MemberStatus":4,"NickName":{},
	//	"PYInitial":{},"QuanPin":{},"Sex":0,"Remark":{},"RemarkPYInitial":{},"RemarkQuanPin":{},
	//	"ContactType":0,"PersonalCard":0,"VerifyFlag":0},
	//	{"MemberName":{"String":"wxid_tnb3o96df8bz22"},"MemberStatus":0,"NickName":{"String":"二平"},
	//	"PYInitial":{"String":"EP"},"QuanPin":{"String":"erping"},"Sex":1,"Remark":{},
	//	"RemarkPYInitial":{},"RemarkQuanPin":{},"ContactType":0,"PersonalCard":1,"VerifyFlag":0,
	//	"Country":"AD"}]}

	b,err := json.Marshal(addRespMap["Data"])
	if err != nil {
		log.Println("chatroom/addnewmembers json.Marshal Error: ", err)
		return memberList,err
	}
	err = json.Unmarshal(b, &addRespMap)
	if err != nil {
		log.Println("chatroom/addnewmembers json.Unmarshal4 Error: ", err)
		return memberList,err
	}

	//"BaseResponse":{"Ret":0,"ErrMsg":{"String":"Everything is OK"}}
	baseResponse := models.BaseResponse{}
	b3,err := json.Marshal(addRespMap["BaseResponse"])
	if err != nil {
		log.Println("baseResponse json.Marshal6 Error: ", err)
		return memberList,err
	}
	err = json.Unmarshal(b3, &baseResponse)
	if err != nil {
		log.Println("baseResponse json.Unmarshal7 Error: ", err)
		return memberList,err
	}
	errStr := "MemberList are wrong"
	if baseResponse.ErrMsg.String_ != nil {
		errStr = fmt.Sprint(*baseResponse.ErrMsg.String_)
	}

	if errStr != "Everything is OK" {
		return memberList,errors.New(errStr)
	}

	b2,err := json.Marshal(addRespMap["MemberList"])
	if err != nil {
		log.Println("chatroom/addnewmembers json.Marshal Error: ", err)
		return memberList,err
	}
	err = json.Unmarshal(b2, &memberList)
	if err != nil {
		log.Println("chatroom/addnewmembers json.Unmarshal5 Error: ", err)
		return memberList,err
	}

	return memberList,nil
}
//
////拉人
//func pullOneIntoRoom(userID, roomID, wechatID string,addWechat string) (string,error) {
//
//	if roomID == "" || wechatID == "" || addWechat == "" {
//		return "",errors.New("缺少拉人必要数据"+roomID+wechatID)
//	}
//
//	dataMap := make(map[string]interface{})
//	dataMap["room_id"] = roomID //"9291272115@chatroom"//"6976946239@chatroom"
//
//	//friendWxID := GetFriendWxID(userID, wechatID, addPhone)
//	dataMap["members"] = addWechat //"wxid_57h9ejzu50wf22"		//"abc891709"
//	heardMap := make(map[string]string)
//	heardMap["Authorization"] = utils.GentToken(userID, wechatID)
//	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/addnewmembers", dataMap, heardMap)
//	if err != nil {
//		log.Println("PostFormRequest Error: ", err)
//		return "",err
//	}
//	addRespMap := make(map[string]interface{})
//	err = json.Unmarshal([]byte(data), &addRespMap)
//	if err != nil {
//		log.Println("chatroom/addnewmembers json.Unmarshal1 Error: ", err)
//		return "",err
//	}
//	if cast.ToString(addRespMap["Code"]) == "-1" {
//		return "",errors.New(cast.ToString(addRespMap["Msg"]))
//	}
//
//	b,err := json.Marshal(addRespMap["Data"])
//	if err != nil {
//		log.Println("chatroom/addnewmembers json.Marshal Error: ", err)
//		return "",err
//	}
//	err = json.Unmarshal(b, &addRespMap)
//	if err != nil {
//		log.Println("chatroom/addnewmembers json.Unmarshal2 Error: ", err)
//		return "",err
//	}
//
//
//	var memberList []models.MemberList
//	b2,err := json.Marshal(addRespMap["MemberList"])
//	if err != nil {
//		log.Println("chatroom/addnewmembers json.Marshal Error: ", err)
//		return "",err
//	}
//	err = json.Unmarshal(b2, &memberList)
//	if err != nil {
//		log.Println("chatroom/addnewmembers json.Unmarshal Error: ", err)
//		return "",err
//	}
//
//	var memberStatus int32 = 4
//	nickName := ""
//	if len(memberList) > 0 {
//		if memberList[0].NickName.String_ != nil {
//			nickName = fmt.Sprint(*memberList[0].NickName.String_)
//		}
//		memberStatus = memberList[0].MemberStatus
//	}
//
//	if memberStatus != 0 {
//		return "",errors.New("MemberList are wrong")
//	}
//
//	return nickName,nil
//}

//获取群成员
func GetChatroomMembers(userID, roomID, wechatID string) []map[string]interface{} {

	membersMapArr := make([]map[string]interface{}, 0)

	dataMap := make(map[string]interface{})
	dataMap["room_id"] = roomID
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wechatID)
	membersResp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/chatroom/getchatroommembers", dataMap, heardMap)
	if err != nil {
		log.Println("getchatroommembers PostFormRequest Error: ", err)
		return membersMapArr
	}
	log.Println("getchatroommembers resp: ", membersResp)
	membersRespMap := make(map[string]interface{})
	err = json.Unmarshal([]byte(membersResp), &membersRespMap)
	if err != nil {
		log.Println("membersRespMap json.Unmarshal Error: ", err)
		return membersMapArr
	}
	if cast.ToString(membersRespMap["Code"]) == "-1" {
		return membersMapArr
	}

	b2, err := json.Marshal(membersRespMap["Data"])
	if err != nil {
		log.Println("upRespMap json.Marshal Error: ", err)
		return membersMapArr
	}
	err = json.Unmarshal(b2, &membersMapArr)
	if err != nil {
		log.Println("membersMapArr json.Unmarshal Error: ", err)
		return membersMapArr
	}
	return membersMapArr
}

//修改拉人信息
func changePullChatroom(id int64, data map[string]interface{}) bool {
	if id == 0 {
		return false
	}

	m, err := models.NewPullChatroom()
	if err != nil {
		return false
	}
	m.SetId(id)
	for k, v := range data {
		m.SetData(k, v)
	}
	err = m.Save()
	if err != nil {
		log.Println("pullChatRoom Update State", err)
		return false
	}
	return true
}

//获取拉群信息
func getPulledRoomItems(pullChatroomID, state string) []*db.Item {
	pullChatroomItem, err := models.NewPullChatroomItem()
	if err != nil {
		return []*db.Item{}
	}
	pullChatroomItems := pullChatroomItem.GetCollection()
	pullChatroomItems.AddFieldToFilter("pull_chatroom_id", "eq", pullChatroomID)
	pullChatroomItems.AddFieldToFilter("state", "eq", state)
	pullChatroomItems.Load()
	return pullChatroomItems.GetItems()
}

//保存原始粉
func SaveOldFriends(wechatID,userID string) {

	//保存到使用状态
	go saveWechatUseState(wechatID)

	of,err := models.NewOldFriends()
	if err != nil {
		return
	}
	ofs := of.GetCollection()
	ofs.AddFieldToFilter("belon_wxid","eq",wechatID)
	if ofs.GetSize() > 0 {
		return
	}
	//同步
	SyncContacts(userID,wechatID,0,0)

	//排除加好友记录表好友
	addFriendLog,err := models.NewAddFriendLog()
	addFriendLogs := addFriendLog.GetCollection()
	addFriendLogs.AddFieldToFilter("wechat_id","eq",wechatID)
	addFriendLogs.AddFieldToFilter("state","eq",1)
	addFriendLogs.Load()

	addFriendLogsMap := make(map[string]int)
	addFriendLogs.Each(func(item *db.Item) {
		addFriendLogsMap[item.GetString("add_wechat_id")] = 1
	})

	//获取好友
	var friendMaps []map[string]interface{}
	GetContacts(userID,wechatID,1,200,&friendMaps)
	for i := range friendMaps {
		userName := utils.Base64DecodeString(cast.ToString(friendMaps[i]["wxid"]))
		contactType := utils.Base64DecodeString(cast.ToString(friendMaps[i]["contact_type"]))

		if userName == "" || userName == "null" {
			userName = utils.Base64DecodeString(cast.ToString(friendMaps[i]["user_name"]))
		}

		if contactType != "0" {
			continue
		}

		if addFriendLogsMap[userName] == 1 {
			continue
		}

		oldFriend,err := models.NewOldFriends()
		if err != nil {
			continue
		}
		oldFriend.SetData("belon_wxid",wechatID)
		oldFriend.SetData("wechat_id",userName)
		oldFriend.SetData("user_id",userID)
		oldFriend.SetData("used_count",0)
		if err = oldFriend.Save(); err != nil {
			log.Println("oldFriend save error: ",err)
			continue
		}
	}
}

func saveWechatUseState(wechatID string) {
	wechatUseState,err := models.NewWechatUseState()
	if err != nil {
		return
	}
	wechatUseStates := wechatUseState.GetCollection()
	wechatUseStates.AddFieldToFilter("wechat_id","eq",wechatID)
	if wechatUseStates.GetSize() > 0 {
		return
	}
	wechatUseState.SetData("wechat_id",wechatID)
	if err = wechatUseState.Save(); err != nil {
		log.Println("wechatUseState save error: ",err)
	}
}

//是否已停止
func checkChatRoomIsStop(id int) bool {
	m, _ := models.NewPullChatroomPlan()
	m.Load(cast.ToInt64(id))
	if m.GetString("state") == "3" {
		return true
	}
	return false
}