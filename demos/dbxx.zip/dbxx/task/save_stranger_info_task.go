/*
@Time : 2019/6/24 14:07 
@Author : Lukebryan
@File : save_stranger_info_task.go
@Software: GoLand
*/
package task

import (
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"github.com/spf13/cast"
	"log"
	"wechatmanagent/models"
)


/*
保存陌生人信息
 */
func (t Task) SaveStrangerInfoTask() {
	spec := "0 0 22 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {
		user,err := models.NewUser()
		if err != nil {
			log.Println("结构体初始化失败")
			return
		}
		users := user.GetCollection()
		users.Load()
		users.Each(func(userItem *db.Item) {

			userID := userItem.GetString("id")

			wechat,_ := models.NewBindWechat()
			wechats := wechat.GetCollection()
			wechats.AddFieldToFilter("user_id","eq",userID)
			wechats.Load()
			wechatItems := wechats.GetItems()
			loginMap := getWechatLoginMap(userID,wechatItems)

			var onlineWechats []string
			for k,v := range loginMap{
				if v == 12007 {
					onlineWechats = append(onlineWechats, k)
				}
			}

			//var addFriendLogWechats []string
			//addFriendLog,_ := models.NewAddFriendLog()
			//addFriendLogs := addFriendLog.GetCollection()
			//addFriendLogs.AddFieldToFilter("user_id","eq",userID)
			//addFriendLogs.AddFieldToFilter("create_date","like",time.Now().Format("2006-01-02"))
			//addFriendLogs.Load()
			//addFriendLogs.Each(func(item *db.Item) {
			//	addFriendLogWechats = append(addFriendLogWechats, item.GetString("wechat_id"))
			//})

			//可以搜索好友的微信号
			//var canSearchContactWechats []string
			//wechats.AddFieldToFilter("wechat_id","in",strings.Join(onlineWechats,"','"))
			//wechats.AddFieldToFilter("wechat_id","nin",strings.Join(addFriendLogWechats,"','"))
			//wechats.Load()
			//wechats.Each(func(item *db.Item) {
			//	canSearchContactWechats = append(canSearchContactWechats, item.GetString("wechat_id"))
			//})
			//可以搜索手机号微信信息的数据(手机号)
			wechatsCount := len(onlineWechats)
			var searchData []string
			importData,_ := models.NewImportData()
			importDatas := importData.GetCollection()
			importDatas.AddFieldToFilter("user_id","eq",userID)
			importDatas.AddFieldToFilter("state","eq",0)
			importDatas.SetCurPage(1)
			importDatas.SetPageSize(cast.ToInt64(wechatsCount * 5))
			importDatas.Load()
			importDatas.Each(func(item *db.Item) {
				searchData = append(searchData, item.GetString("wechat_id"))
			})

			maps := GetWechatPhonesMap(onlineWechats,searchData)

			var successWechats []string
			var failData []string

			for wxID,datas := range maps{
				var fData []string
				for i := range datas{
					toWxID := GetFriendWxID(userID,wxID,datas[i])
					if toWxID == "" {
						failData = append(failData, datas[i])
						fData = append(fData, datas[i])
					}
				}
				if len(fData) == 0 {
					successWechats = append(successWechats, wxID)
				}
			}

			maps = GetWechatPhonesMap(successWechats,failData)
			for wxID,datas := range maps{
				for i := range datas{
					GetFriendWxID(userID,wxID,datas[i])
				}
			}
		})
	})
	c.Start()
	select {}
}
