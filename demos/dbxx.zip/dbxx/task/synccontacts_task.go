/*
@Time : 2019/6/4 9:19 
@Author : Lukebryan
@File : synccontacts_task.go
@Software: GoLand
*/
package task

import (
	"encoding/json"
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"github.com/spf13/cast"
	"log"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

/*
同步联系人
 */
func (t Task) SyncContactsTask() {
	//TODO 消息队列
	//spec := "0 0 6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23 * * ?" // 分 时 日 月 星期
	spec := "0 0 6,8,10,12,14,16,18,20,22 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {
		fmt.Println("2个小时一次的同步联系人")
		user,err := models.NewUser()
		if err != nil {
			log.Println("获取结构体异常")
			return
		}
		users := user.GetCollection()
		users.Load()
		users.Each(func(item *db.Item) {
			userID := item.GetString("id")

			m, _ := models.NewBindWechat()
			d := m.GetCollection()
			d.AddFieldToFilter("user_id","eq",userID)
			d.AddOrder("id desc")
			d.Load()
			wechatItems := d.GetItems()
			//登录状态
			loginStateMaps := getWechatLoginMap(userID,wechatItems)

			for k,v := range loginStateMaps{
				if v == 12007 {
					go SyncContacts(userID,k,0,0)
				}
			}
		})
	})
	c.Start()
	select {}
}

func SyncContacts(userID,wechatID string,currentContactSeq,currentChatroomContactSeq int) {
	fmt.Println("userID,wechatID: ",userID,"--",wechatID)
	dataMap := make(map[string]interface{})
	dataMap["currentContactSeq"] = currentContactSeq
	dataMap["currentChatroomContactSeq"] = currentChatroomContactSeq
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,wechatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/synccontacts",dataMap,heardMap)
	if err != nil {
		log.Println("synccontacts error: ",err)
		return
	}
	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(resp), &maps)
	if err != nil {
		log.Println("synccontacts json.Unmarshal Error: ", err)
		return
	}

	b, err := json.Marshal(maps["Data"])
	if err != nil {
		log.Println("synccontacts json.Marshal Error: ", err)
		return
	}
	//{"Code":0,"Data":{"LoopFlag":false,"FailedContacts":null,"CurrentContactSeq":0,"CurrentChatroomContactSeq":0},"Msg":"同步成功"}
	finalMap := make(map[string]interface{})
	err = json.Unmarshal(b, &finalMap)
	if err != nil {
		log.Println("synccontacts json.Unmarshal Error: ", err)
		return
	}
	if !cast.ToBool(finalMap["LoopFlag"]) {

		return
	}else {
		SyncContacts(userID,wechatID,cast.ToInt(finalMap["CurrentContactSeq"]),cast.ToInt(finalMap["CurrentChatroomContactSeq"]))
	}
}

//获取联系人
func GetContacts(customerID,wechatID string,page,size int,friendMaps *[]map[string]interface{}) {


	dataMap := make(map[string]interface{})
	dataMap["page"] = page
	dataMap["size"] = size
	dataMap["contact_type"] = 0
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(customerID,wechatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/getcontacts",dataMap,heardMap)
	if err != nil {
		log.Println("getcontacts Error: ", err)
		return
	}
	maps := make(map[string]interface{},0)
	err = json.Unmarshal([]byte(resp), &maps)
	if err != nil {
		log.Println("getcontacts json.Unmarshal Error: ", err)
		return
	}

	b,err := json.Marshal(maps["Data"])
	if err != nil {
		log.Println("getcontacts json.Marshal Error: ", err)
		return
	}
	err = json.Unmarshal(b,&maps)
	if err != nil {
		log.Println("getcontacts json.Unmarshal Error: ", err)
		return
	}

	total := cast.ToInt(maps["total"])

	b2,err := json.Marshal(maps["list"])
	if err != nil {
		log.Println("getcontacts json.Marshal Error: ", err)
		return
	}
	var maps2 []map[string]interface{}
	err = json.Unmarshal(b2,&maps2)
	if err != nil {
		log.Println("getcontacts json.Unmarshal Error: ", err)
		return
	}

	if len(maps2) == 0 {
		return
	}

	for i := range maps2 {
		if len(*friendMaps) == total {
			return
		}
		*friendMaps = append(*friendMaps, maps2[i])
	}
	GetContacts(customerID,wechatID,page+1,size,friendMaps)
}
