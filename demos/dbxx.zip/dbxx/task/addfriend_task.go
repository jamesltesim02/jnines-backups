/*
@Time : 2019/5/20 20:05 
@Author : Lukebryan
@File : addfriend_task.go	加人计划(机器人添加手机号为好友任务)
@Software: GoLand
*/
package task

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"github.com/spf13/cast"
	"log"
	"math/rand"
	"strings"
	"sync"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

const (
	FinalLoopCount = 10		//加人最多循环次数
	FinalLoopMin = 5		//同步通讯录间隔时间
)

var rands = rand.New(rand.NewSource(time.Now().Unix()))

var mutex2 sync.Mutex
var addFriendEndTime = make(map[string]time.Time,0)
func SetAddFriendEndTime(planID string,endTime time.Time)  {
	mutex2.Lock()
	addFriendEndTime[planID] = endTime
	mutex2.Unlock()
}
func GetAddFriendEndTime(planID string) time.Time {
	mutex2.Lock()
	v := addFriendEndTime[planID]
	mutex2.Unlock()
	return v
}


var mutex sync.Mutex
var subcribeClient = make(map[string]string,0)
func SetSubcribeClient(k,v string)  {
	mutex.Lock()
	subcribeClient[k] = v
	mutex.Unlock()
}
func GetSubcribeClient(k string) string {
	mutex.Lock()
	v := subcribeClient[k]
	mutex.Unlock()
	return v
}

type MUserData struct {
	Phone           string
	EncryptUserName string
	UserTicket      string
	Scene      int
}

func init() {
	m, err := models.NewAddFriendPlan()
	if err != nil {
		return
	}
	d := m.GetCollection()
	d.AddFieldToFilter("state", "lt", 2) //<2
	d.AddOrder("id desc")
	d.Load()
	items := d.GetItems()
	for i := range items {
		//当前时间在结束时间之前,则可重启
		endT,_ := time.Parse("2006-01-02 15:04:05",time.Now().Format("2006-01-02") + " " + items[i].GetString("end_time") + ":00")
		nowTime,_ := time.Parse("2006-01-02 15:04:05",time.Now().Format("2006-01-02 15:04:05"))

		//在结束之前
		if nowTime.Before(endT) {
			go RunAddFriend(1,items[i])
		}
	}
}

//加人任务
func (t Task) AddFriendTask() {
	//TODO	用MQ
	//min := cast.ToString(time.Now().Minute() + 1)
	//hour := cast.ToString(time.Now().Hour())

	spec := "0 1 0 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {
		m, err := models.NewAddFriendPlan()
		if err != nil {
			return
		}
		d := m.GetCollection()
		d.AddFieldToFilter("state", "lt", 2) //<2
		d.AddOrder("id desc")
		d.Load()
		items := d.GetItems()
		for i := range items {
			go RunAddFriend(0,items[i])
		}
	})
	c.Start()
	select {}
}

//auto 0 自动	1 重启自动	2 手动
func RunAddFriend(auto int,item *db.Item) {
	if checkIsStop(item.GetId()) {
		log.Println("任务已手动取消")
		return
	}

	item.SetData("state", 1)
	err := item.Save()
	if err != nil {
		log.Println("AddFriendPlan Save Error", err)
	}

	id := item.GetString("id")
	userID := item.GetString("user_id")
	customerID := item.GetString("customer_id")
	startTime := item.GetString("start_time")
	endTime := item.GetString("end_time")
	verifyMessages := item.GetString("verify_messages")
	runType := item.GetInt("run_type")
	wechatGroupIds := item.GetString("wechat_group_ids")
	dataGroupIds := item.GetString("data_group_ids")
	addRound := item.GetInt("add_round")                  //轮数
	addCount := item.GetInt("add_count")                  //每轮加人数
	addPhoneInterval := item.GetInt("add_phone_interval") //每轮加手机号间隔

	SetAddFriendEndTime(id,cast.ToTime(time.Now().Format("2006-01-02") + " " + endTime + ":00"))

	fmt.Println("加好友任务: ", item.GetString("name"), startTime)
	if startTime == "" {
		startTime = "8:00"
	}

	min := startTime[strings.Index(startTime, ":")+1:]
	hour := startTime[:strings.Index(startTime, ":")]
	if min == "00" {
		min = "0"
	}

	aleryHour := ""
	aleryMin := ""
	//auto 0 自动	1 重启自动	2 手动
	if auto == 0 {
		aleryHour = cast.ToString(cast.ToInt(hour) - 1)
	}else {
		nowTime := time.Now().Add(time.Minute * 2)
		aleryHour = nowTime.Format("15")
		aleryMin = nowTime.Format("04")
	}

	spec := "0 " + aleryMin + " " + aleryHour + " * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {

		//获取登陆了的微信号
		wechatArr := GetLoginedWechats(wechatGroupIds)

		if len(wechatArr) < 1 {
			log.Println("无登录了的微信号,无法继续进行加人")
			return
		}

		//检查是否订阅了消息
		for i := range wechatArr {
			if GetSubcribeClient(wechatArr[i]) == "" {
				Subcribe(wechatArr[i], userID)
			}
		}

		//所有的数据
		importFileIds := strings.Split(dataGroupIds, ",")

		//检测加人计划表状态
		if len(importFileIds) > 0 {
			log.Println("检测加人计划表状态")
			//6.完成了,修改加人计划表状态
			//phoneV1v2, _ := models.NewPhoneV1v2()
			//phoneV1v2s := phoneV1v2.GetCollection()
			//phoneV1v2s.AddFieldToFilter("state", "eq", "3")
			//phoneV1v2s.AddFieldToFilter("add_friend_plan_id", "eq", id)
			//returnCount := phoneV1v2s.GetSize()
			//importData, _ := models.NewImportData()
			//importDatas2 := importData.GetCollection()
			//importDatas2.AddFieldToFilter("import_file_id", "in", strings.Join(importFileIds, "','"))
			//importDatas2.AddFieldToFilter("state", "eq", 0)
			//size := importDatas2.GetSize()

			var addFriendLogSize int64 = 0
			addFriendLog,err := models.NewAddFriendLog()
			if err == nil {
				addFriendLogs := addFriendLog.GetCollection()
				addFriendLogs.AddFieldToFilter("add_friend_plan_id","eq",id)
				addFriendLogSize = addFriendLogs.GetSize()
			}

			var importDataSize int64 = 0
			importData,err := models.NewImportData()
			if err == nil {
				importDatas2 := importData.GetCollection()
				importDatas2.AddFieldToFilter("import_file_id", "in", strings.Join(importFileIds, "','"))
				importDataSize = importDatas2.GetSize()
			}

			if addFriendLogSize != 0 && importDataSize == 0 && addFriendLogSize == importDataSize{
				addFriendPlan, _ := models.NewAddFriendPlan()
				log.Println("id: ", id)
				addFriendPlan.SetId(cast.ToInt64(id))
				addFriendPlan.SetData("state", 2)
				if err := addFriendPlan.Save(); err != nil {
					log.Println("addFriendPlan Save Error: ", err)
				}
			}
		}

		//已加过的手机号
		hasAddFriends := GetHasAddFriends(userID, wechatArr)

		allAddCount := addRound * addCount

		//执行状态(暂停0/执行中1/完成2/取消3)
		//还需上传循环次数
		needLoopWechats := getNeedLoopWechats(allAddCount, wechatArr)
		fmt.Println("还要同步机器人及次数: ", needLoopWechats)
		if len(needLoopWechats) > 0 {
			//获取加人数据并上传
			getCanAddPhones(userID, id, allAddCount, needLoopWechats, importFileIds, hasAddFriends)
			needLoopWechats = []string{}
		}

		if len(needLoopWechats) == 0 {

			sTime, _ := time.Parse("2006-01-02 15:04:05", time.Now().Format("2006-01-02")+" "+startTime+":00")
			nowTime, _ := time.Parse("2006-01-02 15:04:05", time.Now().Format("2006-01-02 15:04:05"))
			addTime := 0
			//执行时间在现在时间之后
			if sTime.After(nowTime) {
				fmt.Println("sTime: ", sTime, "time.Now(): ", nowTime)
				addTime = utils.GetMinCount(time.Now().Format("15:04"), startTime)
			}

			fmt.Println(addTime, "分钟后执行加人")
			time.AfterFunc(time.Minute*cast.ToDuration(addTime), func() {
				toReadyAddfriend(wechatArr, importFileIds, hasAddFriends, runType, allAddCount, addCount, addPhoneInterval, userID, id, customerID, verifyMessages)
			})

			//加人
			//mins := 30
			//if isAuto {
			//	mins = 60
			//}
			//time.AfterFunc(time.Minute * cast.ToDuration(mins), func() {
			//	toReadyAddfriend(wechatArr,importFileIds,hasAddFriends,runType,allAddCount,addCount,addPhoneInterval,userID,id, customerID,verifyMessages)
			//})
		}
	})
	c.Start()

	go autoStop(c,endTime)

	select {}
}

func autoStop(c *cron.Cron, endTime string) {
	min := endTime[strings.Index(endTime, ":")+1:]
	hour := endTime[:strings.Index(endTime, ":")]
	spec := "0 " + min + " " + hour + " * * ?" // 分 时 日 月 星期
	c2 := cron.New()
	_ = c2.AddFunc(spec, func() {
		c.Stop()
	})
	c2.Start()
	go func() {
		time.AfterFunc(time.Hour * 23, func() {
			c2.Stop()
		})
	}()
	select {}
}

func toReadyAddfriend(wechatArr,importFileIds,hasAddFriends []string,runType,allAddCount,addCount,addPhoneInterval int,userID,id, customerID,verifyMessages string) {
	nowTime,_ := time.Parse("2006-01-02 15:04:05",time.Now().Format("2006-01-02 15:04:05"))
	if nowTime.After(GetAddFriendEndTime(id)) {
		log.Println("任务已取消")
		return
	}


	//nowStr := time.Now().Format("2006-01-02")
	//获取回调V1V2表数据
	phoneV1v2,err := models.NewPhoneV1v2()
	if err != nil {
		return
	}
	phoneV1v2s := phoneV1v2.GetCollection()
	phoneV1v2s.AddFieldToFilter("state","eq",3)
	phoneV1v2s.AddFieldToFilter("wechat_id","in",strings.Join(wechatArr,"','"))
	if len(hasAddFriends) > 0 {
		phoneV1v2s.AddFieldToFilter("add_phone","nin",strings.Join(hasAddFriends,"','"))
	}
	phoneV1v2s.AddOrder("create_date")
	phoneV1v2s.Load()

	//从回调数据中取回调了的
	finalMfriendMaps := make(map[string][]string)
	//重复的过滤
	addPhoneCountMap := make(map[string]int)
	phoneV1v2s.Each(func(item *db.Item) {
		addPhone := item.GetString("add_phone")
		wechatID := item.GetString("wechat_id")

		if _,ok := addPhoneCountMap[addPhone];!ok {
			addPhoneCountMap[addPhone] = 1
		}else {
			addPhoneCountMap[addPhone] = addPhoneCountMap[addPhone] + 1
		}

		if _,ok := finalMfriendMaps[wechatID];!ok {
			finalMfriendMaps[wechatID] = []string{addPhone}
		}else {
			//过滤重复
			if addPhoneCountMap[addPhone]  == 1{
				//过滤已加
				finalMfriendMaps[wechatID] = append(finalMfriendMaps[wechatID], addPhone)
			}
		}
	})
	log.Println("addPhoneCountMap: ",addPhoneCountMap)
	log.Println("上传完通讯录后得到的数据: ",finalMfriendMaps)

	finalMaps := make(map[string][]string)
	finalmUserDataMaps := make(map[string][]MUserData)
	for wechatID, phones := range finalMfriendMaps {

		//TODO	修改allAddCount为本次任务今天还需加多少人
		hasAddCount := getTodayHasAddFriendCount(id,wechatID)
		needAddCount := allAddCount - hasAddCount

		var finalAddPhones []string
		var finalmUserDatas []MUserData
		//获取通讯录联系人
		mUserDatas := getimfriends(runType,allAddCount,userID,wechatID,phones)
		for i := range mUserDatas {

			log.Println(wechatID,"还需加",needAddCount,"人")
			if len(finalAddPhones) == needAddCount {
				break
			}else {
				finalAddPhones = append(finalAddPhones, mUserDatas[i].Phone)
				finalmUserDatas = append(finalmUserDatas, mUserDatas[i])
			}

		}
		finalMaps[wechatID] = finalAddPhones
		finalmUserDataMaps[wechatID] = finalmUserDatas
	}


	//fmt.Println("最终加人数据: ",finalMaps)
	//fmt.Println()
	//fmt.Println()
	//fmt.Println("最终加人数据V1V2: ",finalmUserDataMaps)

	var rountArrsStrArr []string //总计划记录
	for wechatID, phones := range finalMaps {
		//切分手机号数组,根据每轮确定轮数获取每轮加人数
		//if addCount==5 phones== ["12","23","34","45"] return [["12","23","34","45"]]
		rountArrs := GetPhonesArr(addCount, phones) //	len(rountArrs)为轮数	内容为每轮加的人
		fmt.Println(phones,",rountArrs: ",rountArrs)
		for i := range rountArrs {
			rountArrsStr := strings.Join(rountArrs[i], ",")
			//记录数据
			rountArrsStrArr = append(rountArrsStrArr, rountArrsStr)
		}

		dealWithData(finalmUserDataMaps,rountArrs,wechatID, userID, id, customerID,verifyMessages, importFileIds, addPhoneInterval)
	}
}

func getTodayHasAddFriendCount(id,wechatID string) int {
	nowStr := time.Now().Format("2006-01-02")
	addFriendLog,err := models.NewAddFriendLog()
	if err != nil {
		return 0
	}
	addFriendLogs := addFriendLog.GetCollection()
	addFriendLogs.AddFieldToFilter("wechat_id","eq",wechatID)
	addFriendLogs.AddFieldToFilter("create_date","gteq",nowStr + " 00:00:00")
	addFriendLogs.AddFieldToFilter("create_date","lteq",nowStr + " 23:59:59")
	addFriendLogs.AddFieldToFilter("add_friend_plan_id","eq",id)
	return cast.ToInt(addFriendLogs.GetSize())
}

//获取还要循环上传通讯录多少次
func getNeedLoopWechats(allAddCount int,wechatArr []string) []string {
	needLoopWechats := make([]string,0)

	phoneV1v2,err := models.NewPhoneV1v2()
	if err != nil {
		return needLoopWechats
	}

	phoneV1v2s := phoneV1v2.GetCollection()
	phoneV1v2s.AddFieldToSelect("m.wechat_id", "")
	phoneV1v2s.AddFieldToSelect("{count(m.id)} as pcount", "")
	phoneV1v2s.AddFieldToFilter("m.state","eq",3)
	phoneV1v2s.AddFieldToFilter("m.wechat_id","in",strings.Join(wechatArr,"','"))
	phoneV1v2s.AddGroup("m.wechat_id")
	phoneV1v2s.Load()
	phoneV1v2Items := phoneV1v2s.GetItems()
	for i := range phoneV1v2Items {
		wechatID := phoneV1v2Items[i].GetString("wechat_id")
		count := phoneV1v2Items[i].GetInt("pcount")
		if count >= allAddCount * 2 {
			continue
		}
		needLoopWechats = append(needLoopWechats, wechatID)
	}

	return needLoopWechats
}

func getCanAddPhones(userID,id string,allAddCount int,needLoopWechats []string,importFileIds,hasAddFriends []string) {

	importData, _ := models.NewImportData()
	importDatas := importData.GetCollection()
	//importDatas.AddFieldToSelect("wechat_id", "wechat_id")
	importDatas.AddFieldToFilter("import_file_id", "in", strings.Join(importFileIds, "','"))
	importDatas.AddFieldToFilter("state", "eq", 0)
	importDatas.AddFieldToFilter("wechat_id", "nin", strings.Join(hasAddFriends, "','"))
	importDatas.AddOrder("reliable")
	importDatas.Load()
	importDatasLens := len(importDatas.GetItems())

	canloopCount := importDatasLens / (allAddCount)
	moreCount := importDatasLens % (allAddCount)
	if moreCount > 0 {
		canloopCount ++
	}

	//获取总数据
	var importDataPhones []string
	importDatas.Each(func(item *db.Item) {
		importDataPhones = append(importDataPhones, item.GetString("wechat_id"))
	})

	//上传通讯录,回调
	loopUploadmcontact(allAddCount,canloopCount, 0, 0,needLoopWechats,importFileIds,importDataPhones,hasAddFriends,userID,id)
	return
}

func GetHasAddFriends(userID string,wechatArr []string) []string {
	var hasAddFriends []string
	addFriendPlan,_ := models.NewAddFriendPlan()
	addFriendPlans := addFriendPlan.GetCollection()
	addFriendPlans.AddFieldToFilter("user_id","eq",userID)
	addFriendPlans.Load()

	addFriendPlans.Each(func(item *db.Item) {
		addFriendLog,_ := models.NewAddFriendLog()
		addFriendLogs := addFriendLog.GetCollection()
		addFriendLogs.AddFieldToFilter("wechat_id","in",strings.Join(wechatArr,"','"))
		addFriendLogs.AddFieldToFilter("add_friend_plan_id","eq",item.GetId())
		addFriendLogs.Load()
		addFriendLogs.Each(func(i *db.Item) {
			hasAddFriends = append(hasAddFriends, i.GetString("add_phone"))
		})
	})
	return hasAddFriends
}

func loopUploadmcontact(allAddCount,canloopCount,curPage, loopCount int, needLoopWechats,importFileIds,importDataPhones,hasAddFriends []string,userID,id string) {

	nowTime,_ := time.Parse("2006-01-02 15:04:05",time.Now().Format("2006-01-02 15:04:05"))
	if nowTime.After(GetAddFriendEndTime(id)) {
		log.Println("任务已取消")
		return
	}

	loopCount ++

	//微信号上传通讯录,等回调
	for index := range needLoopWechats {

		wechatID := needLoopWechats[index]
		curPage ++

		fmt.Println("loopCount: ",loopCount,"index: ",index,"curPage: ",curPage)
		addPhones := GetImportDatas(importDataPhones,curPage, allAddCount)
		fmt.Println("loopCount addPhones: ",addPhones)

		if len(addPhones) == 0 {
			return
		}

		//上传通讯录好友
		err := Uploadmcontact(addPhones, wechatID, userID)
		if err != nil {
			log.Println("上传通讯录好友失败")
			continue
		}else {
			for i := range addPhones {
				phoneV1v2,err := models.NewPhoneV1v2()
				if err != nil {
					return
				}

				//添加导v1v2表
				phoneV1v2.SetData("wechat_id",wechatID)
				phoneV1v2.SetData("add_friend_plan_id",id)
				phoneV1v2.SetData("add_phone",addPhones[i])
				phoneV1v2.SetData("add_phone_md5",utils.GetMD5String(addPhones[i]))
				if err := phoneV1v2.Save();err != nil {
					log.Println("phoneV1v2 save error: ",err)
					return
				}


			}
			//修改数据使用状态
			flag := UpdateDataState(importFileIds, addPhones)
			if !flag {
				log.Println("修改数据使用状态失败")
			}
		}
	}

	time.Sleep(time.Minute * FinalLoopMin)

	//如果循环次数达到最高次数,结束
	if loopCount >= canloopCount {
		log.Println("达到最高循环次数,结束循环")
		return
	}

	//如果循环次数达到10次任然没有回调,结束
	if loopCount > FinalLoopCount {
		return
	}

	//需要再上传通讯录的
	needAgainLoopWechats := getNeedLoopWechats(allAddCount, needLoopWechats)

	if len(needAgainLoopWechats) == 0 {
		return
	}

	loopUploadmcontact(allAddCount,canloopCount,curPage, loopCount, needAgainLoopWechats,importFileIds,importDataPhones,hasAddFriends,userID,id)
}


func getimfriends(runType,allAddCount int,userID,wechatID string, phones []string) (mUserDatas []MUserData) {
	//nowStr := time.Now().Format("2006-01-02")
	phoneV1v2,err := models.NewPhoneV1v2()
	if err != nil {
		return
	}
	phoneV1v2s := phoneV1v2.GetCollection()
	phoneV1v2s.AddFieldToFilter("state","eq",3)
	phoneV1v2s.AddFieldToFilter("wechat_id","eq",wechatID)
	if len(phones) > 0 {
		phoneV1v2s.AddFieldToFilter("add_phone","in",strings.Join(phones,"','"))
	}
	phoneV1v2s.AddOrder("create_date")
	phoneV1v2s.Load()

	if runType == 11 {
		phoneV1v2s.Each(func(item *db.Item) {
			phone := item.GetString("add_phone")
			v1 := item.GetString("v1")
			v2 := item.GetString("v2")
			var mUserData MUserData
			mUserData.Phone = phone
			mUserData.EncryptUserName = v1
			mUserData.UserTicket = v2
			mUserData.Scene = 11
			mUserDatas = append(mUserDatas, mUserData)
		})
		return
	}

	var canAddPhones []string
	phoneV1v2s.Each(func(item *db.Item) {
		canAddPhones = append(canAddPhones, item.GetString("add_phone"))
	})

	log.Println(wechatID," canAddPhones: ",canAddPhones)
	dataMap := make(map[string]interface{})
	dataMap["phone_list"] = strings.Join(canAddPhones, ",")
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wechatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/getimfriends", dataMap, heardMap)

	if err != nil {
		log.Println("getimfriends json.Unmarshal Error: ", err)
		//return
	}

	respMap := make(map[string]interface{})

	err = json.Unmarshal([]byte(resp), &respMap)
	if err != nil {
		log.Println("getimfriends json.Unmarshal Error: ", err)
		//return
	}

	if cast.ToString(respMap["Code"]) == "-1" {
		log.Println(cast.ToString(respMap["Msg"]))
		//return
	}

	b,err := json.Marshal(respMap["Data"])
	if err != nil {
		log.Println("getimfriends json.Marshal Error: ", err)
		//return
	}

	var resultUserDatas []MUserData
	err = json.Unmarshal(b,&resultUserDatas)
	if err != nil {
		log.Println("getimfriends json.Unmarshal Error: ", err)
	}

	resultUserDataMap := make(map[string]MUserData)
	//优先使用回调且
	for i := range resultUserDatas {
		for j := range canAddPhones {
			if resultUserDatas[i].Phone == canAddPhones[j] {
				var mUserData MUserData
				mUserData.Phone = resultUserDatas[i].Phone
				mUserData.EncryptUserName = resultUserDatas[i].EncryptUserName
				mUserData.UserTicket = resultUserDatas[i].UserTicket
				mUserData.Scene = 13
				mUserDatas = append(mUserDatas, mUserData)
			}
		}
		resultUserDataMap[resultUserDatas[i].Phone] = resultUserDatas[i]
	}


	//再添加回调但getimfriends没有V1V2
	phoneV1v2Items := phoneV1v2s.GetItems()
	for e := range phoneV1v2Items {
		phone := phoneV1v2Items[e].GetString("add_phone")
		v1 := phoneV1v2Items[e].GetString("v1")
		v2 := phoneV1v2Items[e].GetString("v2")
		if _,ok := resultUserDataMap[phone];!ok {
			var mUserData MUserData
			mUserData.Phone = phone
			mUserData.EncryptUserName = v1
			mUserData.UserTicket = v2
			mUserData.Scene = 10
			mUserDatas = append(mUserDatas, mUserData)
		}
	}

	log.Println("mUserDatas: ",mUserDatas)
	return
}

//是否已停止
func checkIsStop(id int) bool {
	m, _ := models.NewAddFriendPlan()
	m.Load(cast.ToInt64(id))
	if m.GetString("state") == "3" {
		return true
	}
	return false
}

func dealWithData(finalmUserDataMaps map[string][]MUserData,rountArrs [][]string,wechatID, userID, id, customerID,verifyMessages string, importFileIds []string, addPhoneInterval int) {
	if checkIsStop(cast.ToInt(id)) {
		log.Println("任务已手动取消")
		return
	}
	go func() {
		for i := range rountArrs {
			nowTime,_ := time.Parse("2006-01-02 15:04:05",time.Now().Format("2006-01-02 15:04:05"))
			endTime := GetAddFriendEndTime(id)
			if nowTime.After(endTime) {
				log.Println("任务已自动结束")
			}
			addPhonesStr := strings.Join(rountArrs[i], ",")
			//加人
			go toAddFriend(finalmUserDataMaps,wechatID,userID, id, customerID, addPhonesStr,verifyMessages, importFileIds)
			time.Sleep(time.Minute * cast.ToDuration(addPhoneInterval))
		}
	}()
}

//停止整个加人任务
func StopTask(planID string) {
	SetAddFriendEndTime(planID,cast.ToTime(time.Now().Format("2006-01-02 15:04:05")))
}

//切分手机号
func GetPhonesArr(addCount int, phones []string) [][]string {
	//遍历次数
	arrCount := len(phones) / addCount
	moreCount := len(phones) % addCount
	if moreCount > 0 {
		arrCount ++
	}

	var resultArrs [][]string
	//循环一次
	if arrCount == 1 {
		resultArrs = append(resultArrs, phones)
	} else {
		strArr222 := make([]string, 0)
		for i := range phones {
			strArr222 = append(strArr222, phones[i])
			if len(strArr222) == addCount {
				fmt.Println(strArr222)
				resultArrs = append(resultArrs, strArr222)
				strArr222 = make([]string, 0)
			} else {
				if i == len(phones)-1 {
					fmt.Println(strArr222)
					resultArrs = append(resultArrs, strArr222)
				}
			}
		}
	}
	return resultArrs
}

func toAddFriend(finalmUserDataMaps map[string][]MUserData,wechatID,userID, id, customerID, addPhonesStr,verifyMessages string, importFileIds []string ) {
	addPhones := strings.Split(addPhonesStr, ",")
	nowTime,_ := time.Parse("2006-01-02 15:04:05",time.Now().Format("2006-01-02 15:04:05"))
	if nowTime.After(GetAddFriendEndTime(id)) {
		log.Println("任务已取消")
		return
	}


	mUserDatas := finalmUserDataMaps[wechatID]

	if len(mUserDatas) == 0 {
		log.Println(wechatID,"没有获取到V1V2数据!")
		return
	}

	var finalMUserDatas []MUserData
	for i := range addPhones {
		for j := range mUserDatas {
			if addPhones[i] == mUserDatas[j].Phone {
				finalMUserDatas = append(finalMUserDatas, mUserDatas[j])
			}
		}
	}

	b,err := json.Marshal(finalMUserDatas)
	if err != nil {
		log.Println("解析V1V2数据失败! mUserDatas json.Marshal error: ",err)
		return
	}
	imUserList := string(b)

	finalMUserDatasMap := make(map[string]MUserData)
	for i := range finalMUserDatas {
		finalMUserDatasMap[finalMUserDatas[i].Phone] = finalMUserDatas[i]
	}


	flag := UpdateV1V2State(wechatID, addPhones)

	if flag {
		//3.添加到通讯录
		//通过手机号加好友
		//[["17335870526","0",""]]
		resultDataArr,vfMsg, err := addFiendWithImcontact(addPhones, imUserList,verifyMessages,wechatID, userID)
		//4.添加加好友日志
		if err != nil {
			log.Println("通过手机号加好友失败")
			//状态(通过1/待通过2/失败3/无效4)
			for i := range addPhones {
				go SaveAddFriendLog(userID, wechatID, id, customerID, addPhones[i],vfMsg[addPhones[i]], err.Error(), 3,finalMUserDatasMap[addPhones[i]].Scene, false)
			}
		} else {

			var resultPhoneArr []string
			for j := range resultDataArr {
				resultPhoneArr = append(resultPhoneArr, resultDataArr[j][0])
			}
			//状态(通过1/待通过2/失败3/无效4)
			for i := range addPhones {
				//state := 4
				isOnewayFans := false
				msg := ""
				//有返回
				//if hasData(addPhones[i], resultPhoneArr) {
				//
				//}

				state := 2
				for j := range resultDataArr {
					if resultDataArr[j][0] == addPhones[i] {
						//返回不是0的有问题的
						if resultDataArr[j][1] != "0" {
							state = 3
						}else {
							friendWxID := GetFriendWxID(userID, wechatID, addPhones[i])
							if friendWxID != "" {
								if strings.Index(friendWxID, "@stranger") == -1 {
									isOnewayFans = true

									//发送消息
									go func() {
										arrs := GetRandMsgs(userID)
										for i := range arrs{
											arr := arrs[i]
											if arr[0] == "0" {
												go SendMessage(wechatID, friendWxID, userID, arr[1])
											}else {
												imgs := strings.Split(arr[1],",")
												for i := range imgs{
													go SendImgMessage(wechatID, friendWxID, userID, imgs[i])
												}
											}
										}
									}()
								}
							}
						}
						msg = resultDataArr[j][2]
					}
				}

				SaveAddFriendLog(userID, wechatID, id, customerID, addPhones[i],vfMsg[addPhones[i]], msg, state,finalMUserDatasMap[addPhones[i]].Scene, isOnewayFans)
			}
		}
	}else {
		log.Println("修改V1V2表状态失败")
	}


}

//上传通讯录好友
func Uploadmcontact(addPhones []string, wechatID, userID string) error {
	log.Println("上传通讯录好友: 手机: ", addPhones, "微信: ", wechatID, "用户: ", userID)
	dataMap := make(map[string]interface{})
	dataMap["phone_list"] = strings.Join(addPhones, ",")
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wechatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/uploadmcontact", dataMap, heardMap)

	if err != nil {
		log.Println("json.Unmarshal Error: ", err)
		return err
	}

	respMap := make(map[string]interface{})

	err = json.Unmarshal([]byte(resp), &respMap)
	if err != nil {
		log.Println("json.Unmarshal Error: ", err)
		return err
	}

	if cast.ToString(respMap["Code"]) == "-1" {
		log.Println(cast.ToString(respMap["Msg"]))
		return errors.New(cast.ToString(respMap["Msg"]))
	}
	return nil
}

func addFiendWithImcontact(phoneList []string,imUserList,verifyMessages, wechatID, userID string) ([][3]string,map[string]string, error) {
	var resultDataArr [][3]string
	dataMap := make(map[string]interface{})
	dataMap["phone_list"] = strings.Join(phoneList, ",")
	dataMap["im_user_list"] = imUserList
	//TODO	验证消息
	msg := GetMessage(phoneList,verifyMessages,wechatID)
	b2, err := json.Marshal(msg)
	if err != nil {
		log.Println("json.Marshal failed:", err)
	}
	dataMap["verify_content"] = string(b2)
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wechatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/addfiendwithimcontact", dataMap, heardMap)

	if err != nil {
		log.Println("account addfiendwithimcontact Error: ", err)
		return resultDataArr,msg, err
	}

	log.Println("加人: 手机: ", phoneList, "微信: ", wechatID,",imUserList: ",imUserList,",验证消息",string(b2), ",返回: ", resp)

	respMap := make(map[string]interface{})

	err = json.Unmarshal([]byte(resp), &respMap)
	if err != nil {
		log.Println("json.Unmarshal Error: ", err)
		return resultDataArr,msg, err
	}

	if cast.ToString(respMap["Code"]) == "-1" {
		return resultDataArr,msg, errors.New(cast.ToString(respMap["Msg"]))
	}

	if respMap["Data"] == nil {
		return resultDataArr,msg, errors.New("目标微信号被请求次数过多,请求被限制")
	}

	b3, err := json.Marshal(respMap["Data"])
	if err != nil {
		log.Println("resultDataMap json.Marshal Error: ", err)
		return resultDataArr,msg, err
	}
	err = json.Unmarshal(b3, &resultDataArr)
	if err != nil {
		log.Println("json.Unmarshal Error: ", err)
		return resultDataArr,msg, err
	}
	return resultDataArr,msg, nil
}

func GetWechatInfo(wechatID string) db.Item {
	wechat,_ := models.NewBindWechat()
	wechat.SetData("wechat_id",wechatID)
	wechat.Row()
	return wechat.Item
}

func SaveAddFriendLog(userID, wechatID, addFriendPlanID, customerID, addPhone,verifyMessages, msg string, state,scene int, isOnewayFans bool) {
	addFriendLog, _ := models.NewAddFriendLog()

	addFriendLogs := addFriendLog.GetCollection()
	addFriendLogs.AddFieldToFilter("wechat_id", "eq", wechatID)
	addFriendLogs.AddFieldToFilter("add_phone", "eq", addPhone)
	addFriendLogs.Load()

	if len(addFriendLogs.GetItems()) > 0 {
		return
	}

	addFriendLog.SetData("wechat_id", wechatID)
	addFriendLog.SetData("add_friend_plan_id", cast.ToUint(addFriendPlanID))
	addFriendLog.SetData("customer_id", cast.ToUint(customerID))
	addFriendLog.SetData("add_phone", addPhone)
	addFriendLog.SetData("state", state) //状态(通过1/待通过2/失败3/无效4)
	addFriendLog.SetData("scene", scene)
	addFriendLog.SetData("msg", msg)
	addFriendLog.SetData("verify_messages", verifyMessages)
	addFriendLog.SetData("is_oneway_fans", isOnewayFans)
	err := addFriendLog.Save()
	if err != nil {
		log.Println("SaveAddFriendLog Error: ", err)
	}

	//if state == 2 {
	//	go subcribe(wechatID,userID)
	//	//time.AfterFunc(time.Minute*3, func() {
	//	//	go CheckPassed(userID, &addFriendLog.Item)
	//	//})
	//}
}

func GetImportDatas(importDataWechatIDs []string,curPage, addCount int) []string {
	if curPage < 1 {
		curPage = 1
	}
	fmt.Println("GetImportDatas---", curPage, addCount)
	index := (curPage-1) * addCount
	if index > len(importDataWechatIDs) {
		return []string{}
	}
	var importDataArr []string
	for i := range importDataWechatIDs {
		if index <= i {
			if len(importDataArr) == addCount {
				break
			}
			importDataArr = append(importDataArr, importDataWechatIDs[i])
			index ++
		}
	}

	return importDataArr
}

//获取所有登陆了的微信号
func GetLoginedWechats(wechatGroupIds string) []string {
	ids := strings.Split(wechatGroupIds, ",")
	wechat,err := models.NewBindWechat()
	if err != nil {
		log.Println("BindWechat结构体初始化异常")
		return []string{}
	}
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("group_id", "in", strings.Join(ids, "','"))
	wechats.Load()

	userID := ""
	var wechatArr []string
	wechats.Each(func(item *db.Item) {
		userID = item.GetString("user_id")
		wechatArr = append(wechatArr, item.GetString("wechat_id"))
	})

	//获取登录了的
	dataMap := make(map[string]interface{})
	dataMap["wxid_list"] = strings.Join(wechatArr, ",")
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, "")
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/batchcheckloginstatus", dataMap, heardMap)
	if err != nil {
		log.Println("batchcheckloginstatus error: ", err)
		return []string{}
	}

	fmt.Println("登录状态返回数据:", data)

	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(data), &maps)
	if err != nil {
		log.Println("batchcheckloginstatus json.Unmarshal Error: ", err)
		return []string{}
	}
	finalMap := make(map[string]int)
	b, err := json.Marshal(maps["Data"])
	if err != nil {
		log.Println("batchcheckloginstatus json.Marshal Error: ", err)
		return []string{}
	}
	err = json.Unmarshal(b, &finalMap)
	if err != nil {
		log.Println("batchcheckloginstatus json.Unmarshal Error: ", err)
		return []string{}
	}
	var finalWechats []string
	for k, v := range finalMap {
		if v == 12007 {
			finalWechats = append(finalWechats, k)
		}
	}

	return finalWechats
}

func GetMessage(phoneList []string,verifyMessages,wechatID string) map[string]string {

	result := make(map[string]string)
	//["43","46","你好"]
	var vems []string
	err := json.Unmarshal([]byte(verifyMessages), &vems)
	if err != nil {
		log.Println("GetMessage json.Unmarshal error",err)
		return result
	}

	importData,_ := models.NewImportData()
	importDatas := importData.GetCollection()
	importDatas.AddFieldToFilter("wechat_id","in",strings.Join(phoneList,"','"))
	importDatas.Load()

	maps := make(map[string]map[string]string)
	importDatas.Each(func(item *db.Item) {
		var otherDataMap map[string]string
		otherDataStr := item.GetString("other_data")
		err := json.Unmarshal([]byte(otherDataStr), &otherDataMap)
		if err != nil {
			log.Println(err)
			return
		}
		otherDataMap["name"] = item.GetString("name")
		otherDataMap["wechat_id"] = item.GetString("wechat_id")
		maps[item.GetString("wechat_id")] = otherDataMap
	})

	if len(vems) < 1 {
		wechatItem := GetWechatInfo(wechatID)
		for i := range phoneList {
			messsage := "你好"
			if wechatItem.GetString("nickname") != "" {
				messsage += ",我是" + wechatItem.GetString("nickname")
			}
			result[phoneList[i]] = messsage
		}
		return result
	}

	randData := 0
	if len(vems) > 0 {
		randData = rand.Intn(len(vems))
	}
	var strArr []string
	if cast.ToInt(vems[randData]) != 0 {
		message, _ := models.NewVerifyMessage()
		messages := message.GetCollection()
		messages.AddFieldToFilter("verify_message_group_id", "eq", cast.ToInt(vems[randData]))
		messages.Load()
		messages.Each(func(item2 *db.Item) {
			//TODO	随机还是所有拼起来
			strArr = append(strArr, item2.GetString("content"))
		})
	}else {
		strArr = append(strArr, vems[randData])
	}

	for i := range phoneList {
		var strs2 string

		randData := 0
		if len(strArr) > 0 {
			randData = rands.Intn(len(strArr))
		}


		//["你好","["2","1"]"]
		str := ""
		if len(strArr) > 0 {
			str = strArr[randData]
		}
		if strings.Index(str,"[") == -1 {
			strs2 += str
		} else {
			//["1","2","你好"]
			var strs []string
			err := json.Unmarshal([]byte(str), &strs)
			if err != nil {
				log.Println("strs json.Unmarshal error: ",err)
				continue
			}
			for k := range strs{
				if cast.ToInt(strs[k]) != 0 {
					otherData := maps[phoneList[i]]
					if cast.ToInt(strs[k]) == 1 {
						//微信号/手机号
						strs2 += otherData["wechat_id"]
					}else if cast.ToInt(strs[k]) == 2 {
						//姓名
						strs2 += otherData["name"]
					}else {
						moveMessageType, _ := models.NewMoveMessageType()
						moveMessageType.Load(cast.ToInt64(strs[k]))
						name := moveMessageType.GetString("name")
						strs2 += otherData[name] + ","
					}
				}else {
					strs2 += strs[k]
				}
			}
		}

		fmt.Println("动态验证消息获取: ", strs2)
		result[phoneList[i]] = strs2
	}

	if len(result) < 1 {
		wechatItem := GetWechatInfo(wechatID)
		for i := range phoneList {
			messsage := "你好"
			if wechatItem.GetString("nickname") != "" {
				messsage += ",我是" + wechatItem.GetString("nickname")
			}
			result[phoneList[i]] = messsage
		}
	}
	return result
}

func UpdateDataState(importFileIds []string, addPhones []string) bool {
	log.Println("---修改数据表手机状态----", importFileIds, "-----", addPhones)
	importData, _ := models.NewImportData()
	importDatas := importData.GetCollection()
	importDatas.AddFieldToFilter("import_file_id", "in", strings.Join(importFileIds, "','"))
	importDatas.AddFieldToFilter("wechat_id", "in", strings.Join(addPhones, "','"))
	importDatas.Load()
	importDatas.Each(func(item *db.Item) {
		item.SetData("state", 1)
		err := item.Save()
		if err != nil {
			log.Println("Save ImportData Error :", err)
			return
		}
	})

	return true
}

func UpdateV1V2State(wechatID string, addPhones []string) bool {
	log.Println("---修改V1V2表请求状态----", wechatID, "-----", addPhones)

	phoneV1v2,err := models.NewPhoneV1v2()
	if err != nil {
		return false
	}
	phoneV1v2s := phoneV1v2.GetCollection()
	phoneV1v2s.AddFieldToFilter("state","eq",3)
	phoneV1v2s.AddFieldToFilter("wechat_id","eq",wechatID)
	phoneV1v2s.AddFieldToFilter("add_phone","in",strings.Join(addPhones,"','"))
	phoneV1v2s.Load()

	phoneV1v2s.Each(func(item *db.Item) {
		item.SetData("state", 4)
		err := item.Save()
		if err != nil {
			log.Println("Save ImportData Error :", err)
			return
		}
	})

	return true
}

//分配微信号目标手机号
func GetWechatPhonesMap(wechatArr, importDataArr []string) map[string][]string {

	maps := make(map[string][]string)
	if len(importDataArr) == 0 || len(wechatArr) == 0 {
		return maps
	}
	//遍历次数
	arrCount := len(importDataArr) / len(wechatArr)
	moreCount := len(importDataArr) % len(wechatArr)
	if moreCount > 0 {
		arrCount ++
	}

	//循环一次(微信号多于数据)
	if arrCount == 1 {
		for i := range wechatArr {
			if i < len(importDataArr) {
				maps[wechatArr[i]] = []string{importDataArr[i]}
			}
		}
	} else {
		//循环多次(微信号少于数据)
		strArr := make([][]string, 0)
		strArr222 := make([]string, 0)
		for i := range importDataArr {
			strArr222 = append(strArr222, importDataArr[i])
			if len(strArr222) == len(wechatArr) {
				//fmt.Println(strArr222)
				strArr = append(strArr, strArr222)
				strArr222 = make([]string, 0)
			} else {
				if i == len(importDataArr)-1 {
					//fmt.Println(strArr222)
					strArr = append(strArr, strArr222)
				}
			}
		}
		//fmt.Println(strArr)//[[微信1 微信2 微信3] [微信4 微信5]]

		for i := range strArr {
			arr := strArr[i]
			for j := range arr {
				data := arr[j]
				weArr := maps[wechatArr[j]]
				weArr = append(weArr, data)
				maps[wechatArr[j]] = weArr
			}
		}
	}
	return maps
}

//订阅消息
func Subcribe(wechatID,userID string)  {
	SetSubcribeClient(wechatID,config.Sysconfig.LocalhostAddr + "/api/v1/account/check/friend/passed")

	dataMap := make(map[string]interface{})
	dataMap["url"] = config.Sysconfig.LocalhostAddr + "/api/v1/account/check/friend/passed"
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wechatID)
	_, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/message/subcribe", dataMap, heardMap)
	if err != nil {
		log.Println("message/subcribe error: ", err)
	}
}

func hasData(data string, dataArr []string) bool {
	for i := range dataArr {
		if dataArr[i] == data {
			return true
		}
	}
	return false
}
