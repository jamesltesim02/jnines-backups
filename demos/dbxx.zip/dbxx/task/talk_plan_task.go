/*
@Time : 2019/5/30 14:13 
@Author : Lukebryan
@File : talk_plan_task.go
@Software: GoLand
*/
package task

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"github.com/spf13/cast"
	"io/ioutil"
	"log"
	"math/rand"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

func (t Task) TalkPlanTask() {

	spec := "0 0 6,12,18 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {
		talkPlan, _ := models.NewTalkPlan()
		talkPlans := talkPlan.GetCollection()
		talkPlans.AddFieldToFilter("state", "lteq", 1)
		talkPlans.Load()
		items := talkPlans.GetItems()
		for i := range items{
			talkPlan, _ := models.NewTalkPlan()
			talkPlan.SetId(cast.ToInt64(items[i].GetId()))
			talkPlan.SetData("state", 1)
			err := talkPlan.Save()
			if err != nil {
				log.Println("talkPlan Save Error", err)
			}

			nowHour := time.Now().Format("15")
			endTime := ""
			if nowHour == "06" {
				endTime = items[i].GetString("morning_time")
				if endTime == "" || strings.Index(endTime,"-") == -1{
					continue
				}
			}else if nowHour == "12" {
				endTime = items[i].GetString("afternoon_time")
				if endTime == "" || strings.Index(endTime,"-") == -1{
					continue
				}
			}else {
				endTime = items[i].GetString("night_time")
				if endTime == "" || strings.Index(endTime,"-") == -1{
					continue
				}
			}

			endTimeStart := endTime[ : strings.Index(endTime,"-")]
			endTimeEnd := endTime[ strings.Index(endTime,"-") + 1: ]

			sTime, _ := time.Parse("2006-01-02 15:04:05", time.Now().Format("2006-01-02")+" "+endTimeStart+":00")
			nowTime, _ := time.Parse("2006-01-02 15:04:05", time.Now().Format("2006-01-02 15:04:05"))
			needAddMin := 0
			//执行时间在现在时间之后
			if sTime.After(nowTime) {
				fmt.Println("endTimeStart: ", endTimeStart, "time.Now(): ", nowTime)
				needAddMin = utils.GetMinCount(time.Now().Format("15:04"),endTimeStart)
			}

			needMoreMin := utils.GetMinCount(endTimeStart,endTimeEnd)

			if needMoreMin <= 0 {
				needMoreMin = 10
			}
			fmt.Println("needMoreMin: ",needMoreMin)

			randData := rands.Intn(needMoreMin)

			fmt.Println("needAddMin: ",needAddMin,",randData: ",randData)
			waitTime := needAddMin + randData
			//聊天
			fmt.Println(waitTime,"分钟后互相聊天")
			go ToTalk(waitTime,items[i])

		}
	})
	c.Start()
	select {}
}

//TODO create into mongodb, not mysql
//添加聊天
func ToTalk(waitTime int,talkPlanItem *db.Item) {
	fmt.Println("聊天任务:", talkPlanItem.GetString("name")," 时间: ",waitTime,"分钟后")
	time.AfterFunc(time.Minute * (cast.ToDuration(waitTime)), func() {
		talkPlanID := talkPlanItem.GetString("id")
		userID := talkPlanItem.GetString("user_id")
		count := talkPlanItem.GetInt("count")
		talkInterval := talkPlanItem.GetInt("talk_interval")
		eachAddCount := talkPlanItem.GetInt("each_add_count")
		if count == 0 {
			count = 1
		}
		materialGroupID := talkPlanItem.GetString("talk_material_group_id")
		//1.获取微信组里登录了的微信
		loginedWechats := GetLoginedWechats(talkPlanItem.GetString("wechat_group_ids"))
		if len(loginedWechats) < 2 {
			log.Println("在线微信号少于2个,无法继续聊天",loginedWechats)
			return
		}

		//TODO 设置自动通过
		setAutoPass(loginedWechats,userID)

		//切割后的微信
		wechatArrs := splitData(loginedWechats,eachAddCount)

		fmt.Println("wechatArrs: ",wechatArrs)

		//素材数据
		talkMaterial, _ := models.NewTalkMaterial()
		talkMaterials := talkMaterial.GetCollection()
		talkMaterials.AddFieldToFilter("talk_material_group_id", "eq", materialGroupID)
		talkMaterials.Load()
		talkMaterialItems := talkMaterials.GetItems()

		if len(talkMaterialItems) < 1 {
			log.Println("缺少对话素材,无法继续聊天")
			return
		}

		for i := range wechatArrs {
			wechatArr := wechatArrs[i]
			go dealWithTalk(wechatArr,talkInterval,count,userID,talkPlanID,talkMaterialItems)

		}

	})
}

func setAutoPass(loginedWechats []string,userID string) {
	for i := range loginedWechats {
		dataMap := make(map[string]interface{})
		heardMap := make(map[string]string)
		heardMap["Authorization"] = utils.GentToken(userID, loginedWechats[i])
		dataMap["active"] = 1
		utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/verifyfriendswitch", dataMap, heardMap)
	}
}
func dealWithTalk(wechatArr []string, talkInterval,count int, userID,talkPlanID string, talkMaterialItems []*db.Item) {
	//wxId := GetRandWxId(loginedWechats)
	//otherWxId := GetOtherRandWxId(wxId, loginedWechats)

	talkMap := make(map[string][]string)
	for i := range wechatArr {
		wxId := wechatArr[i]
		var otherWxIds []string
		for j := range wechatArr {
			otherWxId := wechatArr[j]
			if otherWxId != wxId {
				otherWxIds = append(otherWxIds, otherWxId)
			}
		}
		talkMap[wxId] = otherWxIds
	}

	fmt.Println("talkMap: ",talkMap)

	for wxId, otherWxIds := range talkMap {
		autoTalk(wxId,otherWxIds,talkInterval,count, userID,talkPlanID, talkMaterialItems)
	}


}

func autoTalk(wxId string, otherWxIds []string, talkInterval,count int, userID,talkPlanID string, talkMaterialItems []*db.Item) {
	go func() {
		for i := range otherWxIds {
			otherWxId := otherWxIds[i]
			//2.判断是不是好友,添加随机一好友
			isFriendFlag := isFriend(wxId, otherWxId, userID)
			if !isFriendFlag {
				log.Println(wxId,"和",otherWxId,"不是好友")
				addFriendFlag := addFriend(wxId, otherWxId, userID)
				if !addFriendFlag {
					log.Println("加好友失败,无法互相聊天")
					return
				}
			}

			//3.发消息
			for i := 0; i < count; i++ {
				randNum := 0
				if len(talkMaterialItems) > 1 {
					randNum = rands.Intn(len(talkMaterialItems))
				}

				content := talkMaterialItems[randNum].GetString("content")
				talkMaterialID := talkMaterialItems[randNum].GetString("id")
				sendFlag := SendMessage(wxId, otherWxId, userID, content)
				if !sendFlag {
					log.Println(wxId,"发消息失败")
					return
				}

				//4.保存到记录
				saveTalkItem(wxId, otherWxId, talkMaterialID, talkPlanID, content, "2", "")

				rn := rands.Intn(30)
				time.Sleep(time.Second * cast.ToDuration(5 + rn))

				//TODO 回复
				sendFlag = SendMessage(otherWxId, wxId, userID, getRandCount(1))
				if !sendFlag {
					log.Println(otherWxId,"回复消息失败")
					return
				}
				//go saveTalkItem(otherWxId, wxId, talkMaterialID, talkMaterialID, content, "2", "")
				fmt.Println(wxId,"给",otherWxId,"发消息第",cast.ToString(i + 1) + "轮聊天结束")

			}
			if talkInterval <= 0 {
				talkInterval = 10
			}
			rn := rands.Intn(talkInterval)
			time.Sleep(time.Second * cast.ToDuration(5 + rn))
		}
	}()
}

func splitData(items []string,count int) [][]string {
	arrs := make([][]string,0)

	arr := make([]string,0)
	for i := range items {
		arr = append(arr, items[i])
		if len(arr) == count {
			arrs = append(arrs, arr)
			arr = []string{}
		}
		if i == len(items) - 1 {
			arrs = append(arrs, arr)
		}
	}
	return arrs
}

//获取随机消息/回复
func getRandCount(types int) string {

	talkMaterial,_ := models.NewTalkMaterial()
	talkMaterials := talkMaterial.GetCollection()
	talkMaterials.AddFieldToFilter("types","eq",types)
	talkMaterials.Load()
	items := talkMaterials.GetItems()
	if len(items) < 1 {
		return "你好!"
	}
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	randNum := r.Intn(len(items))
	return items[randNum].GetString("content")
}

//保存聊天记录
func saveTalkItem(wxId, otherWxId, talkMaterialID, talkPlanID, content, state, msg string) {
	talkItem, err := models.NewTalkItem()
	if err != nil {
		log.Println(err)
		return
	}
	talkItem.SetData("from_wechat_id", wxId)
	talkItem.SetData("to_wechat_id", otherWxId)
	talkItem.SetData("talk_material_id", talkMaterialID)
	talkItem.SetData("talk_plan_id", talkPlanID)
	talkItem.SetData("content", content)
	talkItem.SetData("state", state)
	talkItem.SetData("msg", msg)
	err = talkItem.Save()
	if err != nil {
		log.Println("talkItem save error")
	}
}

//机器人之间是否是好友(仅限于机器人之间使用)
func isFriend(wxId, otherWxId, userID string) bool {
	sendFlag := SendMessage(wxId, otherWxId, userID, "你好!")
	if !sendFlag {
		log.Println("发消息失败,机器人之间不是好友")
		return false
	}
	return true
}

//获取除了本个微信的其他一个微信号
func GetOtherRandWxId(wxId string, loginedWechats []string) string {

	if len(loginedWechats) < 2 {
		return ""
	}

	r := rand.New(rand.NewSource(time.Now().UnixNano()))

	for {
		randNum := r.Intn(len(loginedWechats))
		if loginedWechats[randNum] != wxId {
			return loginedWechats[randNum]
		}
	}
}

//获取一个随机微信号
func GetRandWxId(loginedWechats []string) string {
	if len(loginedWechats) < 2 {
		return ""
	}
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	randNum := r.Intn(len(loginedWechats))
	return loginedWechats[randNum]
}

//发消息
func SendMessage(fromWxId, toWxID, userID, content string) bool {

	dataMap := make(map[string]interface{})
	dataMap["to_wxid"] = toWxID
	dataMap["content"] = content
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, fromWxId)
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/message/sendmessage", dataMap, heardMap)
	if err != nil {
		log.Println("sendmessage error: ", err)
		return false
	}
	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(data), &maps)
	if err != nil {
		log.Println("sendmessage json.Unmarshal Error: ", err)
		return false
	}

	if cast.ToString(maps["Code"]) == "-1" {
		return false
	}

	return true
}
//发图片消息
func SendImgMessage(fromWxId, toWxID, userID, imgPath string) bool {

	b, err := ioutil.ReadFile(config.Sysconfig.FileSavePath + "/" + imgPath)
	if err != nil {
		log.Println("ReadFile Error: ",err)
		return false
	}
	imgBase64 := base64.StdEncoding.EncodeToString(b)

	dataMap := make(map[string]interface{})
	dataMap["to_wxid"] = toWxID
	dataMap["image"] = imgBase64
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, fromWxId)
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/message/sendimage", dataMap, heardMap)
	if err != nil {
		log.Println("sendimage error: ", err)
		return false
	}
	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(data), &maps)
	if err != nil {
		log.Println("sendimage json.Unmarshal Error: ", err)
		return false
	}

	if cast.ToString(maps["Code"]) == "-1" {
		return false
	}

	return true
}

//加好友
func addFriend(wechatID, addWxId, userID string) bool {
	wechat, _ := models.NewBindWechat()
	wechat.SetData("wechat_id",addWxId)
	wechat.Row()
	phone := ""
	alias := ""
	if wechat.GetId() > 0 {
		phone = wechat.GetString("wechat_mobile")
		alias = wechat.GetString("wechat_alias")
	}

	if phone == "" && alias == "" {
		log.Println("手机号和微信号都为空")
		return false
	}

	dataMap := make(map[string]interface{})
	if phone != "" {
		dataMap["phone"] = phone
	} else {
		dataMap["alias"] = alias
	}
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wechatID)
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/addfriend", dataMap, heardMap)
	if err != nil {
		log.Println("addfriend error: ", err)
		return false
	}
	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(data), &maps)
	if err != nil {
		log.Println("addfriend json.Unmarshal Error: ", err)
		return false
	}

	if cast.ToString(maps["Code"]) == "-1" {
		return false
	}

	time.Sleep(time.Second * 30)
	return isFriend(wechatID, addWxId, userID)
}
