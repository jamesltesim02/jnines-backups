/*
@Time : 2019/6/24 14:07 
@Author : Lukebryan
@File : auto_get_apitoken_task.go
@Software: GoLand
*/
package task

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/kataras/iris/core/errors"
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"github.com/spf13/cast"
	"log"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

func init() {
	fmt.Println("开机自启刷新API Token")
	user,err := models.NewUser()
	if err != nil {
		log.Println("结构体初始化失败")
		return
	}
	users := user.GetCollection()
	users.Load()
	users.Each(func(userItem *db.Item) {
		userID := userItem.GetString("id")
		apiToken,err := encryptUserId(userID)
		if err != nil {
			log.Println("获取apiToken失败!需手动登录或下次登录")
			return
		}
		utils.ApiToken[userID] = apiToken
	})
}

/*
自动刷新API Token
 */
func (t Task) AutoGetApiTokenTask() {
	//每月1号15号凌晨1点
	spec := "0 0 1 1,15 * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {
		fmt.Println("自动刷新API Token任务")
		user,err := models.NewUser()
		if err != nil {
			log.Println("结构体初始化失败")
			return
		}
		users := user.GetCollection()
		users.Load()
		users.Each(func(userItem *db.Item) {
			userID := userItem.GetString("id")
			userName := userItem.GetString("user_name")
			apiToken,err := encryptUserId(userID)
			if err != nil {
				log.Println("用户",userName,"获取apiToken失败!需手动登录或等待下次1号或15号自动登录")
				return
			}
			utils.ApiToken[userID] = apiToken
		})

	})
	c.Start()
	select {}
}

func loginApi(userName,password string) (string,error) {
	dataMap := make(map[string]interface{})
	dataMap["user_name"] = userName
	dataMap["password"] = password
	heardMap := make(map[string]string)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/user/login", dataMap, heardMap)
	if err != nil {
		log.Println("api user login error: ", err)
		return "",err
	}
	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(resp), &maps)
	if err != nil {
		log.Println("api user login json.Unmarshal Error: ", err)
		return "",err
	}
	if cast.ToString(maps["Code"]) == "-1" {
		log.Println(cast.ToString(maps["Msg"]))
		return "",errors.New(cast.ToString(maps["Msg"]))
	}
	return cast.ToString(maps["Data"]),nil
}

func encryptUserId(userid string) (string, error) {
	hash := md5.New()
	hash.Write([]byte("private_key"))
	key := hash.Sum(nil)
	rel, err := AesEncrypt([]byte(userid), key)
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(rel), nil
}

func AesEncrypt(origData, key []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	blockSize := block.BlockSize()
	origData = PKCS7Padding(origData, blockSize)
	blockMode := cipher.NewCBCEncrypter(block, key[:blockSize])
	crypted := make([]byte, len(origData))
	blockMode.CryptBlocks(crypted, origData)
	return crypted, nil
}

func PKCS7Padding(ciphertext []byte, blockSize int) []byte {
	padding := blockSize - len(ciphertext)%blockSize
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(ciphertext, padtext...)
}