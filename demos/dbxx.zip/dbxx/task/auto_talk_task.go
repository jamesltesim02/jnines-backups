/*
@Time : 2019/6/24 14:07 
@Author : Lukebryan
@File : auto_talk_task.go
@Software: GoLand
*/
package task

import (
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"github.com/spf13/cast"
	"log"
	"math/rand"
	"time"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)


/*
自言自语聊天
 */
func (t Task) AutoTalkTask() {
	spec := "0 0 1 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {

		user,err := models.NewUser()
		if err != nil {
			log.Println("结构体初始化失败")
			return
		}
		users := user.GetCollection()
		users.Load()
		users.Each(func(userItem *db.Item) {

			userID := userItem.GetString("id")

			//群文件记录
			talkChatroom,err := models.NewTalkChatroom()
			if err != nil {
				log.Println("缺少表结构体")
				return
			}
			talkChatrooms := talkChatroom.GetCollection()
			talkChatrooms.AddFieldToFilter("user_id","eq",userID)
			talkChatrooms.AddFieldToFilter("state","eq",0)
			talkChatrooms.Load()

			talkChatrooms.Each(func(item *db.Item) {
				id := item.GetId()
				startTime := item.GetString("start_time")
				chatroomID := item.GetString("chatroom_id")

				wc,_ := models.NewWechatChatroom()
				wcs := wc.GetCollection()
				wcs.AddFieldToFilter("talk_chatroom_id","eq",id)
				wcs.Load()

				var inRoomWechatIDs []string
				wcMaps := make(map[string]string)
				wcs.Each(func(i *db.Item) {
					wxID := i.GetString("wechat_id")
					inRoomWechatIDs = append(inRoomWechatIDs, wxID)
					wcMaps[wxID] = chatroomID
				})
				waitTime := utils.GetMinCount(time.Now().Format("15:04"),startTime)
				fmt.Println("机器人群聊任务: ",cast.ToString(waitTime),"分钟后开始")
				AotoTalk(userID,inRoomWechatIDs,wcMaps,waitTime)
			})
		})



	})
	c.Start()
	select {}
}

func getChatroomWechats(id int) int {
	wechatChatroom,_ := models.NewWechatChatroom()
	wechatChatrooms := wechatChatroom.GetCollection()
	wechatChatrooms.AddFieldToFilter("talk_chatroom_id","eq",id)
	wechatChatrooms.Load()
	return len(wechatChatrooms.GetItems())
}

func AotoTalk(userID string,inRoomWechatIDs []string, wcMaps map[string]string,waitTime int) {
	go func() {
		time.AfterFunc(time.Minute * cast.ToDuration(waitTime), func() {
			fmt.Println("inRoomWechatIDs: ",inRoomWechatIDs)
			fmt.Println("wcMaps: ",wcMaps)
			var r = rand.New(rand.NewSource(time.Now().Unix()))
			if len(inRoomWechatIDs) == 0 {
				log.Println("没有在群里的微信号,无法聊天")
				return
			}

			talkMaterial,_ := models.NewTalkMaterial()
			talkMaterials := talkMaterial.GetCollection()
			talkMaterials.AddFieldToFilter("user_id","eq",userID)
			talkMaterials.Load()
			talkMaterialItems := talkMaterials.GetItems()

			if len(talkMaterialItems) < 1 {
				log.Println("缺少聊天素材")
			}

			for j := 0 ; j < 10 ; j ++ {
				for i := range inRoomWechatIDs{
					fromWxID := inRoomWechatIDs[i]
					roomID := wcMaps[fromWxID]
					content := "大家好呀!现在北京时间:" + time.Now().String()
					randNum := 0
					if len(talkMaterialItems) > 1 {
						randNum = r.Intn(len(talkMaterialItems))
						content = talkMaterialItems[randNum].GetString("content")
					}
					fmt.Println("机器人群聊天: fromWxID: ",fromWxID,",roomID: ",roomID,",content: ",content)
					go SendMessage(fromWxID,roomID,userID,content)
					time.Sleep(time.Second * cast.ToDuration(r.Intn(5)+1))
				}
				time.Sleep(time.Minute * cast.ToDuration(r.Intn(5)+1))
			}
		})
	}()
}