/*
@Time : 2019/6/13 16:31 
@Author : Lukebryan
@File : auto_statistics_chatroom.go
@Software: GoLand
*/
package task

import (
	"encoding/json"
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"log"
	"time"
	"wechatmanagent/models"
)

/*
统计微信
 */
func (task Task) AutoStatisticsChatroom() {
	spec := "0 50 23 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {

		now := time.Now()
		nowStr := now.Format("2006-01-02")
		nowTime := now.Format("2006-01-02 15:04:05")

		fmt.Println("统计今日拉群状况","nowStr",nowStr,"nowTime",nowTime)

		user,_ := models.NewUser()
		users := user.GetCollection()
		users.Load()

		userItems := users.GetItems()
		for i := range userItems{
			userID := userItems[i].GetString("id")
			go statisticsChatroom(userID,nowStr,nowTime)
		}
	})
	c.Start()
	select {}
}

func statisticsChatroom(userID,nowStr,nowTime string) {
	customer,_ := models.NewCustomer()
	customers := customer.GetCollection()
	customers.AddFieldToFilter("user_id","eq",userID)
	customers.Load()

	maps := make(map[string]int)
	customers.Each(func(customerItem *db.Item) {


		pullChatroom,_ := models.NewPullChatroom()
		pullChatrooms := pullChatroom.GetCollection()
		pullChatrooms.AddFieldToFilter("customer_id","eq",customerItem.GetId())
		pullChatrooms.Load()
		fmt.Println("pullChatrooms: ",pullChatrooms)
		pullChatrooms.Each(func(pItem *db.Item) {
			handleFansID := pItem.GetString("handle_fans_id")

			log.Println("拉群: ",pItem.GetId(),",几手粉: ",handleFansID,",群二维码文件: ",pItem.GetString("qrcode_file"))
			pullChatroomItem,_ := models.NewPullChatroomItem()
			pullChatroomItems := pullChatroomItem.GetCollection()
			pullChatroomItems.AddFieldToFilter("pull_chatroom_id","eq",pItem.GetId())
			pullChatroomItems.AddFieldToFilter("create_date","gt",nowStr + " 00:00:00")
			pullChatroomItems.AddFieldToFilter("create_date","lt",nowStr + " 23:59:59")
			pullChatroomItems.Load()
			fmt.Println("pullChatroomItems: ",pullChatroomItems)
			pullChatroomItems.Each(func(item *db.Item) {
				log.Println("统计拉群中,",item.GetString("wechat_id"),"--",item.GetInt("state"),"--",item.GetString("create_date"))
				state := item.GetInt("state")
				if state == 1 {
					if _,ok := maps[handleFansID]; !ok {
						maps[handleFansID] = 1
					}else {
						maps[handleFansID] = maps[handleFansID] + 1
					}
				}
			})
		})
	})

	chatroomStatistics,_ := models.NewChatroomStatistics()
	chatroomStatistics.SetData("user_id",userID)
	chatroomStatistics.SetData("create_date",nowTime)

	log.Println(userID,"的统计情况",maps)
	if _,ok := maps["1"]; !ok {
		maps["1"] = 0
	}
	if _,ok := maps["2"]; !ok {
		maps["2"] = 0
	}
	b, err := json.Marshal(maps)
	if err != nil {
		log.Println("json.Marshal failed:", err)
		return
	}

	chatroomStatistics.SetData("count_json",string(b))
	err = chatroomStatistics.Save()
	if err != nil {
		log.Println("chatroomStatistics save error: ",err)
		return
	}
}
