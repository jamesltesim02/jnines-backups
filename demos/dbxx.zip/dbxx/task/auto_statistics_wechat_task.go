/*
@Time : 2019/6/13 16:31 
@Author : Lukebryan
@File : auto_statistics_wechat.go
@Software: GoLand
*/
package task

import (
	"encoding/json"
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"github.com/spf13/cast"
	"log"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

/*
统计微信
 */
func (task Task) AutoStatisticsWechat() {
	spec := "0 55 23 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {
		fmt.Println("统计今日微信号状况")
		now := time.Now()
		yesToday := now.AddDate(0,0,-1)
		nowStr := now.Format("2006-01-02")
		yesTodayStr := yesToday.Format("2006-01-02")
		nowTime := now.Format("2006-01-02 15:04:05")

		user,_ := models.NewUser()
		users := user.GetCollection()
		users.Load()

		userItems := users.GetItems()
		for i := range userItems{
			userID := userItems[i].GetString("id")
			go statisticsWechat(userID,nowStr,nowTime,yesTodayStr)
		}
	})
	c.Start()
	select {}
}

func statisticsWechat(userID,nowStr,nowTime,yesTodayStr string) {

	wechat,_ := models.NewBindWechat()
	wechats := wechat.GetCollection()
	wechats.AddFieldToFilter("user_id","eq",userID)
	wechats.Load()

	allClosedCount := 0
	onlineCount := 0
	realOnlineCount := 0
	todayClosedCount := 0
	newCount := 0
	newCloseCount := 0

	var wechatsArr []string
	wechats.Each(func(item *db.Item) {
		wechatsArr = append(wechatsArr, item.GetString("wechat_id"))
		if strings.Index(item.GetString("create_date"),nowStr) != -1 {
			newCount ++
		}
	})

	loginMap := getWechatLoginMap(userID,wechats.GetItems())

	for _,v := range loginMap{
		//当前实际登录了的
		if v == 12007 {
			realOnlineCount ++
		}
	}

	wechats.Each(func(item *db.Item) {

		status := item.GetInt("status")
		//0 密码错误 1正常 2封号
		if status == 1 {		//正常
			onlineCount ++
		}else if status == 0 {	//密码错误
			allClosedCount ++
		}else if status == 2 {	//账号异常
			allClosedCount ++
			//todayClosedCount ++
		}

		//当天上号被封
		if strings.Index(item.GetString("create_date"),nowStr) != -1 {
			if loginMap[item.GetString("wechat_id")] == 12008 || loginMap[item.GetString("wechat_id")] == -10002{
				newCloseCount ++
			}
		}
	})
	//昨天总被封
	yestodayClosedCount := getYestodayAllClosedCount(userID,yesTodayStr)
	//今天被封= 今天总被封 - 昨天总被封 (+ 今天上号被封)
	todayClosedCount = allClosedCount - yestodayClosedCount
	if todayClosedCount < 0 {
		todayClosedCount = newCloseCount
	}
	//总被封数
	//allClosedCount = todayClosedCount + yestodayClosedCount

	go saveWechatStatistics(userID,nowTime, len(wechats.GetItems()),allClosedCount,onlineCount,realOnlineCount,todayClosedCount,newCount,newCloseCount)
}

func saveWechatStatistics(userID,nowTime string,allCount,allClosedCount,onlineCount,realOnlineCount,todayClosedCount,newCount,newCloseCount int)  {
	wechatStatistics,_ := models.NewWechatStatistics()
	wechatStatistics.SetData("user_id",userID)
	wechatStatistics.SetData("all_count", allCount)
	wechatStatistics.SetData("all_closed_count",allClosedCount)
	wechatStatistics.SetData("online_count",onlineCount)
	wechatStatistics.SetData("real_online_count",realOnlineCount)
	wechatStatistics.SetData("today_closed_count",todayClosedCount)
	wechatStatistics.SetData("new_count",newCount)
	wechatStatistics.SetData("new_close_count",newCloseCount)
	wechatStatistics.SetData("create_date",nowTime)
	err := wechatStatistics.Save()
	if err != nil {
		log.Println("wechatStatistics save error: ",err)
		return
	}
}

func getYestodayAllClosedCount(userID,nowStr string) int {
	wechatStatistics,_ := models.NewWechatStatistics()
	wechatStatisticss := wechatStatistics.GetCollection()
	wechatStatisticss.AddFieldToFilter("user_id","eq",userID)
	//wechatStatisticss.AddFieldToFilter("create_date","like",nowStr + "%")
	wechatStatisticss.AddFieldToFilter("create_date","gteq",nowStr + " 00:00:00")
	wechatStatisticss.AddFieldToFilter("create_date","lteq",nowStr + " 23:59:59")
	wechatStatisticss.AddOrder("create_date desc")
	wechatStatisticss.Load()
	items := wechatStatisticss.GetItems()
	if len(items) < 1 {
		return 0
	}
	return items[0].GetInt("all_closed_count")
}

func Login(userID string,wechatItem *db.Item) int {
	if wechatItem.GetId() == 0 {
		return 0
	}

	if wechatItem.GetString("wechat_password") == "" {
		return 0
	}

	dataMap := make(map[string]interface{})
	dataMap["wxid"] = wechatItem.GetString("wechat_id")
	dataMap["password"] = wechatItem.GetString("wechat_password")
	dataMap["six_data"] = wechatItem.GetString("login_device_data")
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,wechatItem.GetString("wechat_id"))
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/login",dataMap,heardMap)
	if err != nil {
		log.Println("PostFormRequest Error: ",err)
		return 0
	}
	respMap := make(map[string]interface{})
	err = json.Unmarshal([]byte(resp),&respMap)
	if err != nil {
		log.Println("json.Unmarshal Error: ",err)
		return 0
	}
	if cast.ToString(respMap["Code"]) == "-1" {
		return 0
	}
	return cast.ToInt(respMap["Data"])
}
