/*
@Time : 2019/8/12 15:31 
@Author : Lukebryan
@File : back_wechat_use_state_task.go
@Software: GoLand
*/
package task

import (
	"github.com/robfig/cron"
	"log"
	"wechatmanagent/models"
)

//回收机器人使用状态
func (t Task)  BackWechatUseStateTask()  {
	spec := "0 59 23 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {
		//初始化使用状态
		wechatUseState,err := models.NewWechatUseState()
		if err != nil {
			log.Println("wechatUseState init error: ",err)
		}

		wechatUseStates := wechatUseState.GetCollection()
		_,err = wechatUseStates.GetAdapter().Exec("update ym_wechat_use_state set state = 0")
		if err != nil {
			log.Println("wechatUseState update 0 error: ",err)
		}
	})
	c.Start()
	select {}
}