/*
@Time : 2019/6/12 18:42 
@Author : Lukebryan
@File : check_passfriend_sendmsg_task.go
@Software: GoLand
*/
package task

import (
	"encoding/json"
	"fmt"
	"github.com/liuzhiyi/go-db"
	"github.com/robfig/cron"
	"github.com/spf13/cast"
	"log"
	"math/rand"
	"strings"
	"time"
	"wechatmanagent/config"
	"wechatmanagent/models"
	"wechatmanagent/utils"
)

func (t Task) CheckPassFriendTask() {
	spec := "0 0 9,12,15,18,21 * * ?" // 分 时 日 月 星期
	c := cron.New()
	_ = c.AddFunc(spec, func() {
		fmt.Println("检查修改加好友是否通过了并发送消息")
		addFriendPlan,_ := models.NewAddFriendPlan()
		addFriendPlans := addFriendPlan.GetCollection()
		addFriendPlans.Load()

		addFriendPlans.Each(func(item *db.Item) {
			userID := item.GetString("user_id")

			addFriendLog,_ := models.NewAddFriendLog()
			addFriendLogs := addFriendLog.GetCollection()
			addFriendLogs.AddFieldToFilter("add_friend_plan_id","eq",item.GetId())
			addFriendLogs.AddFieldToFilter("state","eq",2)
			addFriendLogs.Load()

			loginedMap := getWechatLoginMap(userID,addFriendLogs.GetItems())

			items := addFriendLogs.GetItems()
			for i := range items{
				if loginedMap[items[i].GetString("wechat_id")] == 12007 {
					go CheckPassed(userID,items[i])
				}
			}
		})
	})
	c.Start()
	select {}
}

//检查是否通过了好友
func CheckPassed(userID string,item *db.Item) {
	addPhone := item.GetString("add_phone")

	strangerWechatInfo,_ := models.NewStrangerWechatInfo()
	strangerWechatInfo.SetData("phone",addPhone)
	strangerWechatInfo.Row()
	friendWechatID := strangerWechatInfo.GetString("wechat_id")
	if friendWechatID != "" {
		GetContact(userID,friendWechatID,item)
	}
}

func GetContact(userID,friendWechatID string,item *db.Item)  {
	wechatID := item.GetString("wechat_id")
	dataMap := make(map[string]interface{})
	dataMap["id"] = friendWechatID
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID,wechatID)
	resp, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/getcontact",dataMap,heardMap)
	if err != nil {
		log.Println("getcontact error: ",err)
	}

	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(resp),&maps)
	if err != nil {
		log.Println("getcontact json.Unmarshal error: ",err)
	}

	contactResponse := models.ContactResponse{}
	b2,err := json.Marshal(maps["Data"])
	if err != nil {
		log.Println("searchContactResponse json.Marshal error: ",err)
	}
	err = json.Unmarshal(b2,&contactResponse)
	if err != nil {
		log.Println("searchContactResponse json.Unmarshal error: ",err)
	}

	username := ""
	if contactResponse.ContactCount > 0 {
		if contactResponse.ContactList[0].UserName.String_ != nil {
			username = fmt.Sprint(*contactResponse.ContactList[0].UserName.String_)
		}

	}
	fmt.Println("passFriend wechatID: ",username)
	if username != "" && strings.Index(username,"wxid") >=0 {
		go passFriend(username,item)
	}
}

//好友通过了
func passFriend(username string,item *db.Item) {
	item.SetData("add_wechat_id",username)
	item.SetData("state",1)
	item.SetData("pass_date",time.Now().Format("2006-01-02 15:04:05"))
	if err := item.Save();err != nil {
		log.Println("addFriendLog save error: ",err)
	}
	return
}

func GetRandMsgs(userID string) [][2]string {
	arrs := make([][2]string,0)

	msgMaterialGroup,_ := models.NewMsgMaterialGroup()
	msgMaterialGroups := msgMaterialGroup.GetCollection()
	msgMaterialGroups.AddFieldToFilter("user_id","eq",userID)
	msgMaterialGroups.Load()
	items := msgMaterialGroups.GetItems()
	if len(items) < 1 {
		arr := [2]string{"0","你好!"}
		arrs = append(arrs, arr)
		return arrs
	}
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	randNum := r.Intn(len(items))

	msgMaterial,_ := models.NewMsgMaterial()
	msgMaterials := msgMaterial.GetCollection()
	msgMaterials.AddFieldToFilter("msg_material_group_id","eq",items[randNum].GetId())
	msgMaterials.Load()

	if len(msgMaterials.GetItems()) < 1 {
		arr := [2]string{"0","你好!"}
		arrs = append(arrs, arr)
		return arrs
	}

	msgMaterials.Each(func(item *db.Item) {
		var arr [2]string
		arr[0] = item.GetString("types")
		arr[1] = item.GetString("content")
		arrs = append(arrs, arr)
	})
	return arrs
}

func GetFriendWxID(userID,wxId,addPhone string) (toWxID string) {

	dataMap := make(map[string]interface{})
	dataMap["id"] = addPhone	//微信ID或者手机号
	heardMap := make(map[string]string)
	heardMap["Authorization"] = utils.GentToken(userID, wxId)
	data, err := utils.PostFormRequest(config.Sysconfig.WechatServerAddr+"/account/searchcontact", dataMap, heardMap)
	if err != nil {
		log.Println("getcontact error: ", err)
		return
	}

	maps := make(map[string]interface{})
	err = json.Unmarshal([]byte(data), &maps)
	if err != nil {
		log.Println("getcontact json.Unmarshal Error: ", err)
		return
	}
	if cast.ToString(maps["Code"]) == "-1" {
		//log.Println("getcontact  Error: ", maps["Msg"])
		return
	}

	b,err := json.Marshal(maps["Data"])
	if err != nil {
		log.Println("getcontact json.Marshal Error: ", err)
		return
	}
	
	go saveStrangerWechatInfo(maps["Data"],addPhone)
	
	err = json.Unmarshal(b,&maps)
	if err != nil {
		log.Println("getcontact json.Unmarshal Error: ", err)
		return
	}
	b2,err := json.Marshal(maps["UserName"])
	if err != nil {
		log.Println("getcontact json.Marshal Error: ", err)
		return
	}
	err = json.Unmarshal(b2,&maps)
	if err != nil {
		log.Println("getcontact json.Unmarshal Error: ", err)
		return
	}
	toWxID = cast.ToString(maps["String"])
	if toWxID == "{}" {
		toWxID = ""
	}
	log.Println("能否获取好友微信ID: ",toWxID)
	return
}

//保存陌生人信息
func saveStrangerWechatInfo(data interface{},addPhone string) {
	b,err := json.Marshal(data)
	if err != nil {
		log.Println("saveStrangerWechatInfo json.Marshal Error: ", err)
		return
	}
	searchContactResponse := models.SearchContactResponse{}
	err = json.Unmarshal(b,&searchContactResponse)
	if err != nil {
		log.Println("json.Unmarshal error: ",err)
	}
	strangerWechatInfo,err := models.NewStrangerWechatInfo()
	if err != nil {
		log.Println("strangerWechatInfo init error: ",err)
		return
	}
	strangerWechatInfo.SetData("user_name",searchContactResponse.UserName.String_)
	strangerWechatInfo.SetData("nick_name",searchContactResponse.NickName.String_)
	wechatID := cast.ToString(searchContactResponse.QuanPin.String_)
	if wechatID != "" && strings.Index(wechatID,"wxid") != -1 {
		wxid1 := wechatID[ : 4]
		wxid2 := wechatID[ 4 :]
		wechatID = wxid1 + "_" + wxid2
	}
	strangerWechatInfo.SetData("wechat_id",wechatID)
	strangerWechatInfo.SetData("phone",addPhone)
	strangerWechatInfo.SetData("sex",&searchContactResponse.Sex)
	strangerWechatInfo.SetData("province",searchContactResponse.Province)
	strangerWechatInfo.SetData("city",searchContactResponse.City)
	strangerWechatInfo.SetData("signature",searchContactResponse.Signature)
	strangerWechatInfo.SetData("personal_card",searchContactResponse.PersonalCard)
	strangerWechatInfo.SetData("weibo",searchContactResponse.Weibo)
	strangerWechatInfo.SetData("alias",searchContactResponse.Alias)
	strangerWechatInfo.SetData("country",searchContactResponse.Country)
	strangerWechatInfo.SetData("other_info",string(b))
	if err := strangerWechatInfo.Save(); err != nil {
		log.Println("strangerWechatInfo save error: ",err)
	}
	return
}