/*
@Time : 2019/5/18 15:05 
@Author : Lukebryan
@File : addfriendplan_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type AddFriendPlanController struct {
	Ctx     iris.Context
	AddFriendPlan	api.AddFriendPlan
}

func NewAddFriendPlanController() *AddFriendPlanController {
	return &AddFriendPlanController{AddFriendPlan:api.AddFriendPlan{}}
}

//保存
func (g *AddFriendPlanController) PostSave() {
	g.AddFriendPlan.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//终止/开始任务
func (g *AddFriendPlanController) PostStoporstart() {
	g.AddFriendPlan.StopOrStart(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//获取
func (g *AddFriendPlanController) PostGet() {
	g.AddFriendPlan.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//删除
//func (g *AddFriendPlanController) PostDel() {
//	g.AddFriendPlan.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
//}
//列表
func (g *AddFriendPlanController) PostList() {
	g.AddFriendPlan.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//历史记录列表
func (g *AddFriendPlanController) PostLogs() {
	g.AddFriendPlan.Logs(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//统计
func (g *AddFriendPlanController) PostStatistics() {
	g.AddFriendPlan.Statistics(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//单个微信组统计
func (g *AddFriendPlanController) PostGroupStatistics() {
	g.AddFriendPlan.GroupStatistics(g.Ctx.ResponseWriter(),g.Ctx.Request())
}


