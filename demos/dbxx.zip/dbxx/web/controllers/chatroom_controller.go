/*
@Time : 2019/5/13 16:46 
@Author : Lukebryan
@File : chatroom_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type ChatroomController struct {
	Ctx     iris.Context
	Chatroom	api.Chatroom
	ChatroomStatistics	api.ChatroomStatistics
	TalkChatroom	api.TalkChatroom
}

func NewChatroomController() *ChatroomController {
	return &ChatroomController{Chatroom:api.Chatroom{}}
}

//保存群
func (g *ChatroomController) PostCreate() {
	g.Chatroom.CreateChatroom(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//退出群
func (g *ChatroomController) PostQuit() {
	g.Chatroom.QuitChatroom(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//扫码进群
func (g *ChatroomController) PostScanqrjoin() {
	g.Chatroom.ScanQRJoin(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//拉人进群
func (g *ChatroomController) PostAddnewmembers() {
	g.Chatroom.AddNewMembers(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

// 获取群成员列表
func (g *ChatroomController) PostGetchatroommembers() {
	g.Chatroom.GetChatroomMembers(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//群统计
func (g *ChatroomController) PostStatistics() {
	g.ChatroomStatistics.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}


//机器人群聊保存
func (g *ChatroomController) PostTalkSave() {
	g.TalkChatroom.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//获取单个机器人群聊
func (g *ChatroomController) PostTalkGet() {
	g.TalkChatroom.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//删除机器人群聊
func (g *ChatroomController) PostTalkDel() {
	g.TalkChatroom.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//机器人群聊列表
func (g *ChatroomController) PostTalkList() {
	g.TalkChatroom.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

