/*
@Time : 2019/5/13 16:02 
@Author : Lukebryan
@File : base_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"log"
	"wechatmanagent/api"
	"wechatmanagent/config"
)

type BaseController struct {
	Ctx     iris.Context
	Article	api.Article
	Sns	api.Sns
}

func NewBaseController() *BaseController {
	return &BaseController{Article:api.Article{},Sns:api.Sns{}}
}

// GetStaticURL 临时 URL 赚永久 URL
func (g *BaseController) PostGet_static_url() {
	g.Article.GetStaticURL(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//发送朋友圈
func (g *BaseController) PostMmsnspost() {
	g.Sns.MMSnsPost(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//修改朋友圈背景图
func (g *BaseController) PostMmsnsModifysnsbackgroud() {
	g.Sns.Modifysnsbackgroud(g.Ctx.ResponseWriter(),g.Ctx.Request())
}


//模板下载
func (g *BaseController) GetStaticTemplateDown() {
	fileSavePath := config.Sysconfig.FileSavePath+"/static/template/"
	types := g.Ctx.Request().FormValue("type")
	name := "import_template.txt"
	if types == "1"{		//微信模板
		name = "import_template.txt"
	}else if types == "2" {		//导入手机模板
		name = "addpeople_template.xlsx"
	}else if types == "3" {		//聊天模板
		name = "talk_template.txt"
	}else if types == "4" {		//微信素材模板
		name = "wechat_info_template.txt"
	}

	a:=g.Ctx.ResponseWriter()
	a.Header().Set("Content-Disposition", "attachment; filename="+name)
	a.Header().Set("Content-Type", "application/octet-stream")
	err := g.Ctx.SendFile(fileSavePath+name, name)
	if err != nil {
		log.Println(err)
	}
}
