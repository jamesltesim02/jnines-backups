/*
@Time : 2019/5/13 14:31 
@Author : Lukebryan
@File : user_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type UserController struct {
	Ctx     iris.Context
	User	api.User
}

func NewUserController() *UserController {
	return &UserController{User:api.User{}}
}

//创建用户
func (g *UserController) PostCreate() {
	g.User.Create(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//修改密码
func (g *UserController) PostChangePassword() {
	g.User.ChangePassword(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//登录
func (g *UserController) PostLogin() {
	g.User.Login(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//设置二级密码
func (g *UserController) PostSecondpwd() {
	g.User.SetSecondPwd(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//是否有二级密码
func (g *UserController) PostHassecondpwd() {
	g.User.HasSecondPwd(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

