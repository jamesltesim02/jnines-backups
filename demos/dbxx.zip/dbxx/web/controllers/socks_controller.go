/*
@Time : 2019/5/13 16:44 
@Author : Lukebryan
@File : socks_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type SocksController struct {
	Ctx     iris.Context
	Socks	api.Socks
}

func NewSocksController() *SocksController {
	return &SocksController{Socks:api.Socks{}}
}

//导入任务
func (g *SocksController) PostImport() {
	g.Socks.Import(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//保存任务
func (g *SocksController) PostSave() {
	g.Socks.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//删除任务
func (g *SocksController) PostDel() {
	g.Socks.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取任务
func (g *SocksController) PostGet() {
	g.Socks.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取任务列表
func (g *SocksController) PostList() {
	g.Socks.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//获取任务列表
func (g *SocksController) PostAddress() {
	g.Socks.Address(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//导出
func (g *SocksController) GetExport() {
	g.Socks.Export(g.Ctx)
}
//删除全部无效
func (g *SocksController) PostDeldisable() {
	g.Socks.Deldisable(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

