/*
@Time : 2019/5/16 20:11 
@Author : Lukebryan
@File : verifymessagegroup_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type VerifyMessageGroupController struct {
	Ctx     iris.Context
	VerifyMessageGroup	api.VerifyMessageGroup
	MoveMessageType	api.MoveMessageType
}

func NewVerifyMessageGroupController() *VerifyMessageGroupController {
	return &VerifyMessageGroupController{VerifyMessageGroup:api.VerifyMessageGroup{}}
}

//保存验证消息组
func (g *VerifyMessageGroupController) PostSave() {
	g.VerifyMessageGroup.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//获取验证消息组
func (g *VerifyMessageGroupController) PostGet() {
	g.VerifyMessageGroup.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//删除验证消息组
func (g *VerifyMessageGroupController) PostDel() {
	g.VerifyMessageGroup.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//删除单条验证消息组
func (g *VerifyMessageGroupController) PostDelone() {
	g.VerifyMessageGroup.DelOne(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//验证消息组列表
func (g *VerifyMessageGroupController) PostList() {
	g.VerifyMessageGroup.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//验证消息类型列表
func (g *VerifyMessageGroupController) PostMovemessages() {
	g.MoveMessageType.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
