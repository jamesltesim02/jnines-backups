/*
@Time : 2019/5/13 15:50 
@Author : Lukebryan
@File : bindwechat_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type BindWechatController struct {
	Ctx     iris.Context
	BindWechat	api.BindWechat
	BindWechatBack	api.BindWechatBack
	WechatStatistics	api.WechatStatistics
	WechatLog	api.WechatLog
}

func NewBindWechatController() *BindWechatController {
	return &BindWechatController{BindWechat:api.BindWechat{}}
}

//创建微信账号
func (g *BindWechatController) PostSave() {
	g.BindWechat.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//删除微信账号
func (g *BindWechatController) PostDel() {
	g.BindWechat.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取微信账号
func (g *BindWechatController) PostGet() {
	g.BindWechat.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取微信账号列表
func (g *BindWechatController) PostList() {
	g.BindWechat.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//单个绑定/解绑素材
func (g *BindWechatController) PostBindmaterial() {
	g.BindWechat.BindMaterial(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//一键删除失败微信
func (g *BindWechatController) PostDelFails() {
	g.BindWechat.DelFailWechats(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//导出
func (g *BindWechatController) GetExportlog() {
	g.BindWechat.ExportLog(g.Ctx)
}

//获取微信账号统计
func (g *BindWechatController) PostStatistics() {
	g.WechatStatistics.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}




//回收站列表
func (g *BindWechatController) PostRecycleList() {
	g.BindWechatBack.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//回收站删除
func (g *BindWechatController) PostRecycleDel() {
	g.BindWechatBack.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//回收站恢复
func (g *BindWechatController) PostRecycleBack() {
	g.BindWechatBack.Back(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//日志
func (g *BindWechatController) PostLogs() {
	g.WechatLog.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}