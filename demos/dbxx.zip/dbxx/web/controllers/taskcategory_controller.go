/*
@Time : 2019/5/13 16:27 
@Author : Lukebryan
@File : taskcategory_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type TaskCategoryController struct {
	Ctx     iris.Context
	TaskCategory	api.TaskCategory
}

func NewTaskCategoryController() *TaskCategoryController {
	return &TaskCategoryController{TaskCategory:api.TaskCategory{}}
}

//保存任务分类
func (g *TaskCategoryController) PostSave() {
	g.TaskCategory.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())

}

//删除任务分类
func (g *TaskCategoryController) PostDel() {
	g.TaskCategory.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取任务分类
func (g *TaskCategoryController) PostGet() {
	g.TaskCategory.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取微信素材列表
func (g *TaskCategoryController) PostList() {
	g.TaskCategory.List(g.Ctx.ResponseWriter(),g.Ctx.Request())

}
