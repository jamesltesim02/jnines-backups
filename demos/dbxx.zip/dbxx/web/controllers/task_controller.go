/*
@Time : 2019/5/13 16:32 
@Author : Lukebryan
@File : task_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type TaskController struct {
	Ctx     iris.Context
	Task	api.Task
}

func NewTaskController() *TaskController {
	return &TaskController{Task:api.Task{}}
}

//保存任务
func (g *TaskController) PostSave() {
	g.Task.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//删除任务
func (g *TaskController) PostDel() {
	g.Task.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取任务
func (g *TaskController) PostGet() {
	g.Task.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取任务列表
func (g *TaskController) PostList() {
	g.Task.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
