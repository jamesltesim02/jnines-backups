/*
@Time : 2019/5/18 16:43 
@Author : Lukebryan
@File : customer_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type CustomerController struct {
	Ctx     iris.Context
	Customer	api.Customer
}

func NewCustomerController() *CustomerController {
	return &CustomerController{Customer:api.Customer{}}
}

//保存
func (g *CustomerController) PostSave() {
	g.Customer.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//获取
func (g *CustomerController) PostGet() {
	g.Customer.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//列表
func (g *CustomerController) PostList() {
	g.Customer.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//几手粉列表
func (g *CustomerController) PostHandlefans() {
	g.Customer.Handlefans(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//报表日志
func (g *CustomerController) PostChatroomlogs() {
	g.Customer.ChatRoomLogs(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//导出报表
func (g *CustomerController) PostChatroomExport() {
	g.Customer.ChatRoomExport(g.Ctx.ResponseWriter(),g.Ctx.Request())
}