/*
@Time : 2019/5/20 11:00 
@Author : Lukebryan
@File : pullchatroom_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type PullChatroomController struct {
	Ctx     iris.Context
	PullChatroom	api.PullChatroom
}

func NewPullChatroomController() *PullChatroomController {
	return &PullChatroomController{PullChatroom:api.PullChatroom{}}
}


//计划保存
func (g *PullChatroomController) PostPlansave() {
	g.PullChatroom.PlanSave(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//计划列表
func (g *PullChatroomController) PostPlanlist() {
	g.PullChatroom.PlanList(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//计划开始或取消
func (g *PullChatroomController) PostPlanStoporstart() {
	g.PullChatroom.PlanStopOrStart(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//计划删除
func (g *PullChatroomController) PostPlandel() {
	g.PullChatroom.PlanDelete(g.Ctx.ResponseWriter(),g.Ctx.Request())
}



//保存
func (g *PullChatroomController) PostSave() {
	g.PullChatroom.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//保存
func (g *PullChatroomController) PostUpdate() {
	g.PullChatroom.Update(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//保存
func (g *PullChatroomController) PostCodeUrl() {
	g.PullChatroom.CodeUrl(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//列表
func (g *PullChatroomController) PostList() {
	g.PullChatroom.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//删除
func (g *PullChatroomController) PostDel() {
	g.PullChatroom.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//详细
func (g *PullChatroomController) PostItems() {
	g.PullChatroom.Items(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//二维码
func (g *PullChatroomController) PostQrcode() {
	g.PullChatroom.QrCode(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

