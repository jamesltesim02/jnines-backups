/*
@Time : 2019/6/10 18:45 
@Author : Lukebryan
@File : wechatfile_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type WechatFileController struct {
	Ctx     iris.Context
	WechatFile	api.WechatFile
}

func NewWechatFileController() *WechatFileController {
	return &WechatFileController{WechatFile:api.WechatFile{}}
}

//列表
func (g *WechatFileController) PostList() {
	g.WechatFile.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//结果
func (g *WechatFileController) PostLoginlogs() {
	g.WechatFile.LoginLogs(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//预览内容
func (g *WechatFileController) PostFileitems() {
	g.WechatFile.FileItems(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
