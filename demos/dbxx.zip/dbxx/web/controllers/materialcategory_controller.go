/*
@Time : 2019/5/13 15:54 
@Author : Lukebryan
@File : materialcategory_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type MaterialCategoryController struct {
	Ctx     iris.Context
	MaterialCategory	api.MaterialCategory
}

func NewMaterialCategoryController() *MaterialCategoryController {
	return &MaterialCategoryController{MaterialCategory:api.MaterialCategory{}}
}

//创建微信素材分类
func (g *MaterialCategoryController) PostCreate() {
	g.MaterialCategory.Create(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//修改微信素材分类
func (g *MaterialCategoryController) PostUpdate() {
	g.MaterialCategory.Update(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//删除微信素材分类
func (g *MaterialCategoryController) PostDel() {
	g.MaterialCategory.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取微信素材分类
func (g *MaterialCategoryController) PostGet() {
	g.MaterialCategory.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取微信素材分类列表
func (g *MaterialCategoryController) PostList() {
	g.MaterialCategory.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
