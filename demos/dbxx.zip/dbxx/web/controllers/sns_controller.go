/*
@Time : 2019/5/28 11:31 
@Author : Lukebryan
@File : friendscircle_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type SnsController struct {
	Ctx     iris.Context
	SnsMaterial	api.SnsMaterial
	SnsMaterialGroup	api.SnsMaterialGroup
	SnsPlan	api.SnsPlan
}

func NewSnsController() *SnsController {
	return &SnsController{
		SnsMaterialGroup:api.SnsMaterialGroup{},
		SnsMaterial:api.SnsMaterial{},
		SnsPlan:api.SnsPlan{}}
}

//素材保存
func (g *SnsController) PostMaterialSave() {
	g.SnsMaterial.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材获取
func (g *SnsController) PostMaterialGet() {
	g.SnsMaterial.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材删除
func (g *SnsController) PostMaterialDel() {
	g.SnsMaterial.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材列表
func (g *SnsController) PostMaterialList() {
	g.SnsMaterial.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}



//素材组保存
func (g *SnsController) PostGroupSave() {
	g.SnsMaterialGroup.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材组获取
func (g *SnsController) PostGroupGet() {
	g.SnsMaterialGroup.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材组删除
func (g *SnsController) PostGroupDel() {
	g.SnsMaterialGroup.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材组列表
func (g *SnsController) PostGroupList() {
	g.SnsMaterialGroup.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}



//保存计划
func (g *SnsController) PostPlanSave() {
	g.SnsPlan.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//删除计划
func (g *SnsController) PostPlanDel() {
	g.SnsPlan.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//计划列表
func (g *SnsController) PostPlanList() {
	g.SnsPlan.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//详细列表
func (g *SnsController) PostPlanItem() {
	g.SnsPlan.Item(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
