/*
@Time : 2019/5/13 15:40 
@Author : Lukebryan
@File : bindwechatgroup_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type BindWechatGroupController struct {
	Ctx     iris.Context
	BindWechatGroup	api.BindWechatGroup
}

func NewBindWechatGroupController() *BindWechatGroupController {
	return &BindWechatGroupController{BindWechatGroup:api.BindWechatGroup{}}
}

//创建微信账号分组
func (g *BindWechatGroupController) PostCreate() {
	g.BindWechatGroup.Create(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//合并微信账号分组
func (g *BindWechatGroupController) PostMerge() {
	g.BindWechatGroup.Merge(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//批量普通登录微信账号分组
func (g *BindWechatGroupController) PostBatchlogin() {
	g.BindWechatGroup.BatchLogin(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//批量注销微信账号分组
func (g *BindWechatGroupController) PostBatchloginout() {
	g.BindWechatGroup.BatchLoginout(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//修改微信账号分组
func (g *BindWechatGroupController) PostUpdate() {
	g.BindWechatGroup.Update(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//删除微信账号分组
func (g *BindWechatGroupController) PostDel() {
	g.BindWechatGroup.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取微信账号分组
func (g *BindWechatGroupController) PostGet() {
	g.BindWechatGroup.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取微信账号分组列表
func (g *BindWechatGroupController) PostList() {
	g.BindWechatGroup.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//批量修改信息(昵称/头像/个性签名/朋友圈背景图)
func (g *BindWechatGroupController) PostBatchupdateinfo() {
	g.BindWechatGroup.BatchUpdateInfo(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//批量解绑微信
func (g *BindWechatGroupController) PostBacthuntyingmaterial() {
	g.BindWechatGroup.BacthUntyingMaterial(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//批量修改密码
func (g *BindWechatGroupController) PostBatchupdatepwd() {
	g.BindWechatGroup.BatchUpdatePwd(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//获取微信分组导出数据
func (g *BindWechatGroupController) GetWechats() {
	g.BindWechatGroup.Wechats(g.Ctx)
}

