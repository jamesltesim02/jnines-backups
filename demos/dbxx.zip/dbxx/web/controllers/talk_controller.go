/*
@Time : 2019/5/28 11:31 
@Author : Lukebryan
@File : friendscircle_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type TalkController struct {
	Ctx     iris.Context
	TalkMaterial	api.TalkMaterial
	TalkMaterialGroup	api.TalkMaterialGroup
	TalkPlan	api.TalkPlan
}

func NewTalkController() *TalkController {
	return &TalkController{
		TalkMaterialGroup:api.TalkMaterialGroup{},
		TalkMaterial:api.TalkMaterial{},
		TalkPlan:api.TalkPlan{}}
}

//素材保存
func (g *TalkController) PostMaterialSave() {
	g.TalkMaterial.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材
func (g *TalkController) PostMaterialImport() {
	g.TalkMaterial.Import(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材获取
func (g *TalkController) PostMaterialGet() {
	g.TalkMaterial.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材删除
func (g *TalkController) PostMaterialDel() {
	g.TalkMaterial.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材列表
func (g *TalkController) PostMaterialList() {
	g.TalkMaterial.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}



//素材组保存
func (g *TalkController) PostGroupSave() {
	g.TalkMaterialGroup.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材组获取
func (g *TalkController) PostGroupGet() {
	g.TalkMaterialGroup.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材组删除
func (g *TalkController) PostGroupDel() {
	g.TalkMaterialGroup.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材组列表
func (g *TalkController) PostGroupList() {
	g.TalkMaterialGroup.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}



//保存计划
func (g *TalkController) PostPlanSave() {
	g.TalkPlan.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//删除计划
func (g *TalkController) PostPlanDel() {
	g.TalkPlan.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//计划列表
func (g *TalkController) PostPlanList() {
	g.TalkPlan.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//详细列表
func (g *TalkController) PostPlanItem() {
	g.TalkPlan.Item(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
