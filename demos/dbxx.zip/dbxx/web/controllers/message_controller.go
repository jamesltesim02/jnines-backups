/*
@Time : 2019/5/13 17:05 
@Author : Lukebryan
@File : message_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type MessageController struct {
	Ctx     iris.Context
	Message	api.Message
}

func NewMessageController() *MessageController {
	return &MessageController{Message:api.Message{}}
}

//单发消息
func (g *MessageController)  PostSendmessage() {
	g.Message.SendMessage(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//发送动态表情
func (g *MessageController) PostSendemoji() {
	g.Message.SendEmoji(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//发送语音
func (g *MessageController) PostSendvoice() {
	g.Message.SendVoice(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//群发信息
func (g *MessageController) PostMasssend() {
	g.Message.MassSend(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//消息列表
func (g *MessageController) PostList() {
	g.Message.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
