/*
@Time : 2019/5/28 11:31 
@Author : Lukebryan
@File : msg_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type MsgController struct {
	Ctx     iris.Context
	MsgMaterial	api.MsgMaterial
	MsgMaterialGroup	api.MsgMaterialGroup
}

func NewMsgController() *MsgController {
	return &MsgController{
		MsgMaterialGroup:api.MsgMaterialGroup{},
		MsgMaterial:api.MsgMaterial{}}
}

//素材保存
func (g *MsgController) PostMaterialSave() {
	g.MsgMaterial.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材获取
func (g *MsgController) PostMaterialGet() {
	g.MsgMaterial.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材删除
func (g *MsgController) PostMaterialDel() {
	g.MsgMaterial.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材列表
func (g *MsgController) PostMaterialList() {
	g.MsgMaterial.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}



//素材组保存
func (g *MsgController) PostGroupSave() {
	g.MsgMaterialGroup.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材组获取
func (g *MsgController) PostGroupGet() {
	g.MsgMaterialGroup.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材组删除
func (g *MsgController) PostGroupDel() {
	g.MsgMaterialGroup.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//素材组列表
func (g *MsgController) PostGroupList() {
	g.MsgMaterialGroup.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}