/*
@Time : 2019/5/13 17:09 
@Author : Lukebryan
@File : wallet_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type WalletController struct {
	Ctx     iris.Context
	Wallet	api.Wallet
}

func NewWalletController() *WalletController {
	return &WalletController{Wallet:api.Wallet{}}
}

//打开红包
func (g *WalletController) PostOpenwxhb() {
	g.Wallet.OpenWxhb(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//打开红包 (limit,offset参数设置本次请求返回领取红包人数区间)
func (g *WalletController) PostGetdetailwxhb() {
	g.Wallet.GetDetailWxhb(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//收款
func (g *WalletController) PostTransferoperation() {
	g.Wallet.TransferOperation(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//收款查询
func (g *WalletController) PostTransferqurey() {
	g.Wallet.TransferQurey(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//查看钱包明细
func (g *WalletController) PostGetwalletdetail() {
	g.Wallet.GetWalletDetail(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

// 从本地读取余额变动记录
func (g *WalletController) PostGetcreditorderfromlocal() {
	g.Wallet.GetCreditOrderFromLocal(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//二维码收款带金额
func (g *WalletController) PostTransfersetf2ffee() {
	g.Wallet.TransferSetF2FFee(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//二维码收款
func (g *WalletController) PostF2fqrcode() {
	g.Wallet.F2FQRCode(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
