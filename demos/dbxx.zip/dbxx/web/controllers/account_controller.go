/*
@Time : 2019/5/13 16:51 
@Author : Lukebryan
@File : account_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type AccountController struct {
	Ctx     iris.Context
	Account	api.Account
	WechatPwdHistory	api.WechatPwdHistory
}

func NewAccountController() *AccountController {
	return &AccountController{Account:api.Account{}}
}

//二维码登录
func (g *AccountController) PostLoginbyqrcode() {
	g.Account.LoginByQRCode(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//登录
func (g *AccountController) PostLogin() {
	g.Account.Login(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//授权登录手机端/ipad端
func (g *AccountController) PostAccessqrlogin() {
	g.Account.Accessqrlogin(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//同步联系人
func (g *AccountController) PostSynccontacts() {
	g.Account.SyncContacts(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取联系人
func (g *AccountController) PostGetcontacts() {
	g.Account.GetContacts(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//批量检查登录状态
func (g *AccountController) PostBatchcheckloginstatus() {
	g.Account.BatchCheckLoginStatus(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//检查登录状态
func (g *AccountController) PostCheckloginqrcodestatus() {
	g.Account.CheckLoginQRCodeStatus(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//加好友
func (g *AccountController) PostAddfriend() {
	g.Account.AddFriend(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//上传通讯录添加好友
func (g *AccountController) PostAddfriendwithimcontact() {
	g.Account.AddFriendWithIMContact(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//修改头像
func (g *AccountController) PostModifyheadimg() {
	g.Account.ModifyHeadImg(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//更新地区
func (g *AccountController) PostModifyarea() {
	g.Account.ModifyArea(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//更新性别 1男2女
func (g *AccountController) PostModifysex() {
	g.Account.ModifySex(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

// 更新个性签名
func (g *AccountController) PostUpdatepersonality() {
	g.Account.UpdatePersonality(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//更新昵称
func (g *AccountController) PostUpdatenickname() {
	g.Account.UpdateNickname(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//更新别名(微信号)
func (g *AccountController) PostUpdatealias() {
	g.Account.UpdateAlias(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//批量登录
func (g *AccountController) PostBatchlogin() {
	g.Account.BatchLogin(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//登出
func (g *AccountController) PostLogout() {
	g.Account.Logout(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//添加标签列表
func (g *AccountController) PostAddcontactlabel() {
	g.Account.AddContactLabel(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//删除标签列表
func (g *AccountController) PostDelcontactlabel() {
	g.Account.DelContactLabel(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

// 获取标签列表
func (g *AccountController) PostGetcontactlabellist() {
	g.Account.GetContactLabelList(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

// 添加好友到标签
func (g *AccountController) PostModifycontactlabellist() {
	g.Account.ModifyContactLabelList(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//删除好友
func (g *AccountController) PostDelfriend() {
	g.Account.DelFriend(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//拉黑好友
func (g *AccountController) PostBanfriend() {
	g.Account.BanFriend(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//修改密码
func (g *AccountController) PostChangepassword() {
	g.Account.ChangePassword(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//修改密码历史记录
func (g *AccountController) PostPwdHistory() {
	g.WechatPwdHistory.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//生成03数据
func (g *AccountController) PostGenerateclientcheckdata() {
	g.Account.GenerateClientCheckData(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//搜索wxid或者群id
func (g *AccountController) PostSearchcontact() {
	g.Account.SearchContact(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//回调地址
func (g *AccountController) PostCheckFriendPassed() {
	g.Account.CheckFriendPassed(g.Ctx.ResponseWriter(),g.Ctx.Request())
}