/*
@Time : 2019/5/13 16:23 
@Author : Lukebryan
@File : material_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type MaterialController struct {
	Ctx     iris.Context
	Material	api.Material
}

func NewMaterialController() *MaterialController {
	return &MaterialController{Material:api.Material{}}
}

//保存微信素材
func (g *MaterialController) PostSave() {
	g.Material.Save(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//删除微信素材
func (g *MaterialController) PostDel() {
	g.Material.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//创建微信素材
func (g *MaterialController) PostGet() {
	g.Material.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//获取微信素材列表
func (g *MaterialController) PostList() {
	g.Material.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//导入微信素材
func (g *MaterialController) PostImport() {
	g.Material.Import(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//微信素材
func (g *MaterialController) PostAreacodes() {
	g.Material.AreaCodes(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
