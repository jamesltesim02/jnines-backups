/*
@Time : 2019/5/20 10:38 
@Author : Lukebryan
@File : upload_file.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type UploadFileController struct {
	Ctx     iris.Context
	UploadFile	api.UploadFile
}

func NewUploadFileController() *UploadFileController {
	return &UploadFileController{UploadFile:api.UploadFile{}}
}

//导入
func (g *UploadFileController) PostUpload() {
	g.UploadFile.Upload(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
