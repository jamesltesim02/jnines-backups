/*
@Time : 2019/5/17 20:02 
@Author : Lukebryan
@File : importfile_controller.go
@Software: GoLand
*/
package controllers

import (
	"github.com/kataras/iris"
	"wechatmanagent/api"
)

type ImportFileController struct {
	Ctx     iris.Context
	ImportFile	api.ImportFile
	PhoneV1v2	api.PhoneV1v2
}

func NewImportFileController() *ImportFileController {
	return &ImportFileController{ImportFile:api.ImportFile{}}
}

//导入
func (g *ImportFileController) PostImport() {
	g.ImportFile.Import(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//修改
func (g *ImportFileController) PostUpdate() {
	g.ImportFile.Update(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//获取
func (g *ImportFileController) PostGet() {
	g.ImportFile.Get(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//删除
func (g *ImportFileController) PostDel() {
	g.ImportFile.Del(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//合并
func (g *ImportFileController) PostMerge() {
	g.ImportFile.Merge(g.Ctx.ResponseWriter(),g.Ctx.Request())
}
//列表
func (g *ImportFileController) PostList() {
	g.ImportFile.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}

//列表
//localhost:8848/api/v1/importfile/phonev1v2/list
func (g *ImportFileController) PostPhonev1v2List() {
	g.PhoneV1v2.List(g.Ctx.ResponseWriter(),g.Ctx.Request())
}