package middleware

import (
	"fmt"
	"github.com/dgrijalva/jwt-go"
	jwtmiddleware "github.com/iris-contrib/middleware/jwt"
	"github.com/kataras/iris"
	"github.com/spf13/cast"
	"log"
	"strings"
	"time"
	"wechatmanagent/utils"
)

const JwtKey = "secret"

//注册jwt中间件
func GetJWT() *jwtmiddleware.Middleware {
	jwtHandler := jwtmiddleware.New(jwtmiddleware.Config{
		//这个方法将验证jwt的token
		ValidationKeyGetter: func(token *jwt.Token) (interface{}, error) {
			//自己加密的秘钥或者说盐值
			return []byte(JwtKey), nil
		},
		//加密的方式
		SigningMethod: jwt.SigningMethodHS256,
		//验证未通过错误处理方式
		ErrorHandler: func(ctx iris.Context, s string) {

			if strings.Contains(ctx.Request().RequestURI, "/api/v1/user/login") {
				ctx.Next()
			}else if strings.Contains(ctx.Request().RequestURI, "/static") {
				ctx.Next()
			}else if strings.Contains(ctx.Request().RequestURI, "socks/export") {
				ctx.Next()
			}else if strings.Contains(ctx.Request().RequestURI, "/api/v1/bindwechatgroup/wechats") {
				ctx.Next()
			}else if strings.Contains(ctx.Request().RequestURI, "/api/v1/bindwechat/exportlog") {
				ctx.Next()
				return
			}else if strings.Contains(ctx.Request().RequestURI, "/api/v1/account/check/friend/passed") {
				ctx.Next()
			}else if strings.HasPrefix(ctx.Request().RequestURI, "/debug/pprof") {
				ctx.Next()
			} else {
				log.Println("接口:    ",ctx.Request().RequestURI,"错误:    ", s)

				result,err := utils.JsonEncode(510,nil,"认证失败，请重新登录认证")
				ctx.ResponseWriter().Write(result)
				//i, err := ctx.JSON(result)
				if err != nil {
					log.Println(err)
				}
			}
		},
	})
	return jwtHandler
}

func ParseToken(tokenString string, key string) (interface{}, bool) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(key), nil
	})
	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		return claims, true
	} else {
		log.Println(err)
		return "", false
	}
}

//生成token
func GenerateToken(maps map[string]interface{}) string {
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"session":    maps["Session"],                                             //session
		"id":         maps["ID"],                                                  //用户信息
		"iss":        "Iris",                                                   //签发者
		"iat":        time.Now().Unix(),                                        //签发时间
		"jti":        "9527",                                                   //jwt的唯一身份标识，主要用来作为一次性token,从而回避重放攻击。
		"exp":        time.Now().Add(10 * time.Hour * time.Duration(1)).Unix(), //过期时间
	})
	tokenString, _ := token.SignedString([]byte(JwtKey))
	fmt.Println("签发时间：", time.Now().Unix())
	fmt.Println("到期时间：", time.Now().Add(10 * time.Hour * time.Duration(1)).Unix())
	return tokenString
}

func CheckSession(ctx iris.Context) {
	if strings.Contains(ctx.Request().RequestURI, "/api/v1/user/login") {
		ctx.Next()
		return
	}
	if strings.Contains(ctx.Request().RequestURI, "/api/v1/bindwechatgroup/wechats") {
		ctx.Next()
		return
	}
	if strings.Contains(ctx.Request().RequestURI, "/api/v1/bindwechat/exportlog") {
		ctx.Next()
		return
	}
	if strings.Contains(ctx.Request().RequestURI, "/api/v1/account/check/friend/passed") {
		ctx.Next()
		return
	}
	if strings.Contains(ctx.Request().RequestURI, "/static") {
		ctx.Next()
		return
	}
	if strings.HasPrefix(ctx.Request().RequestURI, "/debug/pprof") {
		ctx.Next()
		return
	}
	token := GetToken(ctx)
	var sessionID = ""
	if token != "" && token != "undefined" && len(token) > 7 {
		v, _ := ParseToken(token, JwtKey)
		if v != "" {
			sessionID = v.(jwt.MapClaims)["session"].(string)
		}
	}
	var onlineSessionIDList = SMgr.GetSessionIDList()
	for _, onlineSessionID := range onlineSessionIDList {
		if onlineSessionID == sessionID {
			ctx.Next()
			return
		}
	}

	msg := "该账号已在其它设备登陆!"
	if sessionID == "" {
		msg = "登陆已过期,请重新登陆!"
	}
	if token == "" {
		msg = "没有获取到权限,请重新登陆!"
	}

	result,err := utils.JsonEncode(512,nil,msg)
	ctx.ResponseWriter().Write(result)
	if err != nil {
		log.Println(err)
	}
	//ctx.Next()
}

func GetToken(ctx iris.Context) string {
	token := ctx.GetHeader("Authorization")

	if token != "" && len(token) > 7 {
		token = token[7:]
	}
	return token
}
func GetUserID(token string) string {
	id := ""

	if strings.HasPrefix(strings.ToUpper(token),"BEARER") {
		token = token[7:]
	}

	if token != "" && token != "undefined" && len(token) > 7 {
		v, _ := ParseToken(token, JwtKey)
		if v != "" {
			id = cast.ToString(v.(jwt.MapClaims)["id"])
		}
	}
	return id
}
//func GetWeChatID(token string) string {
//	id := ""
//
//	if strings.HasPrefix(strings.ToUpper(token),"BEARER") {
//		token = token[7:]
//	}
//
//	if token != "" && token != "undefined" && len(token) > 7 {
//		v, _ := ParseToken(token, JwtKey)
//		if v != "" {
//			id = cast.ToString(v.(jwt.MapClaims)["wxid"])
//		}
//	}
//	return id
//}
