package main

import (
	"flag"
	"github.com/iris-contrib/middleware/cors"
	"github.com/kataras/iris"
	"github.com/liuzhiyi/go-db"
	"wechatmanagent/config"
	"wechatmanagent/route"
	"wechatmanagent/task"
)

func main() {
	flag.Parse()
	defer db.F.Destroy()


	app := newApp()
	route.InitRouter(app)

	//运行定时任务
	go task.RunTask()

	err := app.Run(iris.Addr(":"+config.Sysconfig.Port), iris.WithoutServerError(iris.ErrServerClosed))
	if err != nil {
		panic(err)
	}
	//app.Run(iris.TLS(":"+config.Sysconfig.Port, config.Sysconfig.CertFile,config.Sysconfig.CertKey))
}

func newApp() *iris.Application {
	app := iris.New()
	//route.InitRouter(app)

	app.Logger().SetLevel("debug")
	app.Configure(iris.WithOptimizations)
	app.StaticWeb("/", config.Sysconfig.FileSavePath)
	cors.New(cors.Options{
		AllowedOrigins:   []string{"*"}, // allows everything, use that to change the hosts.
		AllowCredentials: true,
		AllowedHeaders:   []string{"*"},
	})


	//app.Use(iris.Gzip, logger.New(), crs) //
	app.AllowMethods(iris.MethodOptions)
	return app
}
