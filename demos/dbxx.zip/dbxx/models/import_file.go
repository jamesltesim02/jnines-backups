/*
@Time : 2019/5/16 15:45 
@Author : Lukebryan
@File : import_file.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

//type ImportFile struct {
//	ID	uint
//	Name	string		//导入文件名
//	UserID	uint		//用户ID
//	DataType	string	//导入数据类型(自定义数据)
//	DataCount	int		//导入数据量
//	Loginfo		string	//导入提示信息(数据导入完成/数据导入失败)
//	State	bool	//启用状态
//	CreateDate	time.Time	//添加时间
//	Describe	string	`gorm:"-"`	//描述
//}


type ImportFile struct {
	db.Item
}

func NewImportFile() (*ImportFile, error) {
	table := "ym_import_file"
	a := new(ImportFile)
	err := a.Init(table, "id")
	return a, err
}

func (i *ImportFile) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *ImportFile) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.AddFieldToFilter("user_id", "eq", userID)
	c.Load()
	return c
}

func (i *ImportFile) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}