package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type Material struct {
	db.Item
}

func NewMaterial() (*Material, error) {
	table := "ym_material"
	c := new(Material)
	err := c.Init(table, "id")
	return c, err
}

func (b *Material) Save() error {
	if b.GetId() == 0 {
		b.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return b.Item.Save()
}
