/*
@Time : 2019/5/28 10:55 
@Author : Lukebryan
@File : friends_circle_plan.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type TalkPlan struct {
	db.Item
}

func NewTalkPlan() (*TalkPlan, error) {
	table := "ym_talk_plan"
	a := new(TalkPlan)
	err := a.Init(table, "id")
	return a, err
}

func (i *TalkPlan) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *TalkPlan) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *TalkPlan) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
