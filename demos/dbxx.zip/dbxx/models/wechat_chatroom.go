/*
@Time : 2019/6/24 14:11 
@Author : Lukebryan
@File : wechat_chatroom.go		机器人群聊天,机器人群关联表
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type WechatChatroom struct {
	db.Item
}

func NewWechatChatroom() (*WechatChatroom, error) {
	table := "ym_wechat_chatroom"
	a := new(WechatChatroom)
	err := a.Init(table, "id")
	return a, err
}

func (i *WechatChatroom) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
