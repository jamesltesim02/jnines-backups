package models

import (
	"github.com/liuzhiyi/go-db"
)

type Friend struct {
	db.Item
}

func NewFriend() (*Friend, error) {
	table := "ym_wechat_friends"
	a := new(Friend)
	err := a.Init(table, "id")
	return a, err
}

func (f *Friend) IsExisted(wxid string) bool {
	f.SetData("wxid", wxid)
	f.GetResource().FetchRow(&f.Item)
	return f.GetId() > 0
}

func (f *Friend) GetList(belongWxid string) *db.Collection {
	c := f.GetCollection()
	c.AddFieldToFilter("belong_wxid", "eq", belongWxid)
	c.Load()
	return c
}
