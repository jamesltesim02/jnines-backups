/*
@Time : 2019/7/9 16:08 
@Author : Lukebryan
@File : wechat_in_chatroom.go	拉群任务中机器人扫码进群记录
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type WechatInChatroom struct {
	db.Item
}

func NewWechatInChatroom() (*WechatInChatroom, error) {
	table := "ym_wechat_in_chatroom"
	a := new(WechatInChatroom)
	err := a.Init(table, "id")
	return a, err
}


func (i *WechatInChatroom) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
