package models

import (
	db "github.com/liuzhiyi/go-db"
	"time"
)

type BindWechatGroup struct {
	db.Item
}

func NewBindWechatGroup() (*BindWechatGroup, error) {
	table := "ym_bind_wechat_group"
	c := new(BindWechatGroup)
	err := c.Init(table, "id")
	return c, err
}

func (b *BindWechatGroup) Add() error {
	b.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	return b.Save()
}
