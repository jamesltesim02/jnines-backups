/*
@Time : 2019/8/10 9:13 
@Author : Lukebryan
@File : wechat_use_state.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type WechatUseState struct {
	db.Item
}

func NewWechatUseState() (*WechatUseState, error) {
	table := "ym_wechat_use_state"
	a := new(WechatUseState)
	err := a.Init(table, "id")
	return a, err
}

func (i *WechatUseState) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}
	return i.Item.Save()
}

