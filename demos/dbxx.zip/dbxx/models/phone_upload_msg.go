/*
@Time : 2019/7/10 11:35 
@Author : Lukebryan
@File : phone_upload_msg.go
@Software: GoLand
*/
package models

//type PhoneUploadMsg struct {
//	db.Item
//}
//
//func NewPhoneUploadMsg() (*PhoneUploadMsg, error) {
//	table := "ym_phone_upload_msg"
//	a := new(PhoneUploadMsg)
//	err := a.Init(table, "id")
//	return a, err
//}
//
//func (i *PhoneUploadMsg) Save() error {
//	if i.GetId() == 0 {
//		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
//	}
//
//	return i.Item.Save()
//}

