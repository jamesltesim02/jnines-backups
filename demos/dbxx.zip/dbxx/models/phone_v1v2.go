/*
@Time : 2019/8/2 14:54 
@Author : Lukebryan
@File : phone_v1v2.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type PhoneV1v2 struct {
	db.Item
}

func NewPhoneV1v2() (*PhoneV1v2, error) {
	table := "ym_phone_v1v2"
	a := new(PhoneV1v2)
	err := a.Init(table, "id")
	return a, err
}

func (i *PhoneV1v2) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
