package models

import (
	db "github.com/liuzhiyi/go-db"
	"time"
)

type TaskCategory struct {
	db.Item
}

func NewTaskCategory() (*TaskCategory, error) {
	table := "ym_task_category"
	c := new(TaskCategory)
	err := c.Init(table, "id")
	return c, err
}

func (b *TaskCategory) Save() error {
	b.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	return b.Item.Save()
}
