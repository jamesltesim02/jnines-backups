/*
@Time : 2019/5/28 10:48 
@Author : Lukebryan
@File : friends_circle_material.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type TalkMaterial struct {
	db.Item
}

func NewTalkMaterial() (*TalkMaterial, error) {
	table := "ym_talk_material"
	a := new(TalkMaterial)
	err := a.Init(table, "id")
	return a, err
}

func (i *TalkMaterial) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *TalkMaterial) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *TalkMaterial) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
