/*
@Time : 2019/6/2 14:11 
@Author : Lukebryan
@File : wechat_pwd_history.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type WechatPwdHistory struct {
	db.Item
}

func NewWechatPwdHistory() (*WechatPwdHistory, error) {
	table := "ym_wechat_pwd_history"
	a := new(WechatPwdHistory)
	err := a.Init(table, "id")
	return a, err
}

func (i *WechatPwdHistory) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *WechatPwdHistory) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *WechatPwdHistory) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
