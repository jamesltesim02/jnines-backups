/*
@Time : 2019/5/17 18:12 
@Author : Lukebryan
@File : import_data.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
)

type ImportData struct {
	db.Item
}

func NewImportData() (*ImportData, error) {
	table := "ym_import_data"
	a := new(ImportData)
	err := a.Init(table, "id")
	return a, err
}

func (i *ImportData) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *ImportData) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *ImportData) Save() error {
	//if i.GetId() == 0 {
	//	i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	//}

	return i.Item.Save()
}
