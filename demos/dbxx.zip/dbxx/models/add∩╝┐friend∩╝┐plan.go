/*
@Time : 2019/5/18 13:50 
@Author : Lukebryan
@File : add＿friend＿plan.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)


type AddFriendPlan struct {
	db.Item
}

func NewAddFriendPlan() (*AddFriendPlan, error) {
	table := "ym_add_friend_plan"
	a := new(AddFriendPlan)
	err := a.Init(table, "id")
	return a, err
}

func (i *AddFriendPlan) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *AddFriendPlan) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *AddFriendPlan) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
func (i *AddFriendPlan) Update(maps map[string]interface{}) error {
	for k,v := range maps{
		i.SetData(k,v)
	}
	return i.Item.Save()
}
