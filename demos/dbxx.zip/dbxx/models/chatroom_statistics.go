/*
@Time : 2019/6/14 14:26 
@Author : Lukebryan
@File : chatroom_statistics.go
@Software: GoLand
*/
package models

import "github.com/liuzhiyi/go-db"

type ChatroomStatistics struct {
	db.Item
}

func NewChatroomStatistics() (*ChatroomStatistics, error) {
	table := "ym_chatroom_statistics"
	a := new(ChatroomStatistics)
	err := a.Init(table, "id")
	return a, err
}

func (i *ChatroomStatistics) Save() error {
	return i.Item.Save()
}