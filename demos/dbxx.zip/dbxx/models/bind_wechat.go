package models

import (
	db "github.com/liuzhiyi/go-db"
	"time"
)

const (
	BindWechatStatusLoginFailed  = iota //登录失败
	BindWechatStatusLoginSuccess        //登录成功
	BindWechatStatusForbidden           //被微信封号
)

type BindWechat struct {
	db.Item
}

func NewBindWechat() (*BindWechat, error) {
	table := "ym_bind_wechats"
	c := new(BindWechat)
	err := c.Init(table, "id")
	return c, err
}

func (b *BindWechat) Add() error {
	e, err := NewBindWechat()
	if err != nil {
		return err
	}

	e.SetData("wechat_id", b.GetString("wechat_id"))
	e.Row()
	if e.GetId() > 0 {
		b.SetId(e.GetInt64("id"))
	}
	b.SetData("last_login_date", time.Now().Format("2006-01-02 15:04:05"))
	return b.Save()
}

func (b *BindWechat) GetByWechatID(wechatID string) *db.Item {
	e, err := NewBindWechat()
	if err != nil {
		return &e.Item
	}
	s := e.GetCollection()
	s.AddFieldToFilter("wechat_id","eq",wechatID)
	s.Load()
	if len(s.GetItems()) < 1 {
		return &e.Item
	}
	return s.GetItems()[0]
}