/*
@Time : 2019/5/18 16:32 
@Author : Lukebryan
@File : customer.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type Customer struct {
	db.Item
}

func NewCustomer() (*Customer, error) {
	table := "ym_customer"
	a := new(Customer)
	err := a.Init(table, "id")
	return a, err
}

func (i *Customer) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *Customer) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *Customer) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
