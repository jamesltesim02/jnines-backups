/*
@Time : 2019/5/28 10:48 
@Author : Lukebryan
@File : msg_material.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type MsgMaterial struct {
	db.Item
}

func NewMsgMaterial() (*MsgMaterial, error) {
	table := "ym_msg_material"
	a := new(MsgMaterial)
	err := a.Init(table, "id")
	return a, err
}

func (i *MsgMaterial) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
