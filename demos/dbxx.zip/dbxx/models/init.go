package models

import (
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	db "github.com/liuzhiyi/go-db"
	"wechatmanagent/config"
)

func init() {
	db.F.InitDb("mysql", fmt.Sprintf("%s:%s@tcp(%s)/%s?charset=utf8mb4", config.Sysconfig.DBUserName, config.Sysconfig.DBPassword, config.Sysconfig.DBIp+":"+config.Sysconfig.DBPort, config.Sysconfig.DBName), "")
	db.F.GetConnect("read").GetDb().SetMaxOpenConns(100)
}

