/*
@Time : 2019/6/13 18:33 
@Author : Lukebryan
@File : wechat_statistics.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
)

type WechatStatistics struct {
	db.Item
}

func NewWechatStatistics() (*WechatStatistics, error) {
	table := "ym_wechat_statistics"
	a := new(WechatStatistics)
	err := a.Init(table, "id")
	return a, err
}

func (i *WechatStatistics) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *WechatStatistics) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *WechatStatistics) Save() error {
	return i.Item.Save()
}

