/*
@Time : 2019/5/28 10:48 
@Author : Lukebryan
@File : msg_material_group.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type MsgMaterialGroup struct {
	db.Item
}

func NewMsgMaterialGroup() (*MsgMaterialGroup, error) {
	table := "ym_msg_material_group"
	a := new(MsgMaterialGroup)
	err := a.Init(table, "id")
	return a, err
}

func (i *MsgMaterialGroup) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
