package models

import (
	db "github.com/liuzhiyi/go-db"
	"time"
)

type BindWechatsBack struct {
	db.Item
}

func NewBindWechatsBack() (*BindWechatsBack, error) {
	table := "ym_bind_wechats_back"
	c := new(BindWechatsBack)
	err := c.Init(table, "id")
	return c, err
}

func (b *BindWechatsBack) Add() error {
	e, err := NewBindWechatsBack()
	if err != nil {
		return err
	}

	e.SetData("wechat_id", b.GetString("wechat_id"))
	e.Row()
	if e.GetId() > 0 {
		b.SetId(e.GetInt64("id"))
	}
	b.SetData("last_login_date", time.Now().Format("2006-01-02 15:04:05"))
	return b.Save()
}

func (b *BindWechatsBack) GetByWechatID(wechatID string) *db.Item {
	e, err := NewBindWechatsBack()
	if err != nil {
		return &e.Item
	}
	s := e.GetCollection()
	s.AddFieldToFilter("wechat_id","eq",wechatID)
	s.Load()
	if len(s.GetItems()) < 1 {
		return &e.Item
	}
	return s.GetItems()[0]
}

func (i *BindWechatsBack) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
