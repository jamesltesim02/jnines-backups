/*
@Time : 2019/5/16 16:22 
@Author : Lukebryan
@File : verify_message.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type VerifyMessage struct {
	db.Item
}

func NewVerifyMessage() (*VerifyMessage, error) {
	table := "ym_verify_message"
	a := new(VerifyMessage)
	err := a.Init(table, "id")
	return a, err
}

func (i *VerifyMessage) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *VerifyMessage) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *VerifyMessage) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}