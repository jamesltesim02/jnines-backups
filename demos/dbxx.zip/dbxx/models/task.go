package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type Task struct {
	db.Item
}

func NewTask() (*Task, error) {
	table := "ym_task"
	c := new(Task)
	err := c.Init(table, "id")
	return c, err
}

func (b *Task) Save() error {
	if b.GetId() == 0 {
		b.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return b.Item.Save()
}
