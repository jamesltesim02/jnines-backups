/*
@Time : 2019/6/10 14:02 
@Author : Lukebryan
@File : login_log.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type LoginLog struct {
	db.Item
}

func NewLoginLog() (*LoginLog, error) {
	table := "ym_login_log"
	a := new(LoginLog)
	err := a.Init(table, "id")
	return a, err
}

func (i *LoginLog) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *LoginLog) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
