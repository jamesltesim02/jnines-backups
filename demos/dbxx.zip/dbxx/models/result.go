/*
@Time : 2019/5/15 9:50 
@Author : Lukebryan
@File : result.go
@Software: GoLand
*/
package models

type Result struct {
	Code int
	Data interface{}
	Msg  string
}
