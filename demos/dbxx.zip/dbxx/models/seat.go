/*
@Time : 2019/8/7 14:18 
@Author : Lukebryan
@File : seat.go
@Software: GoLand
*/
package models

import "github.com/liuzhiyi/go-db"

/*
座位
 */
type Seat struct {
	//Food	string		//食物
	Customer	*db.Item		//消费者:群
	State		bool		//是否空置
}
