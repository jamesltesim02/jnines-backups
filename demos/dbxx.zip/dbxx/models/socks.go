package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type Socks struct {
	db.Item
}

func NewSocks() (*Socks, error) {
	table := "ym_socks"
	c := new(Socks)
	err := c.Init(table, "id")
	return c, err
}

func (s *Socks) Save() error {
	if s.GetId() == 0 {
		s.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return s.Item.Save()
}

var cache = make(map[string][]*db.Item)

func (s *Socks) GetListByUserId(userId string) []*db.Item {
	if list, ok := cache[userId]; ok {
		return list
	} else {
		c := s.GetCollection()
		c.AddFieldToFilter("user_id", "eq", userId)
		c.AddFieldToFilter("status", "eq", 0)
		c.Load()
		cache[userId] = c.GetItems()
		return c.GetItems()
	}
}
