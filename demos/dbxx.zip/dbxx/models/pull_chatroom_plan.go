/*
@Time : 2019/8/6 11:03 
@Author : Lukebryan
@File : pull_chatroom_plan.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type PullChatroomPlan struct {
	db.Item
}

func NewPullChatroomPlan() (*PullChatroomPlan, error) {
	table := "ym_pull_chatroom_plan"
	a := new(PullChatroomPlan)
	err := a.Init(table, "id")
	return a, err
}

func (i *PullChatroomPlan) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
