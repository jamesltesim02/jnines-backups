/*
@Time : 2019/5/21 10:32 
@Author : Lukebryan
@File : add_friend_log.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type AddFriendLog struct {
	db.Item
}

func NewAddFriendLog() (*AddFriendLog, error) {
	table := "ym_add_friend_log"
	a := new(AddFriendLog)
	err := a.Init(table, "id")
	return a, err
}

func (i *AddFriendLog) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *AddFriendLog) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *AddFriendLog) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}

