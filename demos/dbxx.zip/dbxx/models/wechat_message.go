package models

import (
	"github.com/liuzhiyi/go-db"
)

type WechatMessage struct {
	db.Item
}

func NewWechatMessage() (*WechatMessage, error) {
	table := "ym_wechat_message"
	c := new(WechatMessage)
	err := c.Init(table, "id")
	return c, err
}
