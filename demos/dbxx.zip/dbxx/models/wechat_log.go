/*
@Time : 2019/8/5 15:26 
@Author : Lukebryan
@File : wechat_log.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type WechatLog struct {
	db.Item
}

func NewWechatLog() (*WechatLog, error) {
	table := "ym_wechat_log"
	a := new(WechatLog)
	err := a.Init(table, "id")
	return a, err
}

func (i *WechatLog) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
