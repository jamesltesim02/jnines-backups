/*
@Time : 2019/7/2 14:37 
@Author : Lukebryan
@File : search_contact_response.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type StrangerWechatInfo struct {
	db.Item
}

func NewStrangerWechatInfo() (*StrangerWechatInfo, error) {
	table := "ym_stranger_wechat_info"
	a := new(StrangerWechatInfo)
	err := a.Init(table, "id")
	return a, err
}

func (i *StrangerWechatInfo) GetByWechatID(wechatID string) *db.Item {
	strangerWechatInfo, _ := NewStrangerWechatInfo()
	strangerWechatInfo.SetData("wechat_id", wechatID)
	strangerWechatInfo.Row()
	return &strangerWechatInfo.Item
}

func (i *StrangerWechatInfo) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}

type SearchContactResponse struct {
	BaseResponse    *BaseResponse `protobuf:"bytes,1,req,name=BaseResponse" json:"BaseResponse,omitempty"`
	UserName        *StringT      `protobuf:"bytes,2,req,name=UserName" json:"UserName,omitempty"`
	NickName        *StringT      `protobuf:"bytes,3,req,name=NickName" json:"NickName,omitempty"`
	PYInitial       *StringT      `protobuf:"bytes,4,req,name=PYInitial" json:"PYInitial,omitempty"`
	QuanPin         *StringT      `protobuf:"bytes,5,req,name=QuanPin" json:"QuanPin,omitempty"`
	Sex             *int32        `protobuf:"varint,6,req,name=Sex" json:"Sex,omitempty"`
	Province        *string       `protobuf:"bytes,8,opt,name=Province" json:"Province,omitempty"`
	City            *string       `protobuf:"bytes,9,opt,name=City" json:"City,omitempty"`
	Signature       *string       `protobuf:"bytes,10,opt,name=Signature" json:"Signature,omitempty"`
	PersonalCard    *uint32       `protobuf:"varint,11,opt,name=PersonalCard" json:"PersonalCard,omitempty"`
	VerifyFlag      *uint32       `protobuf:"varint,12,opt,name=VerifyFlag" json:"VerifyFlag,omitempty"`
	VerifyInfo      *string       `protobuf:"bytes,13,opt,name=VerifyInfo" json:"VerifyInfo,omitempty"`
	Weibo           *string       `protobuf:"bytes,14,opt,name=Weibo" json:"Weibo,omitempty"`
	Alias           *string       `protobuf:"bytes,15,opt,name=Alias" json:"Alias,omitempty"`
	WeiboNickname   *string       `protobuf:"bytes,16,opt,name=WeiboNickname" json:"WeiboNickname,omitempty"`
	WeiboFlag       *uint32       `protobuf:"varint,17,opt,name=WeiboFlag" json:"WeiboFlag,omitempty"`
	AlbumStyle      *int32        `protobuf:"varint,18,opt,name=AlbumStyle" json:"AlbumStyle,omitempty"`
	AlbumFlag       *int32        `protobuf:"varint,19,opt,name=AlbumFlag" json:"AlbumFlag,omitempty"`
	AlbumBGImgID    *string       `protobuf:"bytes,20,opt,name=AlbumBGImgID" json:"AlbumBGImgID,omitempty"`
	Country         *string       `protobuf:"bytes,22,opt,name=Country" json:"Country,omitempty"`
	MyBrandList     *string       `protobuf:"bytes,23,opt,name=MyBrandList" json:"MyBrandList,omitempty"`
	ContactCount    *uint32       `protobuf:"varint,25,opt,name=ContactCount" json:"ContactCount,omitempty"`
	BigHeadImgUrl   *string       `protobuf:"bytes,27,opt,name=BigHeadImgUrl" json:"BigHeadImgUrl,omitempty"`
	SmallHeadImgUrl *string       `protobuf:"bytes,28,opt,name=SmallHeadImgUrl" json:"SmallHeadImgUrl,omitempty"`
	AntispamTicket  *string       `protobuf:"bytes,30,opt,name=AntispamTicket" json:"AntispamTicket,omitempty"`
	KFWorkerID      *string       `protobuf:"bytes,31,opt,name=KFWorkerID" json:"KFWorkerID,omitempty"`
	MatchType       *uint32       `protobuf:"varint,32,opt,name=MatchType" json:"MatchType,omitempty"`
}

//{"BaseResponse":{"Ret":0,"ErrMsg":{}},
// "ContactCount":1,
// "ContactList":[
// {"UserName":{
// "String":"wxid_80j29mrx8c8b22"},
// "NickName":{"String":"水泥经销商13596900348杨凯晴奶奶"},
// "PYInitial":{},
// "QuanPin":{},
// "Sex":2,
// "ImgBuf":{"iLen":0},
// "BitMask":0,
// "BitVal":0,
// "ImgFlag":0,
// "Remark":{},
// "RemarkPYInitial":{},
// "RemarkQuanPin":{},
// "ContactType":0,
// "RoomInfoCount":0,
// "DomainList":{},
// "ChatRoomNotify":0,
// "AddContactScene":0,
// "PersonalCard":1,
// "HasWeiXinHdHeadImg":1,
// "VerifyFlag":0,
// "Level":0,
// "Source":0,
// "WeiboFlag":0,
// "AlbumStyle":0,
// "AlbumFlag":0,
// "SnsUserInfo":{"SnsFlag":0,"SnsBGObjectID":0,"SnsFlagEx":0},
// "BigHeadImgUrl":"http://wx.qlogo.cn/mmhead/ver_1/sQFs354bI2Enk9mfctZyHuSTTgYiauxt3Z3h96frIaXD6uTXxnPZ1HgmplPVIStcxocicv1FvSRMDEY0TzFiaMAak6ylQ7DzcPMrdicR80gr37c/0",
// "SmallHeadImgUrl":"http://wx.qlogo.cn/mmhead/ver_1/sQFs354bI2Enk9mfctZyHuSTTgYiauxt3Z3h96frIaXD6uTXxnPZ1HgmplPVIStcxocicv1FvSRMDEY0TzFiaMAak6ylQ7DzcPMrdicR80gr37c/96",
// "CustomizedInfo":{"BrandFlag":0},
// "HeadImgMd5":"7faa9a92ee13ae00a4bf25009a8fb988",
// "AdditionalContactList":{"LinkedinContactItem":{}},
// "ChatroomVersion":0,
// "ChatroomMaxCount":0,
// "ChatroomType":0,
// "NewChatroomData":{"MemberCount":0,"InfoMask":0},
// "DeleteFlag":0
// }
// ],
// "Ret":[0]
// }

type ContactList struct {
	UserName        StringT `protobuf:"bytes,2,req,name=UserName" json:"UserName,omitempty"`
	NickName        StringT `protobuf:"bytes,3,req,name=NickName" json:"NickName,omitempty"`
	PYInitial       StringT `protobuf:"bytes,4,req,name=PYInitial" json:"PYInitial,omitempty"`
	QuanPin         StringT `protobuf:"bytes,5,req,name=QuanPin" json:"QuanPin,omitempty"`
	Sex             int32   `protobuf:"varint,6,req,name=Sex" json:"Sex,omitempty"`
	Signature       string  `protobuf:"bytes,10,opt,name=Signature" json:"Signature,omitempty"`
	VerifyFlag      int32   `protobuf:"bytes,13,opt,name=VerifyFlag" json:"VerifyFlag,omitempty"`
	WeiboFlag       uint32  `protobuf:"varint,17,opt,name=WeiboFlag" json:"WeiboFlag,omitempty"`
	AlbumStyle      int32   `protobuf:"varint,18,opt,name=AlbumStyle" json:"AlbumStyle,omitempty"`
	AlbumFlag       int32   `protobuf:"varint,19,opt,name=AlbumFlag" json:"AlbumFlag,omitempty"`
	BigHeadImgUrl   string  `protobuf:"bytes,27,opt,name=BigHeadImgUrl" json:"BigHeadImgUrl,omitempty"`
	SmallHeadImgUrl string  `protobuf:"bytes,28,opt,name=SmallHeadImgUrl" json:"SmallHeadImgUrl,omitempty"`
	HeadImgMd5      string  `protobuf:"bytes,31,opt,name=HeadImgMd5" json:"HeadImgMd5,omitempty"`
	DeleteFlag      uint32  `protobuf:"varint,32,opt,name=DeleteFlag" json:"DeleteFlag,omitempty"`
}

type ContactResponse struct {
	BaseResponse BaseResponse  `protobuf:"bytes,1,req,name=BaseResponse" json:"BaseResponse,omitempty"`
	ContactCount uint32        `protobuf:"varint,25,opt,name=ContactCount" json:"ContactCount,omitempty"`
	ContactList  []ContactList `protobuf:"bytes,2,req,name=ContactList" json:"ContactList,omitempty"`
	Ret          []int32       `protobuf:"varint,1,req,name=Ret" json:"Ret,omitempty"`
}

type StringT struct {
	String_ *string `protobuf:"bytes,1,opt,name=String" json:"String,omitempty"`
}

type BaseResponse struct {
	Ret    *int32   `protobuf:"varint,1,req,name=Ret" json:"Ret,omitempty"`
	ErrMsg *StringT `protobuf:"bytes,2,req,name=ErrMsg" json:"ErrMsg,omitempty"`
}

//"Data":{"BaseResponse":{"Ret":0,"ErrMsg":{"String":"Everything is OK"}},"MemberCount":2,
//	"MemberList":[{"MemberName":{"String":"wxid_tkzhhyyfrehb22"},"MemberStatus":4,"NickName":{},
//	"PYInitial":{},"QuanPin":{},"Sex":0,"Remark":{},"RemarkPYInitial":{},"RemarkQuanPin":{},
//	"ContactType":0,"PersonalCard":0,"VerifyFlag":0},
//	{"MemberName":{"String":"wxid_tnb3o96df8bz22"},"MemberStatus":0,"NickName":{"String":"二平"},
//	"PYInitial":{"String":"EP"},"QuanPin":{"String":"erping"},"Sex":1,"Remark":{},
//	"RemarkPYInitial":{},"RemarkQuanPin":{},"ContactType":0,"PersonalCard":1,"VerifyFlag":0,
//	"Country":"AD"}]}

type MemberList struct {
	MemberName      StringT `json:"MemberName,omitempty"`
	MemberStatus    int32   `json:"MemberStatus,omitempty"`
	NickName        StringT `json:"NickName,omitempty"`
	PYInitial       StringT `json:"PYInitial,omitempty"`
	QuanPin         StringT `json:"QuanPin,omitempty"`
	Sex             int32   `json:"Sex,omitempty"`
	Remark          StringT `json:"Remark,omitempty"`
	RemarkPYInitial StringT `json:"RemarkPYInitial,omitempty"`
	RemarkQuanPin   StringT `json:"RemarkQuanPin,omitempty"`
	ContactType     int32   `json:"ContactType,omitempty"`
	PersonalCard    int32   `json:"PersonalCard,omitempty"`
	VerifyFlag      int32   `json:"VerifyFlag,omitempty"`
	Country         string  `json:"Country,omitempty"`
}
