/*
@Time : 2019/5/20 11:33 
@Author : Lukebryan
@File : handle_fans.go
@Software: GoLand
*/
package models

import "github.com/liuzhiyi/go-db"

type HandleFans struct {
	db.Item
}

func NewHandleFans() (*HandleFans, error) {
	table := "ym_handle_fans"
	a := new(HandleFans)
	err := a.Init(table, "id")
	return a, err
}

func (i *HandleFans) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *HandleFans) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}
