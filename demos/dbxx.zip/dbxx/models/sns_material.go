/*
@Time : 2019/5/28 10:48 
@Author : Lukebryan
@File : friends_circle_material.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type SnsMaterial struct {
	db.Item
}

func NewSnsMaterial() (*SnsMaterial, error) {
	table := "ym_sns_material"
	a := new(SnsMaterial)
	err := a.Init(table, "id")
	return a, err
}

func (i *SnsMaterial) IsExisted(id string) bool {
	i.SetData("id", id)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *SnsMaterial) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *SnsMaterial) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
