package models

import (
	"crypto/md5"
	"encoding/hex"

	db "github.com/liuzhiyi/go-db"
	"github.com/sony/sonyflake"
)

type Card struct {
	db.Item
}

func NewCard() (*Card, error) {
	table := "ym_cards"
	a := new(Card)
	err := a.Init(table, "id")
	return a, err
}

func (c *Card) Get(id int64) *db.Item {
	collection := c.GetCollection()
	collection.JoinLeft(
		"ym_card_categories as cc",
		"m.category_id = cc.id",
		"title, valid_time, is_persist, card_perfix",
	)
	collection.Load()
	items := collection.GetItems()
	if len(items) == 0 {
		return nil
	} else {
		return items[0]
	}
}

func (c *Card) Create(prefix string) error {
	flake := sonyflake.NewSonyflake(sonyflake.Settings{})
	id, err := flake.NextID()
	if err != nil {
		return err
	}

	h := md5.New()
	h.Write([]byte{byte(id & 0xff), byte(id >> 8 & 0xff), byte(id >> 16 & 0xff), byte(id >> 24 & 0xff), byte(id >> 32 & 0xff), byte(id >> 40 & 0xff), byte(id >> 48 & 0xff), byte(id >> 56 & 0xff)})
	dst := h.Sum(nil)
	code := hex.EncodeToString(dst)
	c.SetData("code", prefix+code)
	c.SetData("is_active", 0)
	return c.Save()
}
