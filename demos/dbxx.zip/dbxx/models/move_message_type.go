/*
@Time : 2019/5/16 19:11 
@Author : Lukebryan
@File : move_message_type.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type MoveMessageType struct {
	db.Item
}

func NewMoveMessageType() (*MoveMessageType, error) {
	table := "ym_move_message_type"
	a := new(MoveMessageType)
	err := a.Init(table, "id")
	return a, err
}

func (i *MoveMessageType) IsExisted(name string) bool {
	i.SetData("name", name)
	i.GetResource().FetchRow(&i.Item)
	return i.GetId() > 0
}

func (i *MoveMessageType) GetList(userID string) *db.Collection {
	c := i.GetCollection()
	c.Load()
	return c
}

func (i *MoveMessageType) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}
