package models

import (
	db "github.com/liuzhiyi/go-db"
)

type CardCategory struct {
	db.Item
}

func NewCardCategory() (*CardCategory, error) {
	table := "ym_card_categories"
	c := new(CardCategory)
	err := c.Init(table, "id")
	return c, err
}

func (c *CardCategory) Add(category *CardCategory) {

}

func (c *CardCategory) Get(id int64) {}
