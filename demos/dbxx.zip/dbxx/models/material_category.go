package models

import (
	db "github.com/liuzhiyi/go-db"
	"time"
)

type MaterialCategory struct {
	db.Item
}

func NewMaterialCategory() (*MaterialCategory, error) {
	table := "ym_material_category"
	c := new(MaterialCategory)
	err := c.Init(table, "id")
	return c, err
}

func (i *MaterialCategory) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}

