package models

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"time"

	"github.com/liuzhiyi/go-db"
)

var (
	ErrPasswordLength    = errors.New("密码长度应该为8-20之间")
	ErrUserNameEmpty     = errors.New("用户名不能为空")
	ErrPasswordUncorrect = errors.New("密码不正确")
)

type User struct {
	db.Item
}

func NewUser() (*User, error) {
	table := "ym_users"
	a := new(User)
	err := a.Init(table, "id")
	return a, err
}

func (u *User) VerifyLogin() error {
	pwd, err := u.encryptPassword()
	if err != nil {
		return err
	}

	u.SetData("password", pwd)
	u.GetResource().FetchRow(&u.Item)
	if u.GetId() > 0 {
		return nil
	} else {
		return ErrPasswordUncorrect
	}
}

// password+"JOIN"+username
func (u *User) encryptPassword() (string, error) {
	pwd := u.GetString("password")
	userName := u.GetString("user_name")
	if userName == "" {
		return "", ErrUserNameEmpty
	}

	if len(pwd) > 20 && len(pwd) < 8 {
		return "", ErrPasswordLength
	}

	h256 := sha256.New()
	h256.Write([]byte(pwd))
	h256.Write([]byte("JOIN"))
	h256.Write([]byte(userName))
	return hex.EncodeToString(h256.Sum(nil)), nil
}

func (u *User) Create() error {
	password, err := u.encryptPassword()
	if err != nil {
		return err
	}

	u.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	u.SetData("password", password)
	return u.Save()
}
