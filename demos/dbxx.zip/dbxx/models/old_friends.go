/*
@Time : 2019/8/7 19:58 
@Author : Lukebryan
@File : old_friends.go
@Software: GoLand
*/
package models

import (
	"github.com/liuzhiyi/go-db"
	"time"
)

type OldFriends struct {
	db.Item
}

func NewOldFriends() (*OldFriends, error) {
	table := "ym_old_friends"
	a := new(OldFriends)
	err := a.Init(table, "id")
	return a, err
}

func (i *OldFriends) Save() error {
	if i.GetId() == 0 {
		i.SetData("create_date", time.Now().Format("2006-01-02 15:04:05"))
	}

	return i.Item.Save()
}

